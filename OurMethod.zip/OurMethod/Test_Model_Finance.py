# -*- coding: utf-8 -*-
"""
Test Script for Dual-Engine Anomaly Detection Framework (dADF)

"""

import numpy as np
import torch
import pandas as pd
import os
import sys
import time
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from sklearn.metrics import roc_auc_score, average_precision_score
import warnings
warnings.filterwarnings('ignore')


try:
    from dADF_Finance import (
        GOEEngine,
        MLNNEngine,
        DualEngineADF,
        EnhancedDualEngineSynergy,
        TheoremBasedThresholdDynamic,
        DataCleaner,
        calculate_gmean,
        ensure_numpy_array,
        AdvancedDynamicThresholdManager,
        DynamicAdaptiveThreshold,
        EnhancedThresholdFusion
    )
except ImportError:
    print("Unable to import necessary classes and functions. Please ensure that dADF_clean.py is in the same directory")
    sys.exit(1)


try:
    from ReadFinanceDataSet import DataProcessor
except ImportError:
    print("Unable to import DataProcessor. Please ensure that ReadFinanceDataSet.py is in the same directory")
    sys.exit(1)
    
    
import torch.serialization
torch.serialization.add_safe_globals([DualEngineADF, GOEEngine, MLNNEngine])


def calculate_gmean(y_true, y_pred):
    """Calculate G-mean"""
    cm = confusion_matrix(y_true, y_pred)
    if cm.shape == (2, 2):
        tn, fp, fn, tp = cm.ravel()
        specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
        sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0
        return np.sqrt(sensitivity * specificity)
    else:
        return 0.0


def load_trained_model(model_path):
    """Loading model"""
    print(f"Loading trained model from: {model_path}")
    
    try:
        checkpoint = torch.load(model_path, 
                               map_location=torch.device('cuda' if torch.cuda.is_available() else 'cpu'),
                               weights_only=False)
        
        print("Model checkpoint loaded successfully!")
        
        if 'goe_projection_basis' in checkpoint:
            input_size = checkpoint['goe_projection_basis'].shape[0]
        else:
            print("Warning: Could not determine input size from checkpoint")


        print(f"Creating model with input size: {input_size}")
        model = DualEngineADF(input_size=input_size)
        
        if 'goe_eigenvectors' in checkpoint:
            model.goe_engine.eigenvectors = checkpoint['goe_eigenvectors']
        if 'goe_eigenvalues' in checkpoint:
            model.goe_engine.eigenvalues = checkpoint['goe_eigenvalues']
        if 'goe_reference_mean' in checkpoint:
            model.goe_engine.reference_mean = checkpoint['goe_reference_mean']
        if 'goe_reference_cov' in checkpoint:
            model.goe_engine.reference_cov = checkpoint['goe_reference_cov']
        if 'goe_projection_basis' in checkpoint:
            model.goe_engine.projection_basis = checkpoint['goe_projection_basis']
        
        if 'mlnn_engine_state_dict' in checkpoint:
            model.mlnn_engine.load_state_dict(checkpoint['mlnn_engine_state_dict'])
            print("MLNN engine state loaded successfully")
        
        if 'lambda_reg' in checkpoint:
            model.lambda_reg = checkpoint['lambda_reg']
        
        model.mlnn_engine.eval()
        
        print("Model loaded successfully!")
        return model
        
    except Exception as e:
        print(f"Error loading model: {e}")
        import traceback
        traceback.print_exc()
        return None


def compute_scores(model, X_test):
 
    goe_scores = model.goe_engine.compute_anomaly_scores(X_test)
    
    sequence_length = 5
    X_seq = model._create_sequences(X_test, sequence_length)
    if len(X_seq) == 0:
        X_tensor = torch.FloatTensor(X_test).unsqueeze(1).to(model.device)
    else:
        X_tensor = torch.FloatTensor(X_seq).to(model.device)
    
    model.mlnn_engine.eval()
    with torch.no_grad():
        mlnn_scores = model.mlnn_engine(X_tensor)
        mlnn_scores_norm = torch.sigmoid(mlnn_scores).cpu().numpy()
    

    min_length = min(len(goe_scores), len(mlnn_scores_norm))
    goe_scores = goe_scores[:min_length]
    mlnn_scores_norm = mlnn_scores_norm[:min_length]
    
    return goe_scores, mlnn_scores_norm, min_length

def compute_dual_scores_fused(goe_scores, mlnn_scores):
 
    min_length = min(len(goe_scores), len(mlnn_scores))
    goe_scores = goe_scores[:min_length]
    mlnn_scores = mlnn_scores[:min_length]
    
    goe_scores_norm = (goe_scores - np.min(goe_scores)) / (np.max(goe_scores) - np.min(goe_scores) + 1e-8)
    
    # Specific fusion strategy for financial data（Consistent with training code）
    goe_percentiles = np.percentile(goe_scores_norm, [ 95, 99, 99.5])
    goe_min = goe_percentiles[0]
    goe_max = goe_percentiles[2]
    goe_norm_financial = (goe_scores_norm - goe_min) / (goe_max - goe_min + 1e-8)
    goe_norm_financial = np.clip(goe_norm_financial, 0, 1)
    
    mlnn_min = np.percentile(mlnn_scores, 10)
    mlnn_max = np.percentile(mlnn_scores, 90)
    mlnn_norm_financial = (mlnn_scores - mlnn_min) / (mlnn_max - mlnn_min + 1e-8)
    mlnn_norm_financial = np.clip(mlnn_norm_financial, 0, 1)
    
    # Calculate MLNN confidence level
    mlnn_std = np.std(mlnn_norm_financial)
    mlnn_confidence = 1.0 - min(mlnn_std * 5, 1.0)
    
    # Fusion strategy (consistent with training code)
    dual_scores = np.zeros_like(goe_norm_financial)
    goe_uncertainty = 2.0 * np.abs(goe_norm_financial - 0.5)
    
    for i in range(len(goe_norm_financial)):
        g_score = goe_norm_financial[i]
        m_score = mlnn_norm_financial[i]
        g_uncertain = goe_uncertainty[i]
        
        if g_uncertain < 0.3:
            if g_score > 0.7:
                weight = 0.8
                dual_scores[i] = weight * g_score + (1 - weight) * m_score
            else:
                weight = 0.7
                dual_scores[i] = weight * g_score + (1 - weight) * m_score
        elif g_uncertain > 0.7:
            if mlnn_confidence > 0.6 and np.abs(m_score - 0.5) > 0.3:
                weight = 0.7
                dual_scores[i] = weight * m_score + (1 - weight) * g_score
            else:
                dual_scores[i] = 0.5 * g_score + 0.5 * m_score
        else:
            score_diff = np.abs(g_score - m_score)
            if score_diff < 0.2:
                dual_scores[i] = (g_score + m_score) / 2
            else:
                if g_score > 0.6:
                    weight = 0.6
                else:
                    weight = 0.4
                dual_scores[i] = weight * g_score + (1 - weight) * m_score
    
    # Enhance the discrimination of high scoring regions
    high_score_mask = dual_scores > 0.7
    if np.sum(high_score_mask) > 0:
        dual_scores[high_score_mask] = dual_scores[high_score_mask] ** 0.8
    
    # smoothing process
    if len(dual_scores) > 10:
        smoothed = np.convolve(dual_scores, np.ones(5)/5, mode='same')
        dual_scores = 0.7 * dual_scores + 0.3 * smoothed
    
    return dual_scores

def evaluate_with_percentile_threshold(dual_scores, y_true, percentile=99.9):
 
    threshold = np.percentile(dual_scores, percentile)
    

    min_length = min(len(dual_scores), len(y_true))
    scores = dual_scores[:min_length]
    y_true_adj = y_true[:min_length]
    y_true_int = y_true_adj.astype(int)

    predictions = (scores > threshold).astype(int)
    

    accuracy = accuracy_score(y_true_int, predictions)
    precision = precision_score(y_true_int, predictions, zero_division=0)
    recall = recall_score(y_true_int, predictions, zero_division=0)
    f1 = f1_score(y_true_int, predictions, zero_division=0)
    gmean = calculate_gmean(y_true_int, predictions)
    

    try:
        auc = roc_auc_score(y_true_int, scores)
    except:
        auc = 0
    

    try:
        pr_auc = average_precision_score(y_true_int, scores)
    except:
        pr_auc = 0
    
    cm = confusion_matrix(y_true_int, predictions)
    
    anomaly_rate_actual = np.mean(y_true_int)
    anomaly_rate_predicted = np.mean(predictions)
    
    return {
        'engine': 'DUAL',
        'threshold': threshold,
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1_score': f1,
        'g_mean': gmean,
        'auc': auc,
        'pr_auc': pr_auc,
        'confusion_matrix': cm,
        'actual_anomaly_rate': anomaly_rate_actual,
        'predicted_anomaly_rate': anomaly_rate_predicted,
        'n_samples': min_length,
        'predictions': predictions,
        'scores': scores,
        'y_true': y_true_int
    }

def save_test_results(results):
 
    results_data = [{
        'engine': results['engine'],
        'auc': results['auc'],
        'pr_auc': results['pr_auc'],
        'accuracy': results['accuracy'],
        'precision': results['precision'],
        'recall': results['recall'],
        'f1_score': results['f1_score'],
        'g_mean': results['g_mean']
    }]
    
 
    results_df = pd.DataFrame(results_data)
    

    columns_order = ['engine', 'auc', 'pr_auc','accuracy', 'precision', 'recall', 'f1_score', 'g_mean']
    
    results_df = results_df[columns_order]
    

    float_columns = ['auc', 'accuracy', 'pr_auc','precision', 'recall', 'f1_score', 'g_mean']
    
    results_df[float_columns] = results_df[float_columns].round(4)
    
    os.makedirs('Finance_results/Test', exist_ok=True)
    
    csv_path = 'Finance_results/Test/testing_results.csv'
    results_df.to_csv(csv_path, index=False, encoding='utf-8-sig')
    print(f"\ntest results save to : {csv_path}")
    
 
    print("\n" + "="*100)
    print("testing results:")
    print("="*100)
    print(f"threoshold: {results['threshold']:.4f}")
    print(f"AUC: {results['auc']:.4f}")
    print(f"PR-AUC: {results['pr_auc']:.4f}")
    print(f"Accuracy: {results['accuracy']:.4f}")
    print(f"Precision: {results['precision']:.4f}")
    print(f"Recall: {results['recall']:.4f}")
    print(f"F1-score: {results['f1_score']:.4f}")
    print(f"G-Mean: {results['g_mean']:.4f}")
    print(f"real anomaly ratio: {results['actual_anomaly_rate']:.4%}")
    print(f"prediction anomaly ratio: {results['predicted_anomaly_rate']:.4%}")
    print(f"sample: {results['n_samples']}")
    print("="*100)

def main():
    def set_seed(seed=42):
        import random
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)

    set_seed(42)

    print("\nloading data...")
    processor = DataProcessor()
    processed_data = processor.load_and_preprocess_data()

    if processed_data is None:
        print("Data loading failed, exiting program")
        return

    _, _, _, _, X_test, y_test = processed_data

    y_test = ensure_numpy_array(y_test)
    

    print("data shape:")
    print(f"  testing data: X={X_test.shape}, y={y_test.shape}, anomaly ratio={np.mean(y_test):.4%}")

    model_path = 'Finance_results/dEADF_model_finance.pth'

    if not os.path.exists(model_path):
        print(f"Model file not found: {model_path}")
        print("Please ensure the trained model exists in the Finance_results directory.")
        return

    model = load_trained_model(model_path)

    if model is None:
        print("Failed to load model, exiting...")
        return

    print("\n" + "="*100)
    print("testing the model...")
    print("="*100)
    

    goe_scores, mlnn_scores, min_length = compute_scores(model, X_test)
    

    dual_scores = compute_dual_scores_fused(goe_scores, mlnn_scores)
    
    print("\n3. evaluating...")
    results = evaluate_with_percentile_threshold(dual_scores, y_test, percentile=99.9)
    
    print("\n4. save to testing results...")
    save_test_results(results)
    
    print("\n" + "="*100)
    print("finish testing")
    print("="*100)
    print("test results save to : Finance_results/Test/testing_results.csv")
    print("="*100)

    return results
    
if __name__ == "__main__":
    os.makedirs('Finance_results/Test/', exist_ok=True)
    
    results = main()