import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import warnings
warnings.filterwarnings('ignore')

class DataProcessor:
    """Data Processor"""
    
    def __init__(self, random_state=42):
        self.scaler = StandardScaler()
        self.attribute_columns = None
        self.random_state = random_state
        
    def load_and_preprocess_data(self):
        """
        Load and preprocess CreditCard.csv data
        Returns: Processed training set, validation set, test set and corresponding labels
        """
        try:
            # Read CreditCard.csv data
            print("Loading CreditCard data...")
            data = pd.read_csv('./DataSample/CreditCard.csv')
            
            # Display basic data information
            print(f"Original data shape: {data.shape}")
            print("Data column names:", data.columns.tolist())
            
            # Select valid feature columns: V1-V28 and Amount
            feature_columns = [f'V{i}' for i in range(1, 29)] + ['Amount']
            print(f"Feature columns used: {feature_columns}")
            
            # Extract features and labels
            X = data[feature_columns].copy()
            y = data['Class'].copy()
            
            # Check and handle missing values
            print("\n=== Missing Value Check ===")
            print(f"Number of NaN in feature data: {X.isna().sum().sum()}")
            print(f"Number of NaN in label data: {y.isna().sum()}")
            
            # Delete rows containing NaN values
            nan_mask = X.isna().any(axis=1) | y.isna()
            if nan_mask.any():
                print(f"Deleting rows containing NaN values: {nan_mask.sum()}")
                X = X[~nan_mask].copy()
                y = y[~nan_mask].copy()
                print(f"Data shape after cleaning: {X.shape}")
            
            # Check data distribution
            print(f"\nLabel distribution:\n{y.value_counts()}")
            print(f"Fraud transaction ratio: {y.mean():.5f}")
            
        except FileNotFoundError as e:
            print(f"File not found: {e}")
            return None
        except Exception as e:
            print(f"Error reading data: {e}")
            return None
        
        # Set attribute columns
        self.attribute_columns = feature_columns
        
        print(f"Found {len(self.attribute_columns)} attribute columns")
        print(f"Feature data shape: {X.shape}")
        print(f"Label data shape: {y.shape}")
        
        # Split dataset: 70% training, 20% validation, 10% testing
        print("\nSplitting dataset into training set(70%), validation set(20%), test set(10%)...")
        
        # Step 1: First split into training set(70%) and temporary set(30%)
        X_train, X_temp, y_train, y_temp = train_test_split(
            X, y, 
            test_size=0.30,  # Temporary set accounts for 30%
            random_state=self.random_state,
            stratify=y  # Maintain class ratio
        )
        
        # Step 2: Split temporary set(30%) into validation set(20%) and test set(10%)
        # Note: Splitting 10% from 30% is equivalent to 10% of total data, so test_size=10%/30%=0.3333
        X_val, X_test, y_val, y_test = train_test_split(
            X_temp, y_temp,
            test_size=1/3,  # Test set accounts for 1/3 of temporary set, i.e., 10% of total data
            random_state=self.random_state,
            stratify=y_temp  # Continue maintaining class ratio
        )
        
        print(f"Training set shape: {X_train.shape}, Validation set shape: {X_val.shape}, Test set shape: {X_test.shape}")
        
        # Data preprocessing - Standardization
        print("Performing data standardization...")
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_val_scaled = self.scaler.transform(X_val)
        X_test_scaled = self.scaler.transform(X_test)
        
        print(f"Training set shape: {X_train_scaled.shape}, Label shape: {y_train.shape}")
        print(f"Validation set shape: {X_val_scaled.shape}, Label shape: {y_val.shape}")
        print(f"Test set shape: {X_test_scaled.shape}, Label shape: {y_test.shape}")
        
        # Check data quality
        self._check_data_quality(X_train_scaled, X_val_scaled, X_test_scaled, y_train, y_val, y_test)

        # Return 6 values: features and labels of training set, validation set, test set
        return X_train_scaled, y_train, X_val_scaled, y_val, X_test_scaled, y_test
    
    def _check_data_quality(self, X_train, X_val, X_test, y_train, y_val, y_test):
        """Check data quality"""
        print("\n=== Data Quality Check ===")
        print(f"Training set - NaN count: {np.isnan(X_train).sum()}, Inf count: {np.isinf(X_train).sum()}")
        print(f"Validation set - NaN count: {np.isnan(X_val).sum()}, Inf count: {np.isinf(X_val).sum()}")
        print(f"Test set - NaN count: {np.isnan(X_test).sum()}, Inf count: {np.isinf(X_test).sum()}")
        
        # Check label distribution
        unique_train, counts_train = np.unique(y_train, return_counts=True)
        unique_val, counts_val = np.unique(y_val, return_counts=True)
        unique_test, counts_test = np.unique(y_test, return_counts=True)
        
        print(f"Training set label distribution: {dict(zip(unique_train, counts_train))}")
        print(f"Validation set label distribution: {dict(zip(unique_val, counts_val))}")
        print(f"Test set label distribution: {dict(zip(unique_test, counts_test))}")
        
        # Check feature statistics
        print(f"Training set feature range: [{X_train.min():.4f}, {X_train.max():.4f}]")
        print(f"Training set feature mean: {X_train.mean():.4f} ± {X_train.std():.4f}")
        
        # Check class imbalance
        train_fraud_ratio = np.mean(y_train)
        val_fraud_ratio = np.mean(y_val)
        test_fraud_ratio = np.mean(y_test)
        
        print(f"Training set fraud ratio: {train_fraud_ratio:.5f}")
        print(f"Validation set fraud ratio: {val_fraud_ratio:.5f}")
        print(f"Test set fraud ratio: {test_fraud_ratio:.5f}")
        
        # Calculate proportions of each dataset
        total_samples = len(X_train) + len(X_val) + len(X_test)
        train_ratio = len(X_train) / total_samples
        val_ratio = len(X_val) / total_samples
        test_ratio = len(X_test) / total_samples
        
        print(f"\nDataset split ratio:")
        print(f"Training set: {train_ratio:.1%} ({len(X_train)} samples)")
        print(f"Validation set: {val_ratio:.1%} ({len(X_val)} samples)")
        print(f"Test set: {test_ratio:.1%} ({len(X_test)} samples)")

# Main execution section
if __name__ == "__main__":
    # Create data processor, set random seed
    processor = DataProcessor(random_state=42)
    
    # Load and preprocess data
    processed_data = processor.load_and_preprocess_data()
    
    if processed_data is not None:
        X_train, y_train, X_val, y_val, X_test, y_test = processed_data
        print("\nData preprocessing completed!")
        print(f"Final data shape:")
        print(f"X_train: {X_train.shape}, y_train: {y_train.shape}")
        print(f"X_val: {X_val.shape}, y_val: {y_val.shape}")
        print(f"X_test: {X_test.shape}, y_test: {y_test.shape}")
    else:
        print("Data preprocessing failed!")