# -*- coding: utf-8 -*-
"""
Dynamic Adaptive Thresholding for Dual-Engine Anomaly Detection Framework
 
"""
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from sklearn.metrics import roc_auc_score
import time
import os
import warnings
warnings.filterwarnings('ignore')
import random
import pandas as pd
import csv
from scipy.spatial.distance import cdist
from scipy.interpolate import NearestNDInterpolator
from scipy.signal import savgol_filter
from scipy import stats
import traceback
import json
from datetime import datetime

# Set global parameters for Nature standards
plt.rcParams.update({
    'font.size': 12,
    'font.family': 'Arial',
    'axes.labelsize': 12,
    'axes.titlesize': 14,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'legend.fontsize': 10,
    'figure.dpi': 600,
    'savefig.dpi': 600,
    'savefig.format': 'png',
    'savefig.bbox': 'tight'
})

'''======================================================================================================='''
'''                                           Read dataset                       '''
from ReadCreditcardDataset import DataProcessor  


'''======================================================================================================='''
def calculate_gmean(y_true, y_pred):
    """Calculate G-mean"""
    cm = confusion_matrix(y_true, y_pred)
    if cm.shape == (2, 2):
        tn, fp, fn, tp = cm.ravel()
        specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
        sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0
        return np.sqrt(sensitivity * specificity)
    else:
        return 0.0
    
def ensure_numpy_array(data):
    """ensure input data for numpy """
    if isinstance(data, np.ndarray):
        return data
    elif hasattr(data, 'values'):  # pandas Series or DataFrame
        return data.values
    elif torch.is_tensor(data):
        return data.cpu().numpy()
    else:
        return np.array(data)
    
    
''' ########################    data process    ############# '''
class DataCleaner:
    """Data cleaning utility"""
    
    @staticmethod
    def clean_data(X, y=None):
        """Clean data by handling NaN and outliers"""
        X_clean = X.copy()
        nan_mask = np.isnan(X_clean)
        
        if np.any(nan_mask):
            col_means = np.nanmean(X_clean, axis=0)
            for i in range(X_clean.shape[1]):
                nan_indices = np.isnan(X_clean[:, i])
                X_clean[nan_indices, i] = col_means[i]
        
        inf_mask = np.isinf(X_clean)
        if np.any(inf_mask):
            X_clean[inf_mask] = 0
        
        if np.any(np.isnan(X_clean)) or np.any(np.isinf(X_clean)):
            X_clean = np.nan_to_num(X_clean, nan=0.0, posinf=0.0, neginf=0.0)
        
        if y is not None:
            y_clean = np.nan_to_num(y, nan=0.0)
            return X_clean, y_clean
        else:
            return X_clean
'''======================================================================================================='''        
        
        
        
        
'''=======================================================================================================''' 
"""                               dimension estimation based on Theorem 8 and  Corollary 8.1    """
    
class ImprovedDimensionEstimator:
    """Improved dimensionality estimator - fused version with Grassberger-Procaccia method"""
    
    @staticmethod
    def grassberger_procaccia(X, k=20):
        """Grassberger-Procaccia algorithm for correlation dimension"""
        try:
            from scipy.spatial.distance import cdist
            
            X = np.asarray(X)
            if len(X.shape) != 2:
                return 1
                
            n_samples = min(300, X.shape[0])
            indices = np.random.choice(X.shape[0], n_samples, replace=False)
            X_sampled = X[indices]
            X_normalized = (X_sampled - np.mean(X_sampled, axis=0)) / (np.std(X_sampled, axis=0) + 1e-8)
            
            dist_matrix = cdist(X_normalized, X_normalized)
            np.fill_diagonal(dist_matrix, np.inf)
            r_k = np.partition(dist_matrix, k, axis=1)[:, k]
            
            r_min, r_max = np.min(r_k), np.max(r_k)
            if r_min >= r_max:
                return 1
                
            r_range = np.logspace(np.log10(r_min), np.log10(r_max), 10)
            C_r = []
            
            for r in r_range:
                C_r.append(np.mean(r_k < r))
            
            C_r = np.array(C_r)
            mask = (C_r > 0) & (C_r < 1) & (~np.isnan(C_r)) & (~np.isinf(C_r))
            
            if np.sum(mask) < 3:
                return 1
            
            log_r = np.log(r_range[mask])
            log_C = np.log(C_r[mask])
            valid_mask = (~np.isinf(log_r)) & (~np.isinf(log_C)) & (~np.isnan(log_r)) & (~np.isnan(log_C))
            
            if np.sum(valid_mask) < 3:
                return 1
                
            log_r = log_r[valid_mask]
            log_C = log_C[valid_mask]
            slope = np.polyfit(log_r, log_C, 1)[0]
            intrinsic_dim = max(1, int(round(slope)))
            
            return min(intrinsic_dim, X.shape[1])
            
        except Exception:
            return 1
'''======================================================================================================='''        
        
        


'''======================================================================================================='''        
''' ########################    Dynamic Adaptive Threshold Calculation    ############# '''
"""Enhanced dynamic adaptive threshold strategy for data drift"""

class DynamicAdaptiveThreshold:
    """Dynamic adaptive threshold calculation for handling data drift"""
    
    def __init__(self, window_size=1000, base_percentile=99.0, adaptation_rate=0.1):
        """
        Initialize dynamic threshold calculator
        
        Parameters:
        window_size: Size of sliding window for statistics
        base_percentile: Base percentile for threshold calculation
        adaptation_rate: Rate of adaptation to new data (0-1)
        """
        self.window_size = window_size
        self.base_percentile = base_percentile
        self.adaptation_rate = adaptation_rate
        self.score_history = []
        self.threshold_history = []
        self.drift_detected_history = []
        self.confidence_history = []  
        self.current_threshold = None
        self.current_mean = None
        self.current_std = None
        self.current_skew = None
             
    def update(self, new_scores, detect_drift=True):
        """
        Update threshold with new scores
        
        Parameters:
        new_scores: New anomaly scores
        detect_drift: Whether to detect and adapt to drift
        """
        new_scores = np.array(new_scores).flatten()
        
        # Add new scores to history
        self.score_history.extend(new_scores.tolist())
        
        # Maintain window size
        if len(self.score_history) > self.window_size:
            self.score_history = self.score_history[-self.window_size:]
        
        if len(self.score_history) < 50:  # Minimum samples for reliable statistics
            return self.current_threshold if self.current_threshold is not None else 0.5
        
        scores_array = np.array(self.score_history)
        
        # Calculate statistics
        mean = np.mean(scores_array)
        std = np.std(scores_array)
        skew = stats.skew(scores_array) if len(scores_array) > 2 else 0
        
        if detect_drift:
            drift_detected = self._detect_drift(mean, std, skew)
            self.drift_detected_history.append(drift_detected)
            
            if drift_detected:
                # Adaptive adjustment for drift
                adjusted_percentile = self._adapt_to_drift(scores_array, mean, std, skew)
                threshold = np.percentile(scores_array, adjusted_percentile)
                print(f"Drift detected! Adjusted percentile: {adjusted_percentile:.2f}")
            else:
                # Normal operation
                threshold = np.percentile(scores_array, self.base_percentile)
        else:
            threshold = np.percentile(scores_array, self.base_percentile)
        
        # Apply smoothing if we have previous threshold
        if self.current_threshold is not None:
            threshold = (1 - self.adaptation_rate) * self.current_threshold + \
                       self.adaptation_rate * threshold
        
        # Update current values
        self.current_threshold = threshold
        self.current_mean = mean
        self.current_std = std
        self.current_skew = skew
        self.threshold_history.append(threshold)
        
        confidence = self.get_threshold_confidence()
        self.confidence_history.append(confidence)
        
        return threshold
    
    def _detect_drift(self, new_mean, new_std, new_skew):
        """Detect if data drift has occurred"""
        if self.current_mean is None or self.current_std is None:
            return False
        
        # Multiple drift detection criteria
        mean_change = abs(new_mean - self.current_mean) / (self.current_std + 1e-8)
        std_change = abs(new_std - self.current_std) / (self.current_std + 1e-8)
        
        # Statistical test for distribution change (simplified)
        drift_score = 0
        
        if mean_change > 1.0:  # Mean changed more than 1 std
            drift_score += 1
        
        if std_change > 0.5:  # Std changed more than 50%
            drift_score += 1
        
        if len(self.score_history) > 100:
            # Compare recent vs older statistics
            recent_scores = np.array(self.score_history[-100:])
            older_scores = np.array(self.score_history[-200:-100]) if len(self.score_history) >= 200 else recent_scores
            
            recent_mean = np.mean(recent_scores)
            recent_std = np.std(recent_scores)
            older_mean = np.mean(older_scores)
            older_std = np.std(older_scores)
            
            if abs(recent_mean - older_mean) > 0.5 * older_std:
                drift_score += 1
        
        return drift_score >= 2  # At least 2 indicators suggest drift
    
    def _adapt_to_drift(self, scores_array, mean, std, skew):
        """Adapt percentile based on drift characteristics"""
        adjusted_percentile = self.base_percentile
        
        # 1. Enhanced adjustment based on skewness
        if abs(skew) > 0.3:
            if skew > 0:  # Positive skew (long tail on right)
                adjusted_percentile += min(1.5, abs(skew) * 2.0)  # Increase more
            else:  # Negative skew
                adjusted_percentile -= min(1.0, abs(skew) * 1.5)
        
        # 2. Adjustment based on kurtosis (if there are many extreme values)
        if len(scores_array) > 10:
            from scipy import stats
            kurt = stats.kurtosis(scores_array)
            if kurt > 3:  # High kurtosis (heavy tails)
                adjusted_percentile += min(1.0, (kurt - 3) * 0.5)
            elif kurt < 2:  # Low kurtosis (light tails)
                adjusted_percentile -= min(0.5, (3 - kurt) * 0.3)
        
        # 3. Adjustment based on expected anomaly rate
        # Financial data typically has anomaly rate of 1-5%
        expected_anomaly_rate = 0.02  # Expected 2% anomaly rate
        current_high_score_ratio = np.mean(scores_array > np.percentile(scores_array, 95))
        
        if current_high_score_ratio > expected_anomaly_rate * 2:
            # Current high score ratio is too high, increase threshold
            adjusted_percentile += 0.5
        elif current_high_score_ratio < expected_anomaly_rate / 2:
            # Current high score ratio is too low, decrease threshold
            adjusted_percentile -= 0.5
        
        # Ensure threshold is within reasonable range
        adjusted_percentile = max(95.0, min(99.9, adjusted_percentile))
        
        return adjusted_percentile
    
    
    def get_threshold_confidence(self):
        """Get confidence level of current threshold"""
        if self.current_std is None or len(self.score_history) < 50:
            return 0.5
        
        # Confidence based on stability and sample size
        stability = 1.0 / (1.0 + self.current_std)  # Higher std = less confidence
        sample_sufficiency = min(1.0, len(self.score_history) / self.window_size)
        
        return stability * 0.6 + sample_sufficiency * 0.4
    

        
        
               
''' ########################    Advanced Dynamic Threshold Manager    ############# '''
"""Enhanced dynamic threshold manager with performance feedback and adaptive adjustment"""

class AdvancedDynamicThresholdManager:
    """Enhanced dynamic threshold manager supporting performance feedback and adaptive adjustment"""
    
    def __init__(self, window_size=1000, base_percentile=99.0, 
                 adaptation_rate=0.1, target_anomaly_rate=0.02):
        """
        Initialize advanced dynamic threshold manager
        
        Parameters:
        window_size: Sliding window size
        base_percentile: Base percentile
        adaptation_rate: Adaptation rate (0-1)
        target_anomaly_rate: Target anomaly rate
        """
        self.dynamic_thresholder = DynamicAdaptiveThreshold(
            window_size=window_size, 
            base_percentile=base_percentile, 
            adaptation_rate=adaptation_rate
        )
        self.target_anomaly_rate = target_anomaly_rate
        self.performance_history = []
        self.threshold_adjustment_factor = 1.0
        self.consecutive_low_performance = 0
        self.optimal_thresholds = []
        
    def update_with_feedback(self, scores, y_true=None, predictions=None):
        """
        Threshold update with feedback
        
        Parameters:
        scores: Anomaly scores
        y_true: True labels (if available)
        predictions: Model predictions (if true labels not available)
        
        Returns:
        Adjusted threshold
        """
        # Update base dynamic threshold
        base_threshold = self.dynamic_thresholder.update(scores)
        
        # Calculate statistics
        current_scores = np.array(scores).flatten()
        score_mean = np.mean(current_scores)
        score_std = np.std(current_scores)
        score_skew = stats.skew(current_scores) if len(current_scores) > 2 else 0
        
        # If true labels are available, perform performance evaluation and adjustment
        adjusted_threshold = base_threshold
        
        if y_true is not None and len(y_true) > 0:
            # Adjust y_true to match scores length
            y_true_adj = y_true[:len(current_scores)] if len(y_true) > len(current_scores) else y_true
            
            # Calculate performance at current threshold
            current_predictions = (current_scores > base_threshold).astype(int)
            if len(current_predictions) > len(y_true_adj):
                current_predictions = current_predictions[:len(y_true_adj)]
            elif len(current_predictions) < len(y_true_adj):
                y_true_adj = y_true_adj[:len(current_predictions)]
            
            current_f1 = f1_score(y_true_adj, current_predictions, zero_division=0)
            current_precision = precision_score(y_true_adj, current_predictions, zero_division=0)
            current_recall = recall_score(y_true_adj, current_predictions, zero_division=0)
            current_anomaly_rate = np.mean(current_predictions)
            
            # Store performance history
            performance_record = {
                'threshold': base_threshold,
                'f1': current_f1,
                'precision': current_precision,
                'recall': current_recall,
                'anomaly_rate': current_anomaly_rate,
                'time': len(self.performance_history),
                'score_mean': score_mean,
                'score_std': score_std,
                'score_skew': score_skew
            }
            self.performance_history.append(performance_record)
            
            # Find optimal threshold (if supervised signals are available)
            optimal_threshold = self._find_optimal_threshold(current_scores, y_true_adj)
            if optimal_threshold is not None:
                self.optimal_thresholds.append(optimal_threshold)
                # If there are multiple optimal thresholds in history, calculate average
                if len(self.optimal_thresholds) > 5:
                    optimal_avg = np.mean(self.optimal_thresholds[-5:])
                    # Incorporate optimal threshold information into adjustment
                    adjusted_threshold = 0.7 * base_threshold + 0.3 * optimal_avg
            
            # Adjust threshold factor based on performance
            if len(self.performance_history) > 10:
                recent_performance = self.performance_history[-10:]
                recent_f1 = np.mean([p['f1'] for p in recent_performance])
                recent_anomaly_rate = np.mean([p['anomaly_rate'] for p in recent_performance])
                
                # Performance evaluation
                if recent_f1 < 0.3:
                    self.consecutive_low_performance += 1
                else:
                    self.consecutive_low_performance = max(0, self.consecutive_low_performance - 1)
                
                # If consecutive low performance, perform aggressive adjustment
                if self.consecutive_low_performance > 5:
                    # Aggressive adjustment: recalculate based on statistical characteristics
                    adjusted_threshold = score_mean + 3.0 * score_std
                    print(f"Aggressive adjustment: detected consecutive low performance, threshold reset to {adjusted_threshold:.4f}")
                else:
                    # Normal adjustment: based on anomaly rate
                    if recent_anomaly_rate > self.target_anomaly_rate * 1.5:
                        # Anomaly rate too high, increase threshold
                        self.threshold_adjustment_factor *= 1.05
                    elif recent_anomaly_rate < self.target_anomaly_rate / 2:
                        # Anomaly rate too low, decrease threshold
                        self.threshold_adjustment_factor *= 0.95
                    
                    # Adjust based on score distribution
                    if score_skew > 0.5:
                        # Positive skew distribution, increase threshold to capture more anomalies
                        self.threshold_adjustment_factor *= 1.02
                    elif score_skew < -0.5:
                        # Negative skew distribution, decrease threshold
                        self.threshold_adjustment_factor *= 0.98
                    
                    # Limit adjustment range
                    self.threshold_adjustment_factor = max(0.7, min(1.3, self.threshold_adjustment_factor))
                    
                    # Apply adjustment
                    adjusted_threshold = base_threshold * self.threshold_adjustment_factor
                    
                    # Output adjustment information
                    if len(self.performance_history) % 20 == 0:
                        print(f"Threshold adjustment: base={base_threshold:.4f}, adjustment factor={self.threshold_adjustment_factor:.3f}, "
                              f"final={adjusted_threshold:.4f}, F1={current_f1:.3f}, anomaly rate={current_anomaly_rate:.3f}")
        
        # If no true labels but predictions are provided, perform simple adjustment
        elif predictions is not None and len(predictions) > 0:
            current_anomaly_rate = np.mean(predictions)
            
            # Simple adjustment based on predicted anomaly rate
            if current_anomaly_rate > self.target_anomaly_rate * 1.5:
                adjusted_threshold = base_threshold * 1.05
            elif current_anomaly_rate < self.target_anomaly_rate / 2:
                adjusted_threshold = base_threshold * 0.95
        
        # Apply smoothing (prevent sudden changes)
        if len(self.performance_history) > 1:
            last_threshold = self.performance_history[-1]['threshold']
            threshold_change = abs(adjusted_threshold - last_threshold)
            if threshold_change > 0.1:
                # Change too large, apply stronger smoothing
                adjusted_threshold = 0.3 * adjusted_threshold + 0.7 * last_threshold
        
        return adjusted_threshold
    
    
    def _find_optimal_threshold(self, scores, y_true):
        """Find supervised optimal threshold"""
        if len(scores) != len(y_true):
            return None
        
        try:
            # Prepare candidate thresholds
            score_range = np.max(scores) - np.min(scores)
            
            if score_range > 0.1:
                # Generate candidate thresholds
                if np.mean(y_true) < 0.01:  # Extremely low anomaly rate
                    candidates = np.percentile(scores, [99.0, 99.5, 99.7, 99.9])
                else:
                    candidates = np.linspace(np.percentile(scores, 80), 
                                           np.percentile(scores, 99.9), 20)
            else:
                candidates = np.linspace(np.min(scores), np.max(scores), 20)
            
            # Find optimal threshold
            best_threshold = None
            best_f1 = 0
            
            for threshold in candidates:
                predictions = (scores > threshold).astype(int)
                if np.sum(predictions) == 0:
                    continue
                f1 = f1_score(y_true, predictions, zero_division=0)
                if f1 > best_f1:
                    best_f1 = f1
                    best_threshold = threshold
            
            return best_threshold
        except Exception as e:
            print(f"Error finding optimal threshold: {e}")
            return None
    
    def get_performance_summary(self):
        """Get performance summary"""
        if not self.performance_history:
            return {"total_records": 0, "avg_f1": 0, "avg_anomaly_rate": 0}
        
        total_records = len(self.performance_history)
        recent_records = self.performance_history[-min(20, total_records):]
        
        avg_f1 = np.mean([r['f1'] for r in recent_records])
        avg_precision = np.mean([r['precision'] for r in recent_records])
        avg_recall = np.mean([r['recall'] for r in recent_records])
        avg_anomaly_rate = np.mean([r['anomaly_rate'] for r in recent_records])
        
        return {
            "total_records": total_records,
            "avg_f1": avg_f1,
            "avg_precision": avg_precision,
            "avg_recall": avg_recall,
            "avg_anomaly_rate": avg_anomaly_rate,
            "current_adjustment_factor": self.threshold_adjustment_factor,
            "target_anomaly_rate": self.target_anomaly_rate,
            "consecutive_low_performance": self.consecutive_low_performance
        }
    
    def plot_performance_history(self):
        """Plot performance history"""
        if len(self.performance_history) < 2:
            return
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        
        # 1. Threshold changes
        ax1 = axes[0, 0]
        thresholds = [p['threshold'] for p in self.performance_history]
        ax1.plot(thresholds, 'b-', linewidth=2, label='Threshold')
        ax1.set_xlabel('Update Step')
        ax1.set_ylabel('Threshold Value')
        ax1.set_title('Threshold Evolution')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # 2. F1 score changes
        ax2 = axes[0, 1]
        f1_scores = [p['f1'] for p in self.performance_history]
        ax2.plot(f1_scores, 'g-', linewidth=2, label='F1-Score')
        ax2.axhline(y=0.5, color='r', linestyle='--', label='Target (0.5)')
        ax2.set_xlabel('Update Step')
        ax2.set_ylabel('F1-Score')
        ax2.set_title('F1-Score Evolution')
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        
        # 3. Anomaly rate changes
        ax3 = axes[1, 0]
        anomaly_rates = [p['anomaly_rate'] for p in self.performance_history]
        ax3.plot(anomaly_rates, 'r-', linewidth=2, label='Anomaly Rate')
        ax3.axhline(y=self.target_anomaly_rate, color='b', linestyle='--', 
                   label=f'Target ({self.target_anomaly_rate})')
        ax3.set_xlabel('Update Step')
        ax3.set_ylabel('Anomaly Rate')
        ax3.set_title('Anomaly Rate Evolution')
        ax3.legend()
        ax3.grid(True, alpha=0.3)
        
        # 4. Score statistics
        ax4 = axes[1, 1]
        score_means = [p['score_mean'] for p in self.performance_history]
        score_stds = [p['score_std'] for p in self.performance_history]
        
        ax4.plot(score_means, 'b-', linewidth=2, label='Score Mean')
        ax4.plot(score_stds, 'g-', linewidth=2, label='Score Std')
        ax4.set_xlabel('Update Step')
        ax4.set_ylabel('Score Statistics')
        ax4.set_title('Score Statistics Evolution')
        ax4.legend()
        ax4.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig('CredictCard_results/advanced_threshold_performance.png', dpi=300, bbox_inches='tight')
        plt.show()
               
        
        
"""Enhanced Theorem 5-based threshold strategy with dynamic adaptation"""

class TheoremBasedThresholdDynamic:
    """Theorem 5-based threshold strategy with dynamic adaptation"""
    
    def __init__(self, window_size=500):
        self.dynamic_threshold_goe = DynamicAdaptiveThreshold(window_size=window_size)
        self.dynamic_threshold_mlnn = DynamicAdaptiveThreshold(window_size=window_size)
        self.dynamic_threshold_dual = DynamicAdaptiveThreshold(window_size=window_size)
        
    @staticmethod
    def enhanced_synergy_strategy(goe_scores, mlnn_scores, y_true=None, use_dynamic=True, 
                                  dynamic_thresholder=None):
        """Enhanced synergy strategy combining Theorem 5 and dynamic adaptation"""
        goe_norm = (goe_scores - np.min(goe_scores)) / (np.max(goe_scores) - np.min(goe_scores) + 1e-8)
        mlnn_norm = (mlnn_scores - np.min(mlnn_scores)) / (np.max(mlnn_scores) - np.min(mlnn_scores) + 1e-8)
        
        if np.max(goe_norm) < 0.01 and np.max(mlnn_norm) < 0.01:
            return 0.5, (goe_norm + mlnn_norm) / 2
        
        correlation = np.corrcoef(goe_norm, mlnn_norm)[0, 1]
        
        if abs(correlation) < 0.3:
            goe_weight = 0.55
            mlnn_weight = 0.45
        else:
            goe_weight = 0.7
            mlnn_weight = 0.3
        
        final_scores = goe_weight * goe_norm + mlnn_weight * mlnn_norm
        
        if y_true is not None:
            # Use supervised threshold optimization if labels available
            min_length = min(len(final_scores), len(y_true))
            final_scores = final_scores[:min_length]
            y_true = y_true[:min_length]
            
            best_threshold = 0.5
            best_f1 = 0
            
            if np.mean(y_true) < 0.01:
                thresholds = np.percentile(final_scores, [99.0, 99.5, 99.8, 99.9])
            else:
                thresholds = np.linspace(np.percentile(final_scores, 80), 
                                       np.percentile(final_scores, 99.9), 20)
            
            for threshold in thresholds:
                predictions = (final_scores > threshold).astype(int)
                if np.sum(predictions) == 0:
                    continue
                f1 = f1_score(y_true, predictions, zero_division=0)
                if f1 > best_f1:
                    best_f1 = f1
                    best_threshold = threshold
            
            print(f"Supervised optimal threshold: {best_threshold:.4f}, Best F1: {best_f1:.4f}")
            
            # Update dynamic thresholder with supervised result
            if dynamic_thresholder is not None:
                dynamic_thresholder.update([best_threshold])
            
            return best_threshold, final_scores
        else:
            # Unsupervised threshold selection
            if use_dynamic and dynamic_thresholder is not None:
                # Use dynamic thresholding
                threshold = dynamic_thresholder.update(final_scores)
                print(f"Dynamic adaptive threshold: {threshold:.4f}, "
                      f"Confidence: {dynamic_thresholder.get_threshold_confidence():.3f}")
            else:
                # Fallback to statistical threshold
                statistical_threshold = np.percentile(final_scores, 99)
                threshold = statistical_threshold
                print(f"Statistical threshold: {threshold:.4f}")
            
            return threshold, final_scores
    
    def adaptive_fusion_strategy_dynamic(self, goe_scores, mlnn_scores, y_true=None):
        """Dynamic fusion strategy with separate threshold adaptation per engine"""
        # Normalize scores
        goe_norm = (goe_scores - np.min(goe_scores)) / (np.max(goe_scores) - np.min(goe_scores) + 1e-8)
        mlnn_norm = (mlnn_scores - np.min(mlnn_scores)) / (np.max(mlnn_scores) - np.min(mlnn_scores) + 1e-8)
        
        # Update individual engine thresholds
        goe_threshold = self.dynamic_threshold_goe.update(goe_norm)
        mlnn_threshold = self.dynamic_threshold_mlnn.update(mlnn_norm)
        
        print(f"GOE dynamic threshold: {goe_threshold:.4f}, "
              f"MLNN dynamic threshold: {mlnn_threshold:.4f}")
        
        # Calculate confidence-weighted fusion
        goe_confidence = self.dynamic_threshold_goe.get_threshold_confidence()
        mlnn_confidence = self.dynamic_threshold_mlnn.get_threshold_confidence()
        
        # Dynamic weight adjustment based on confidence
        total_confidence = goe_confidence + mlnn_confidence + 1e-8
        goe_weight = goe_confidence / total_confidence
        mlnn_weight = mlnn_confidence / total_confidence
        
        print(f"GOE confidence: {goe_confidence:.3f}, MLNN confidence: {mlnn_confidence:.3f}")
        
        # Fuse scores
        final_scores = goe_weight * goe_norm + mlnn_weight * mlnn_norm
        
        # Update dual threshold
        dual_threshold = self.dynamic_threshold_dual.update(final_scores)
        
        return dual_threshold, final_scores
'''======================================================================================================='''
        
        
        

'''======================================================================================================='''        
''' ########################    GOE Engine    ############# '''
"""GOE macro-statistical engine"""
        
class GOEEngine:
    """GOE macro-statistical engine"""
    
    def __init__(self, perturbation_strength=0.1):
        self.perturbation_strength = perturbation_strength
        self.eigenvectors = None
        self.eigenvalues = None
        self.reference_mean = None
        self.reference_cov = None
        self.projection_basis = None
        self.data_covariance = None
        self.regularization_epsilon = 1e-4
        self.mahalanobis_min = 1e-8
        np.random.seed(42)
        
        
    def compute_boundary_scores(self, X):
        """Enhanced boundary-sensitive score calculation - optimized for financial data"""
        X_goe = self.transform(X)
        
        if self.reference_mean is None or self.reference_cov is None:
            raise ValueError("GOE engine are not trained")
        
        ''' Mahalanobis distance'''
        diff = X_goe - self.reference_mean
        try:
            cov_inv = np.linalg.inv(self.reference_cov + np.eye(self.reference_cov.shape[0]) * 1e-6)
            mahalanobis_dist = np.sum(diff @ cov_inv * diff, axis=1)
        except np.linalg.LinAlgError:
            ''' If matrix is not invertible, use pseudo-inverse'''
            cov_pinv = np.linalg.pinv(self.reference_cov)
            mahalanobis_dist = np.sum(diff @ cov_pinv * diff, axis=1)
        
        ''' ========== Enhanced financial data boundary detection =========='''
        ''' 1. Multi-scale local density analysis '''
        n_samples = min(2000, X_goe.shape[0])
        if n_samples < 50:
            return mahalanobis_dist
        
        indices = np.random.choice(X_goe.shape[0], n_samples, replace=False)
        X_sampled = X_goe[indices]
        
        ''' Calculate local density using multiple k values'''
        local_density_multi = []
        for k in [5, 10, 20]:
            dist_matrix = cdist(X_sampled, X_sampled)
            np.fill_diagonal(dist_matrix, np.inf)
            kth_dist = np.partition(dist_matrix, k, axis=1)[:, k]
            local_density = 1.0 / (kth_dist + 1e-8)
            local_density_multi.append(local_density)
            
        
        ''' Combine multi-scale densities '''
        local_density_combined = np.mean(local_density_multi, axis=0)
        
        '''# 2. Directional anomaly detection (for multidimensional correlations in financial data)'''
        if hasattr(self, 'reference_cov'):
            try:
                ''' Calculate anomaly degree in principal component directions'''
                eigvals, eigvecs = np.linalg.eigh(self.reference_cov)
                ''' Select main eigen directions'''
                top_k = min(10, eigvecs.shape[1])
                ''' Eigenvectors corresponding to largest eigenvalues'''
                principal_dirs = eigvecs[:, -top_k:]   
                
                ''' Projection distance in main directions '''
                proj_dist = np.zeros((X_sampled.shape[0], top_k))
                for i in range(top_k):
                    proj = X_sampled @ principal_dirs[:, i]
                    proj_dist[:, i] = (proj - np.mean(proj)) ** 2 / (np.var(proj) + 1e-8)
                
                directional_score = np.mean(proj_dist, axis=1)
            except:
                directional_score = np.ones(X_sampled.shape[0])
        else:
            directional_score = np.ones(X_sampled.shape[0])
        

     
        ''' Interpolate local density '''
        interpolator_density = NearestNDInterpolator(X_sampled, local_density_combined)
        all_local_density = interpolator_density(X_goe)
        
        ''' Interpolate directional anomaly scores '''
        if hasattr(self, 'reference_cov'):
            interpolator_directional = NearestNDInterpolator(X_sampled, directional_score)
            all_directional = interpolator_directional(X_goe)
        else:
            all_directional = np.ones(len(X_goe))
        
        ''' ========== Boundary score calculation for financial data ========== '''
        if np.max(mahalanobis_dist) - np.min(mahalanobis_dist) > 1e-8:
            mahalanobis_norm = (mahalanobis_dist - np.min(mahalanobis_dist)) / (np.max(mahalanobis_dist) - np.min(mahalanobis_dist))
        else:
            mahalanobis_norm = mahalanobis_dist * 0
        
        if np.max(all_local_density) - np.min(all_local_density) > 1e-8:
            density_norm = (all_local_density - np.min(all_local_density)) / (np.max(all_local_density) - np.min(all_local_density))
        else:
            density_norm = all_local_density * 0
        
        if np.max(all_directional) - np.min(all_directional) > 1e-8:
            directional_norm = (all_directional - np.min(all_directional)) / (np.max(all_directional) - np.min(all_directional))
        else:
            directional_norm = all_directional * 0
        
        ''' Financial data boundary score = f(distance, density, direction) '''
        ''' Boundary samples: medium distance * (1-density) * directional anomaly '''
        boundary_scores = (mahalanobis_norm * 0.4 + (1 - density_norm) * 0.3 + directional_norm * 0.3)
        
        ''' Enhance scores in boundary regions '''
        ''' Give higher boundary scores to medium score regions (0.3-0.7) '''
        boundary_scores = boundary_scores * (1 + 0.5 * np.exp(-((boundary_scores - 0.5) ** 2) / 0.1))
        
        ''' Normalize to [0, 1] '''
        if np.max(boundary_scores) - np.min(boundary_scores) > 1e-8:
            boundary_scores = (boundary_scores - np.min(boundary_scores)) / (np.max(boundary_scores) - np.min(boundary_scores))
        
        return boundary_scores
    

    def get_boundary_samples(self, X, boundary_ratio=0.1):
        """identify boundary samples"""
        boundary_scores = self.compute_boundary_scores(X)
        threshold = np.percentile(boundary_scores, 100 * (1 - boundary_ratio))
        boundary_mask = boundary_scores > threshold
        return boundary_mask, boundary_scores
    
        
    def fit(self, X):
        """Train GOE engine with data-aware perturbation (Theorem 3)"""
        print("Training GOE macro-statistical engine...")
        
        X_clean = DataCleaner.clean_data(X)
        covariance_matrix = np.cov(X_clean.T)
        n_features = covariance_matrix.shape[0]
        
        self.data_covariance = covariance_matrix
        U_goe = self._generate_goe_basis_enhanced(n_features)
        
        G = self._generate_perturbation_matrix(n_features)
        perturbed_covariance = covariance_matrix + self.perturbation_strength * G
        
        eigenvalues, eigenvectors = np.linalg.eigh(perturbed_covariance)
        optimal_dim = self._select_optimal_dimension_enhanced(eigenvalues, X_clean.shape[0], X_clean)
        
        idx = np.argsort(eigenvalues)[::-1][:optimal_dim]
        self.projection_basis = eigenvectors[:, idx]
        self.eigenvalues = eigenvalues[idx]
        
        X_goe = self.transform(X_clean)
        self.reference_mean = np.mean(X_goe, axis=0)
        self.reference_cov = self._compute_regularized_covariance(X_goe)
        
        print(f"GOE engine training completed, selected dimension: {optimal_dim}")
        return self
    
    
    def transform(self, X):
        """Project data to GOE space"""
        if self.projection_basis is None:
            raise ValueError("GOE engine not trained")
        
        X_clean = DataCleaner.clean_data(X)
        return X_clean @ self.projection_basis
    
    
    def compute_anomaly_scores(self, X):
        """Compute Mahalanobis distance anomaly scores"""
        X_goe = self.transform(X)
        
        if self.reference_mean is None or self.reference_cov is None:
            raise ValueError("GOE engine not trained")
        
        diff = X_goe - self.reference_mean
        cov = self.reference_cov.copy()
        
        try:
            L = np.linalg.cholesky(cov)
            y = np.linalg.solve(L, diff.T)
            mahalanobis_dist = np.sum(y * y, axis=0)
            mahalanobis_dist = np.maximum(mahalanobis_dist, self.mahalanobis_min)
        except np.linalg.LinAlgError:
            U, s, Vt = np.linalg.svd(cov, full_matrices=False)
            s_inv = np.zeros_like(s)
            threshold = np.max(s) * 1e-12
            mask = s > threshold
            s_inv[mask] = 1.0 / s[mask]
            cov_pinv = Vt.T @ np.diag(s_inv) @ U.T
            mahalanobis_dist = np.sum(diff @ cov_pinv * diff, axis=1)
            mahalanobis_dist = np.maximum(mahalanobis_dist, self.mahalanobis_min)
        
        return mahalanobis_dist
    
    
    def _compute_regularized_covariance(self, X):
        """Compute regularized covariance matrix"""
        cov = np.cov(X.T)
        cond_number = np.linalg.cond(cov)
        if cond_number > 1e10:
            epsilon = 1e-6 * np.trace(cov) / cov.shape[0]
            cov += epsilon * np.eye(cov.shape[0])
        return cov
    
    
    def _generate_goe_basis_enhanced(self, n):
        """Enhanced GOE basis generation with data-aware Cholesky method"""
        try:
            G_base = np.random.normal(0, 1, (n, n))
            G_symmetric = (G_base + G_base.T) / 2
            
            if hasattr(self, 'data_covariance') and self.data_covariance is not None:
                try:
                    cov_eigenvalues = np.linalg.eigvalsh(self.data_covariance)
                    scaling_factor = np.sqrt(np.abs(cov_eigenvalues) + 1e-8)
                    mean_scaling = np.mean(scaling_factor)
                    G_data_aware = G_symmetric * mean_scaling / np.sqrt(n)
                except:
                    G_data_aware = G_symmetric / np.sqrt(n)
            else:
                G_data_aware = G_symmetric / np.sqrt(n)
            
            try:
                if hasattr(self, 'data_covariance') and self.data_covariance is not None:
                    epsilon = 1e-6 * np.trace(self.data_covariance) / n
                    cov_regularized = self.data_covariance + epsilon * np.eye(n)
                    L = np.linalg.cholesky(cov_regularized)
                    Z = np.random.normal(0, 1/np.sqrt(n), (n, n))
                    G_cholesky = L @ Z @ L.T
                    G_cholesky = (G_cholesky + G_cholesky.T) / 2
                    alpha = 0.7
                    G_combined = alpha * G_data_aware + (1 - alpha) * G_cholesky
                    _, U = np.linalg.eigh(G_combined)
                    return U
            except Exception:
                pass
            
            _, U = np.linalg.eigh(G_data_aware)
            return U
            
        except Exception:
            G_standard = np.random.normal(0, 1/np.sqrt(n), (n, n))
            G_standard = (G_standard + G_standard.T) / 2
            _, U = np.linalg.eigh(G_standard)
            return U
        
    
    def _generate_perturbation_matrix(self, n):
        """Generate data-aware perturbation matrix"""
        perturbation = np.random.normal(0, 1/np.sqrt(n), (n, n))
        return (perturbation + perturbation.T) / 2
    
    
    def _select_optimal_dimension_enhanced(self, eigenvalues, n_samples, X_original=None):
        """Enhanced optimal dimension selection"""
        intrinsic_dim = self._estimate_intrinsic_dimension_ensemble_enhanced(eigenvalues, X_original)
        n_features = eigenvalues.shape[0]
        optimal_dim = int((intrinsic_dim**0.7) * (np.log(n_samples)**0.3))
        return max(10, min(optimal_dim, n_features))
    
    
    def _estimate_intrinsic_dimension_ensemble_enhanced(self, eigenvalues, X=None):
        """Enhanced ensemble dimensionality estimation"""
        estimators = []
        
        if eigenvalues is not None and len(eigenvalues) > 1:
            try:
                eigenvalues_sorted = np.sort(eigenvalues)[::-1]
                cumulative_variance = np.cumsum(eigenvalues_sorted) / np.sum(eigenvalues_sorted)
                dim1 = np.argmax(cumulative_variance >= 0.95) + 1
                estimators.append(dim1)
            except Exception:
                dim1 = max(50, len(eigenvalues) // 3)
                estimators.append(dim1)
        
        if X is not None and X.shape[0] > 100:
            dim2 = ImprovedDimensionEstimator.grassberger_procaccia(X)
            estimators.append(dim2)
        
        if not estimators:
            return 50
        
        intrinsic_dim = int(np.median(estimators))
        return max(10, intrinsic_dim)
'''======================================================================================================='''
    
    


'''======================================================================================================='''    
''' ########################    MLNN Engines    ############# '''
"""             MLNN micro- dynamic engine             """

class LTCUnit(nn.Module):
    """LTC unit implementing ODE-driven network"""
    
    def __init__(self, input_size, hidden_size, dt=0.1):
        super(LTCUnit, self).__init__()
        self.hidden_size = hidden_size
        self.dt = dt
        self.time_constant = nn.Parameter(torch.randn(hidden_size) * 0.1 + 1.0)
        self.W_rec = nn.Parameter(torch.randn(hidden_size, hidden_size) * 0.1)
        self.W_in = nn.Parameter(torch.randn(input_size, hidden_size) * 0.1)
        self.bias = nn.Parameter(torch.zeros(hidden_size))
        self.activation = nn.Tanh()
        
    
    def forward(self, x):
        """Forward pass using Euler method for ODE solving"""
        batch_size = x.size(1)
        h = torch.zeros(batch_size, self.hidden_size, device=x.device)
        hidden_states = []
        
        for t in range(x.size(0)):
            input_term = x[t] @ self.W_in
            recurrent_term = h @ self.W_rec
            activation_term = self.activation(h)
            dh_dt = -h / torch.exp(self.time_constant) + recurrent_term * activation_term + input_term + self.bias
            h = h + self.dt * dh_dt
            hidden_states.append(h)
        
        return torch.stack(hidden_states)
    

class MLNNEngine(nn.Module):
    """MLNN micro-dynamic engine with multi-granularity architecture"""
    
    def __init__(self, input_size, fine_grained_size=32, coarse_grained_size=32):  #默认32,32 金融，  16 信用卡 协同改进  --0.01 16好于32
        super(MLNNEngine, self).__init__()
        
        nhead = 4              
        self.transformer_input_size = self._calculate_adjusted_dimension(input_size, nhead)
        
        if self.transformer_input_size != input_size:
            self.input_adjustment = nn.Linear(input_size, self.transformer_input_size)
        else:
            self.input_adjustment = nn.Identity()
        
        self.ltc_units = nn.ModuleList([
            LTCUnit(self.transformer_input_size, fine_grained_size // 2) for _ in range(2)
        ])
        
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=self.transformer_input_size, 
            nhead=nhead,  
            dim_feedforward=64,
            batch_first=True
        )
        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=2)
        
        self.output_size = fine_grained_size + coarse_grained_size
        self.attention_context = nn.Parameter(torch.randn(self.output_size))
        self.projection = nn.Linear(2 * self.transformer_input_size, coarse_grained_size)
        self.final_projection = nn.Linear(self.output_size, 1)
        
        self.fine_grained_size = fine_grained_size
        self.coarse_grained_size = coarse_grained_size
        
        ''' boundary-aware module'''
        self.boundary_detector = nn.Sequential(
            nn.Linear(self.output_size, 16),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(16, 1),
            nn.Sigmoid()
        )
        
        self.boundary_weight = nn.Parameter(torch.tensor(0.5))
        ''' output layer: output deterministic score (0-1)'''
        self.final_projection = nn.Linear(self.output_size, 1)
        ''' Use sigmoid to ensure output between 0-1'''
        self.sigmoid = nn.Sigmoid()
          
        self.financial_feature_extractor = nn.Sequential(
            nn.Linear(self.output_size, 64),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(64, 32),
            nn.BatchNorm1d(32),
            nn.ReLU(),
            nn.Dropout(0.2)
        )
        
        ''' Financial data specific extractor '''
        self.financial_output = nn.Sequential(
            nn.Linear(32, 16),
            nn.ReLU(),
            nn.Linear(16, 1),
            nn.Sigmoid()
        )
        
        self.training_epoch = 0
        
               
    def _calculate_adjusted_dimension(self, input_size, nhead):
        """Calculate adjusted dimension divisible by nhead"""
        if input_size % nhead == 0:
            return input_size
        
        candidate1 = ((input_size + nhead - 1) // nhead) * nhead
        candidate2 = (input_size // nhead) * nhead
        
        if abs(candidate1 - input_size) <= abs(candidate2 - input_size):
            return candidate1
        else:
            return candidate2 if candidate2 >= nhead else nhead
    
             
    def forward(self, x):
        """Forward pass """
        x = torch.nan_to_num(x, nan=0.0)
        x_adjusted = self.input_adjustment(x)
        x_transposed = x_adjusted.transpose(0, 1)
        
        fine_features = []
        for ltc_unit in self.ltc_units:
            ltc_output = ltc_unit(x_transposed)
            final_state = ltc_output[-1]
            fine_features.append(final_state)
        
        fine_combined = torch.cat(fine_features, dim=1)
        coarse_features = self._coarse_grained_processing(x_adjusted)
        fused_features = self._multi_granularity_fusion(fine_combined, coarse_features)
        
        ''' ========== Financial data specific feature extraction ========== '''
        financial_features = self.financial_feature_extractor(fused_features)
        
        if self.training and hasattr(self, 'training_epoch'):
            noise_scale = max(0.01, 0.05 * (1.0 - self.training_epoch / 100.0))
            noise = torch.randn_like(financial_features) * noise_scale
            financial_features = financial_features + noise
        
        output = self.financial_output(financial_features)
        
        return output.squeeze(-1)
        
           
    def extract_features(self, x):
        """Extract intermediate features for diagnostics"""
        with torch.no_grad():
            output = self.forward(x)
            return output.unsqueeze(-1)
        
    
    def _coarse_grained_processing(self, x):
        """Coarse-grained processing with multi-scale downsampling"""
        batch_size, seq_len, input_size = x.shape
        scales = [3, 6]
        scale_features = []
        
        for scale in scales:
            if seq_len >= scale:
                downsampled = self._temporal_downsample(x, scale)
                transformer_output = self.transformer_encoder(downsampled)
                scale_rep = transformer_output.mean(dim=1)
                scale_features.append(scale_rep)
            else:
                scale_rep = torch.zeros(batch_size, input_size, device=x.device)
                scale_features.append(scale_rep)
        
        while len(scale_features) < 2:
            scale_features.append(torch.zeros(batch_size, input_size, device=x.device))
        
        coarse_combined = torch.cat(scale_features, dim=1)
        expected_projection_input = 2 * self.transformer_input_size
        
        if coarse_combined.shape[1] != expected_projection_input:
            if coarse_combined.shape[1] < expected_projection_input:
                padding = torch.zeros(batch_size, 
                                    expected_projection_input - coarse_combined.shape[1], 
                                    device=coarse_combined.device)
                coarse_combined = torch.cat([coarse_combined, padding], dim=1)
            else:
                coarse_combined = coarse_combined[:, :expected_projection_input]
        
        return self.projection(coarse_combined)
    
    
    def _temporal_downsample(self, x, scale):
        """Temporal downsampling for multi-scale processing"""
        batch_size, seq_len, input_size = x.shape
        
        if seq_len % scale != 0:
            pad_len = scale - (seq_len % scale)
            x = torch.cat([x, torch.zeros(batch_size, pad_len, input_size, device=x.device)], dim=1)
            seq_len += pad_len
        
        downsampled = x.reshape(batch_size, seq_len // scale, scale, input_size)
        return downsampled.mean(dim=2)
    
    
    def _multi_granularity_fusion(self, fine_features, coarse_features):
        """Multi-granularity fusion with attention mechanism"""
        if fine_features.shape[1] != self.fine_grained_size:
            if fine_features.shape[1] < self.fine_grained_size:
                padding = torch.zeros(fine_features.shape[0], 
                                    self.fine_grained_size - fine_features.shape[1], 
                                    device=fine_features.device)
                fine_features = torch.cat([fine_features, padding], dim=1)
            else:
                fine_features = fine_features[:, :self.fine_grained_size]
                
        if coarse_features.shape[1] != self.coarse_grained_size:
            if coarse_features.shape[1] < self.coarse_grained_size:
                padding = torch.zeros(coarse_features.shape[0], 
                                    self.coarse_grained_size - coarse_features.shape[1], 
                                    device=coarse_features.device)
                coarse_features = torch.cat([coarse_features, padding], dim=1)
            else:
                coarse_features = coarse_features[:, :self.coarse_grained_size]
        
        combined = torch.cat([fine_features, coarse_features], dim=1)
        
        if combined.shape[1] != self.attention_context.shape[0]:
            self.attention_context = nn.Parameter(torch.randn(combined.shape[1], device=combined.device))
        
        attention_weights = torch.softmax(combined @ self.attention_context, dim=0)
        fine_weighted = attention_weights.unsqueeze(1) * fine_features
        coarse_weighted = (1 - attention_weights.unsqueeze(1)) * coarse_features
        fused = torch.cat([fine_weighted, coarse_weighted], dim=1)
        
        if fused.shape[1] != self.output_size:
            if fused.shape[1] < self.output_size:
                padding = torch.zeros(fused.shape[0], 
                                    self.output_size - fused.shape[1], 
                                    device=fused.device)
                fused = torch.cat([fused, padding], dim=1)
            else:
                fused = fused[:, :self.output_size]
        
        return fused
'''=======================================================================================================''' 
    
    


'''======================================================================================================='''     
'''                 Dual-Engines  Synergy                         '''
"""Enhanced dual-engine based on Theorem 5, Theorem 6 and Theorem 7""" 

class EnhancedDualEngineSynergy:
    """Enhanced dual-engine fusion strategy with dynamic thresholding"""
    
    def __init__(self, window_size=500):
        self.dynamic_thresholder = DynamicAdaptiveThreshold(window_size=window_size)
        
    @staticmethod
    def adaptive_fusion_strategy(goe_scores, mlnn_certainty_scores, y_true=None, use_dynamic=True, 
                                 dynamic_thresholder=None):
        
        
        min_length = min(len(goe_scores), len(mlnn_certainty_scores))
        goe_scores = goe_scores[:min_length]
        mlnn_certainty = mlnn_certainty_scores[:min_length]
        
        # GOE Normalization: Considering the Low Anomaly Rate of Financial Data
        goe_percentiles = np.percentile(goe_scores, [ 95, 99, 99.5])
        # Normalize using the median to the 99.5 percentile
        goe_min = goe_percentiles[0]   
        goe_max = goe_percentiles[2]   
        goe_norm = (goe_scores - goe_min) / (goe_max - goe_min + 1e-8)
        goe_norm = np.clip(goe_norm, 0, 1)
        
        # MLNN normalization: MLNN's outputs may be concentrated in a certain range
        mlnn_min = np.percentile(mlnn_certainty, 10)   
        mlnn_max = np.percentile(mlnn_certainty, 90)   
        mlnn_norm = (mlnn_certainty - mlnn_min) / (mlnn_max - mlnn_min + 1e-8)
        mlnn_norm = np.clip(mlnn_norm, 0, 1)
        
        ''' ========== Calculate the confidence level of financial data ========== '''
        # GOE Confidence: Steepness based on Score Distribution
        goe_hist, goe_bins = np.histogram(goe_norm, bins=50)
        goe_entropy = -np.sum((goe_hist / np.sum(goe_hist)) * np.log(goe_hist / np.sum(goe_hist) + 1e-8))
        goe_confidence = 1.0 - min(goe_entropy / np.log(50), 1.0)  # Normalized to 0-1
        
        # MLNN Confidence: Output based Consistency
        mlnn_std = np.std(mlnn_norm)
        mlnn_confidence = 1.0 - min(mlnn_std * 5, 1.0)
        
        ''' ========== Specific fusion strategies for financial data: GOE led, MLNN assisted ========== '''
        dual_scores = np.zeros_like(goe_norm)
        
        # Calculate the boundedness of GOE
        goe_uncertainty = 2.0 * np.abs(goe_norm - 0.5)   
        
        for i in range(len(goe_norm)):
            g_score = goe_norm[i]
            m_score = mlnn_norm[i]
            g_uncertain = goe_uncertainty[i]
            
            # Rule 1: In cases where GOE is highly determined (GOE is more reliable for macro models in financial data)
            if g_uncertain < 0.3:   
                # If GOE is determined and the score is high, it is considered abnormal
                if g_score > 0.7:
                    # GOE considers it abnormal and gives high weight to GOE
                    weight = 0.8
                    dual_scores[i] = weight * g_score + (1 - weight) * m_score
                else:
                    # GOE considers it normal and gives it high weight
                    weight = 0.7
                    dual_scores[i] = weight * g_score + (1 - weight) * m_score
                    
            # Rule 2: GOE uncertainty (boundary samples)
            elif g_uncertain > 0.7:
                # In boundary samples, if MLNN has high confidence, trust MLNN
                if mlnn_confidence > 0.6 and np.abs(m_score - 0.5) > 0.3:
                    # MLNN has a clear judgment and high weights are given to MLNN
                    weight = 0.7   
                    dual_scores[i] = weight * m_score + (1 - weight) * g_score
                else:
                    # Both are uncertain, use a conservative average
                    dual_scores[i] = 0.5 * g_score + 0.5 * m_score
            
            # Rule 3: Medium uncertainty
            else:
                # Dynamically adjust weights based on score differences
                score_diff = np.abs(g_score - m_score)
                if score_diff < 0.2:   
                    dual_scores[i] = (g_score + m_score) / 2
                else:  
                    # Both are inconsistent, there is a tendency to trust GOE (more sensitive to statistical patterns)
                    if g_score > 0.6:   
                        weight = 0.6
                    else:
                        weight = 0.4
                    dual_scores[i] = weight * g_score + (1 - weight) * m_score
        
        # Enhance the discrimination of high scoring regions
        high_score_mask = dual_scores > 0.7
        if np.sum(high_score_mask) > 0:
            dual_scores[high_score_mask] = dual_scores[high_score_mask] ** 0.8  
        
        # Smooth processing  
        if len(dual_scores) > 10:
            # Use moving average smoothing
            smoothed = np.convolve(dual_scores, np.ones(5)/5, mode='same')
            dual_scores = 0.7 * dual_scores + 0.3 * smoothed
        
        # Dynamic threshold selection
        if y_true is not None and len(y_true) >= min_length:
            y_true_adj = y_true[:min_length]
            anomaly_rate = np.mean(y_true_adj)
            
            # New addition: Supervised threshold and dynamic threshold fusion
            # Calculate supervised optimal threshold
            if anomaly_rate < 0.005:   
                threshold_candidates = np.percentile(dual_scores, [99.0, 99.5, 99.7, 99.9])
            elif anomaly_rate < 0.015:  
                threshold_candidates = np.percentile(dual_scores, [98.0, 98.5, 99.0, 99.5])
            else:  
                threshold_candidates = np.percentile(dual_scores, [95.0, 96.0, 97.0, 98.0])
            
            # Select the optimal threshold
            best_supervised_threshold = 0.5
            best_f1 = 0
            supervised_candidates = []
            
            for threshold in threshold_candidates:
                predictions = (dual_scores > threshold).astype(int)
                if np.sum(predictions) == 0:
                    continue
                f1 = f1_score(y_true_adj, predictions, zero_division=0)
                if f1 > best_f1:
                    best_f1 = f1
                    best_supervised_threshold = threshold
                # Collect all candidate thresholds
                supervised_candidates.append(threshold)
            
            # If dynamic thresholder is available, perform fusion
            if use_dynamic and dynamic_thresholder is not None:
                # Get current dynamic threshold
                current_dynamic_threshold = dynamic_thresholder.current_threshold
                
                # Use EnhancedThresholdFusion for fusion
                fused_threshold = EnhancedThresholdFusion.fuse_thresholds(
                    dynamic_threshold=current_dynamic_threshold,
                    supervised_thresholds=supervised_candidates,
                    dynamic_confidence=dynamic_thresholder.get_threshold_confidence(),
                    n_samples=len(dual_scores),
                    supervised_f1=best_f1
                )
                
                # Update dynamic thresholder (update with fused threshold)
                dynamic_thresholder.update([fused_threshold])
                
                print(f"Threshold Fusion - Supervised: {best_supervised_threshold:.4f}, "
                      f"Dynamic: {current_dynamic_threshold:.4f}, "
                      f"Fused: {fused_threshold:.4f}, F1: {best_f1:.4f}")
                
                return fused_threshold, dual_scores
            else:
                # If no dynamic thresholder, directly use supervised threshold
                print(f"Supervised optimal threshold: {best_supervised_threshold:.4f}, "
                      f"F1: {best_f1:.4f}, anomaly ratio: {anomaly_rate:.4%}")
                return best_supervised_threshold, dual_scores
        else:
            # Dynamic adaptive threshold when unlabeled
            if use_dynamic and dynamic_thresholder is not None:
                threshold = dynamic_thresholder.update(dual_scores)
                print(f"Dynamic adaptive threshold: {threshold:.4f}, "
                      f"Confidence: {dynamic_thresholder.get_threshold_confidence():.3f}")
            else:
                # Fallback to financial data experience threshold
                threshold = np.percentile(dual_scores, 98.5)
                print(f"Statistical threshold: {threshold:.4f}")
            
            return threshold, dual_scores
        
        
        
'''                 Threshold Fusion Module                         '''
"""Enhanced threshold fusion strategy for combining supervised and dynamic thresholds"""

class EnhancedThresholdFusion:
    """Strategy for fusing supervised signals and unsupervised dynamic thresholds"""
    
    @staticmethod
    def fuse_thresholds(dynamic_threshold, supervised_thresholds, 
                       dynamic_confidence, n_samples, supervised_f1=None):
        """
        Fuse dynamic threshold and supervised threshold
        
        Parameters:
        dynamic_threshold: Dynamic threshold
        supervised_thresholds: List of multiple candidate thresholds obtained from supervised learning
        dynamic_confidence: Dynamic threshold confidence (0-1)
        n_samples: Number of samples
        supervised_f1: F1 score corresponding to supervised threshold (if available)
        """
        
        if not supervised_thresholds:
            return dynamic_threshold
        
        # 1. Process supervised thresholds
        supervised_thresholds_array = np.array(supervised_thresholds)
        
        # Exclude extreme values (e.g., 0.01 or 0.99)
        valid_mask = (supervised_thresholds_array > 0.1) & (supervised_thresholds_array < 0.9)
        if np.sum(valid_mask) == 0:
            # If no valid thresholds, use median
            supervised_median = np.median(supervised_thresholds_array)
        else:
            supervised_median = np.median(supervised_thresholds_array[valid_mask])
        
        # 2. Calculate fusion weights
        # Based on dynamic threshold confidence
        if dynamic_confidence > 0.8:
            dynamic_weight = 0.6
        elif dynamic_confidence > 0.6:
            dynamic_weight = 0.4
        else:
            dynamic_weight = 0.2
        
        # Adjust based on sample size
        if n_samples > 5000:
            # More samples, trust data-driven more
            dynamic_weight += 0.1
        elif n_samples < 1000:
            # Fewer samples, rely more on supervised signals
            dynamic_weight -= 0.1
        
        # Adjust based on supervised F1 score
        if supervised_f1 is not None:
            if supervised_f1 > 0.5:
                # Good supervised performance, increase supervised weight
                dynamic_weight -= 0.15
            elif supervised_f1 < 0.2:
                # Poor supervised performance, increase dynamic weight
                dynamic_weight += 0.15
        
        # Ensure weights are within reasonable range
        dynamic_weight = max(0.1, min(0.9, dynamic_weight))
        supervised_weight = 1.0 - dynamic_weight
        
        print(f"Fusion weights - Dynamic: {dynamic_weight:.2f}, Supervised: {supervised_weight:.2f}")
        
        # 3. Calculate fused threshold
        fused_threshold = (dynamic_weight * dynamic_threshold + 
                         supervised_weight * supervised_median)
        
        # 4. Apply smoothing (prevent sudden changes)
        # Calculate threshold change rate
        if hasattr(EnhancedThresholdFusion, 'last_threshold'):
            threshold_change = abs(fused_threshold - EnhancedThresholdFusion.last_threshold)
            if threshold_change > 0.2:
                # Change too large, apply stronger smoothing
                fused_threshold = 0.3 * fused_threshold + 0.7 * EnhancedThresholdFusion.last_threshold
                print(f"Large threshold change detected ({threshold_change:.3f}), applying smoothing")
        
        EnhancedThresholdFusion.last_threshold = fused_threshold
        
        return fused_threshold
'''======================================================================================================='''
    
    
    
 
'''======================================================================================================='''    
''' ########################    The MODEL- Dual-Engine Anomaly Detection Framework (dADF)   ############# '''

class DualEngineADF:
    """Dual-Engine Anomaly Detection Framework with Dynamic Thresholding"""
    
    def __init__(self, input_size, perturbation_strength=0.1, lambda_reg=0.1, window_size=500):
        self.goe_engine = GOEEngine(perturbation_strength)
        self.mlnn_engine = MLNNEngine(input_size)
        self.lambda_reg = lambda_reg
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.mlnn_engine.to(self.device)
        
        # Dynamic thresholding components
        self.dynamic_thresholder = DynamicAdaptiveThreshold(window_size=window_size)
        self.theorem_thresholder = TheoremBasedThresholdDynamic(window_size=window_size)
        self.dual_synergy = EnhancedDualEngineSynergy(window_size=window_size)
        
        self.training_history = {
            'mlnn_loss': [], 'goe_loss': [], 'dual_loss': [],
            'mlnn_accuracy': [], 'mlnn_f1': [], 'goe_accuracy': [], 'goe_f1': [],
            'dual_accuracy': [], 'dual_f1': []
        }
        
        self.progressive_trainer = ProgressiveTrainingStrategy(self)
        
    
    def fit(self, X_train, y_train, X_val, y_val, use_progressive_training=True):
        """Train dual-engine framework"""
        print("Starting dual-engine anomaly detection framework training...")
        
        total_start_time = time.time()
        goe_start_time = time.time()
        
        print("... Training GOE macro-statistical engine...")
        X_train_clean, y_train_clean = DataCleaner.clean_data(X_train, y_train)
        self.goe_engine.fit(X_train_clean)
        
        goe_training_time = time.time() - goe_start_time
        self.training_history['goe_training_time'] = goe_training_time
        print(f"GOE training time: {goe_training_time:.2f} seconds")
        
        print("... Training MLNN micro-dynamic engine...")
        mlnn_start_time = time.time()
        
        if use_progressive_training:
            print("Using progressive training strategy...")
            stage_results = self.progressive_trainer.train_with_progressive_strategy(
                X_train_clean, y_train_clean, X_val, y_val
            )
            print("Progressive training completed!")
        else:
            self._train_mlnn_with_goe_guidance(X_train_clean, y_train_clean, X_val, y_val, 100, 10)
        
        mlnn_training_time = time.time() - mlnn_start_time
        self.training_history['mlnn_training_time'] = mlnn_training_time
        
        total_training_time = time.time() - total_start_time
        self.training_history['total_training_time'] = total_training_time
        
        print(f"Total training time: {total_training_time:.2f} seconds")
        print("Dual-engine training completed!")
        
    
    def _train_mlnn_with_goe_guidance(self, X_train, y_train, X_val, y_val, epochs, patience):
        """Incorporating the concept of adversarial training"""   
        
        sequence_length = 5
        X_seq = self._create_sequences(X_train, sequence_length)
        y_seq = self._create_sequence_labels(y_train, sequence_length)
        
        X_val_seq = self._create_sequences(X_val, sequence_length)
        y_val_seq = self._create_sequence_labels(y_val, sequence_length)
        
        X_tensor = torch.FloatTensor(X_seq).to(self.device)
        y_tensor = torch.FloatTensor(y_seq).to(self.device)
        X_val_tensor = torch.FloatTensor(X_val_seq).to(self.device)
        y_val_tensor = torch.FloatTensor(y_val_seq).to(self.device)
        
        optimizer = optim.Adam(self.mlnn_engine.parameters(), lr=0.001)
        criterion = nn.BCEWithLogitsLoss()
        
        best_f1 = 0.0
        patience_counter = 0
        best_model_state = None
        
        for epoch in range(epochs):
            self.training_epoch = epoch  
            
            self.mlnn_engine.train()
            optimizer.zero_grad()
            
            mlnn_scores = self.mlnn_engine(X_tensor)
            mlnn_loss = criterion(mlnn_scores, y_tensor)
            goe_regularization = self._compute_goe_regularization(X_tensor, mlnn_scores)
            
            # Dynamic adjustment of loss weights: focus on independent learning of MLNN in the early stage, and focus on fusion in the later stage
            progress = epoch / max(1, epochs-1)
            # Top 30%: MLNN focuses on independent learning
            if progress < 0.3:  
                dual_loss = mlnn_loss * 0.8 + self.lambda_reg * goe_regularization * 0.2
            # 30% -70%: Balanced learning
            elif progress < 0.7:   
                dual_loss = mlnn_loss * 0.5 + self.lambda_reg * goe_regularization * 0.5
            # Last 30%: GOE guidance as the main approach
            else:   
                dual_loss = mlnn_loss * 0.2 + self.lambda_reg * goe_regularization * 0.8
            
            dual_loss.backward()
            optimizer.step()
            
            if patience_counter >= patience:
                break
        
        if best_model_state is not None:
            self.mlnn_engine.load_state_dict(best_model_state)
    
    
    def _compute_goe_regularization(self, X, mlnn_scores):
        """GOE regularization for financial data - enhanced boundary sample learning"""
        try:
            batch_size, seq_len, input_size = X.shape
            
            # Obtain GOE boundary samples
            X_flat = X.reshape(-1, input_size)
            X_np = X_flat.detach().cpu().numpy()
            
            # Calculate GOE boundary score
            if hasattr(self.goe_engine, 'compute_boundary_scores'):
                goe_boundary_scores = self.goe_engine.compute_boundary_scores(X_np)
            else:
                goe_scores = self.goe_engine.compute_anomaly_scores(X_np)
                goe_boundary_scores = (goe_scores - np.min(goe_scores)) / (np.max(goe_scores) - np.min(goe_scores) + 1e-8)
            
            goe_boundary_scores_reshaped = goe_boundary_scores.reshape(batch_size, seq_len)
            goe_boundary_avg = np.mean(goe_boundary_scores_reshaped, axis=1)
            
            # Identification of boundary samples specific to financial data
            # In financial data, we need to identify more boundary samples (target: 10-20%)
            
            # Method 1: Based on percentiles
            boundary_threshold_low = np.percentile(goe_boundary_avg, 70)  
            boundary_threshold_high = np.percentile(goe_boundary_avg, 90)   
            
            # Method 2: Based on distribution patterns
            hist, bins = np.histogram(goe_boundary_avg, bins=50)
            # Find valleys in the histogram as boundary thresholds
            if len(hist) > 3:
                # Smooth histogram
                hist_smooth = np.convolve(hist, np.ones(3)/3, mode='valid')
                # Find local minimum value
                minima = []
                for i in range(1, len(hist_smooth)-1):
                    if hist_smooth[i] < hist_smooth[i-1] and hist_smooth[i] < hist_smooth[i+1]:
                        minima.append(bins[i])
                
                if minima:
                    # Use the first trough as the boundary threshold
                    boundary_threshold_dynamic = minima[0]
                else:
                    boundary_threshold_dynamic = np.percentile(goe_boundary_avg, 75)
            else:
                boundary_threshold_dynamic = np.percentile(goe_boundary_avg, 75)
            
            # Choose a lower threshold to obtain more boundary samples
            boundary_threshold = min(boundary_threshold_low, boundary_threshold_dynamic)
            
            # Identify boundary samples (Objective: Increase the proportion of boundary samples)
            boundary_mask_np = (goe_boundary_avg >= boundary_threshold) & (goe_boundary_avg < boundary_threshold_high)
            non_boundary_mask_np = goe_boundary_avg < boundary_threshold  # Low score region
            clear_anomaly_mask_np = goe_boundary_avg >= boundary_threshold_high  # Clear anomaly
            
            # Low score area
            boundary_ratio = np.sum(boundary_mask_np) / len(boundary_mask_np)
            
            # Calculate the proportion of boundary samples
            if boundary_ratio < 0.1:   
                boundary_threshold = np.percentile(goe_boundary_avg, 60)   
                boundary_mask_np = (goe_boundary_avg >= boundary_threshold) & (goe_boundary_avg < boundary_threshold_high)
                boundary_ratio = np.sum(boundary_mask_np) / len(boundary_mask_np)
            
            # Normalized GOE score
            goe_boundary_norm = (goe_boundary_avg - np.min(goe_boundary_avg)) / (np.max(goe_boundary_avg) - np.min(goe_boundary_avg) + 1e-8)
            
            # Convert GOE scores to tensor
            goe_boundary_tensor = torch.FloatTensor(goe_boundary_norm).to(self.device).unsqueeze(1)
            
            # MLNN output (deterministic score)
            mlnn_certainty = torch.sigmoid(mlnn_scores).unsqueeze(1)
            
            # MLNN output (deterministic score)
            min_dim = min(goe_boundary_tensor.size(0), mlnn_certainty.size(0))
            goe_boundary_tensor = goe_boundary_tensor[:min_dim]
            mlnn_certainty = mlnn_certainty[:min_dim]
            boundary_mask_np = boundary_mask_np[:min_dim]
            non_boundary_mask_np = non_boundary_mask_np[:min_dim] if len(non_boundary_mask_np) >= min_dim else non_boundary_mask_np
            clear_anomaly_mask_np = clear_anomaly_mask_np[:min_dim] if len(clear_anomaly_mask_np) >= min_dim else clear_anomaly_mask_np
            
            boundary_mask = torch.tensor(boundary_mask_np, device=self.device, dtype=torch.bool)
            non_boundary_mask = torch.tensor(non_boundary_mask_np, device=self.device, dtype=torch.bool)
            clear_anomaly_mask = torch.tensor(clear_anomaly_mask_np, device=self.device, dtype=torch.bool)
            
            # Specific regularization strategies
            total_regularization = torch.tensor(0.0, device=self.device)
            
            # 1. Regularization of boundary samples
            boundary_loss = torch.tensor(0.0, device=self.device)
            if torch.sum(boundary_mask) > 10:  
                # Ensure sufficient samples are available
                # For financial data boundary samples: MLNN should learn GOE patterns
                mlnn_boundary = mlnn_certainty[boundary_mask]
                goe_boundary = goe_boundary_tensor[boundary_mask]
                
                # Using mild MSE loss to encourage MLNN to approach GOE but not enforce consistency
                boundary_loss = torch.mean((mlnn_boundary - goe_boundary) ** 2)
                
                # Record the number of boundary samples
                boundary_count = torch.sum(boundary_mask).item()
            else:
                boundary_count = 0
            
            # 2. Regularization of non-boundary samples (normal samples)
            non_boundary_loss = torch.tensor(0.0, device=self.device)
            if torch.sum(non_boundary_mask) > 10:
                # For normal samples: MLNN should output a low anomaly score
                mlnn_normal = mlnn_certainty[non_boundary_mask]
                # Goal: Approaching 0 (as normal)
                target_normal = torch.zeros_like(mlnn_normal)
                non_boundary_loss = torch.mean((mlnn_normal - target_normal) ** 2)
            
            # 3. Clarify the regularization of abnormal samples
            clear_anomaly_loss = torch.tensor(0.0, device=self.device)
            if torch.sum(clear_anomaly_mask) > 5:
                # For clear anomalies: MLNN should output high anomaly scores
                mlnn_anomaly = mlnn_certainty[clear_anomaly_mask]
                # Goal: Approaching 1 (as abnormal)
                target_anomaly = torch.ones_like(mlnn_anomaly)
                clear_anomaly_loss = torch.mean((mlnn_anomaly - target_anomaly) ** 2)
            
            # Dynamic weight adjustment
            epoch = getattr(self, 'training_epoch', 0)
            
            # Early: Focus on boundary learning
            if epoch < 30:   
                boundary_weight = 0.6
                non_boundary_weight = 0.2
                anomaly_weight = 0.2
            # Mid-term: Balanced Learning
            elif epoch < 60:   
                boundary_weight = 0.4
                non_boundary_weight = 0.3
                anomaly_weight = 0.3
            # Post-production: Overall optimization
            else: 
                boundary_weight = 0.3
                non_boundary_weight = 0.4
                anomaly_weight = 0.3
            
            mlnn_std = torch.std(mlnn_certainty)
            diversity_loss = torch.exp(-mlnn_std * 5.0)  
            
            # Loss
            total_regularization = (
                boundary_weight * boundary_loss +
                non_boundary_weight * non_boundary_loss +
                anomaly_weight * clear_anomaly_loss +
                0.05 * diversity_loss
            )
            
            self._debug_info = {
                'boundary_ratio': boundary_count / min_dim,
                'boundary_count': boundary_count,
                'boundary_loss': boundary_loss.item() if torch.sum(boundary_mask) > 0 else 0,
                'non_boundary_loss': non_boundary_loss.item() if torch.sum(non_boundary_mask) > 0 else 0,
                'mlnn_std': mlnn_std.item(),
                'boundary_threshold': boundary_threshold,
                'epoch': epoch
            }
            
            if epoch % 10 == 0:
                print(f"Epoch {epoch}: boundary sample ratio={self._debug_info['boundary_ratio']:.3f}, "
                      f"boundary counts ={self._debug_info['boundary_count']}")
            
            return total_regularization * 0.3  
            
        except Exception as e:
            print(f"GOE regularization error: {e}")
            import traceback
            traceback.print_exc()
            return torch.tensor(0.0, device=self.device)
        
          
    def _create_sequences(self, X, sequence_length):
        """Create time sequences"""
        sequences = []
        for i in range(len(X) - sequence_length + 1):
            sequences.append(X[i:i+sequence_length])
        if not sequences:
            sequences = [X]
        return np.array(sequences)
    
    
    def _create_sequence_labels(self, y, sequence_length):
        """Create sequence labels"""
        if len(y) <= sequence_length:
            return y[-1:] if len(y) > 0 else np.array([0])
        return y[sequence_length-1:]
    
    
    def find_optimal_threshold(model, X_val, y_val, metric='f1', num_candidates=200):
        """
        Find optimal threshold on validation set that maximizes the given metric.
        
        Parameters:
            model: trained DualEngineADF model
            X_val, y_val: validation data
            metric: one of 'f1', 'gmean', 'recall', 'precision', 'accuracy'
            num_candidates: number of threshold candidates to evaluate
        
        Returns:
            best_threshold: float
            best_score: float
        """
        """
        Search for the optimal threshold on the validation set and return the percentile corresponding to that threshold
        """
        scores = model.predict_anomaly_scores(X_val, use_dynamic_threshold=False)
        dual_scores = scores['dual_scores']
        min_len = min(len(dual_scores), len(y_val))
        dual_scores = dual_scores[:min_len]
        y_val = y_val[:min_len].astype(int)

        low_percentile, high_percentile = 80, 99.9
        low = np.percentile(dual_scores, low_percentile)
        high = np.percentile(dual_scores, high_percentile)
        if high <= low:
            low, high = np.min(dual_scores), np.max(dual_scores)

        thresholds = np.linspace(low, high, num_candidates)
        best_th = thresholds[0]
        best_score = 0.0

        for th in thresholds:
            pred = (dual_scores > th).astype(int)
            if metric == 'f1':
                score = f1_score(y_val, pred, zero_division=0)
            elif metric == 'gmean':
                score = calculate_gmean(y_val, pred)
            elif metric == 'recall':
                score = recall_score(y_val, pred, zero_division=0)
            elif metric == 'precision':
                score = precision_score(y_val, pred, zero_division=0)
            else:
                score = accuracy_score(y_val, pred)
            if score > best_score:
                best_score = score
                best_th = th

        percentile = np.sum(dual_scores <= best_th) / len(dual_scores) * 100
        print(f"Best threshold on validation set ({metric}): {best_th:.6f} with score {best_score:.4f}, percentile={percentile:.2f}%")
        return best_th, best_score, dual_scores, percentile
    
    
    
    
    def predict_anomaly_scores(self, X, use_dynamic_threshold=True, streaming_mode=False, custom_threshold=None):
            """
            Predict anomaly scores combining dual-engine outputs with dynamic thresholding
            
            Parameters:
            X: Input data
            use_dynamic_threshold: Whether to use dynamic adaptive thresholding
            streaming_mode: Whether in streaming mode (for real-time processing)
            custom_threshold: If provided, use this fixed threshold for prediction
            """
            # Compute base scores
            goe_scores = self.goe_engine.compute_anomaly_scores(X)
            
            sequence_length = 5
            X_seq = self._create_sequences(X, sequence_length)
            if len(X_seq) == 0:
                X_tensor = torch.FloatTensor(X).unsqueeze(1).to(self.device)
            else:
                X_tensor = torch.FloatTensor(X_seq).to(self.device)
            
            self.mlnn_engine.eval()
            with torch.no_grad():
                mlnn_scores = self.mlnn_engine(X_tensor)
                mlnn_scores_norm = torch.sigmoid(mlnn_scores).cpu().numpy()
            
            min_length = min(len(goe_scores), len(mlnn_scores_norm))
            goe_scores = goe_scores[:min_length]
            mlnn_scores_norm = mlnn_scores_norm[:min_length]
            
            goe_scores_norm = (goe_scores - np.min(goe_scores)) / (np.max(goe_scores) - np.min(goe_scores) + 1e-8)
            
            _, dual_scores = EnhancedDualEngineSynergy.adaptive_fusion_strategy(
                goe_scores_norm, mlnn_scores_norm, None, use_dynamic=False
            )
            
            if custom_threshold is not None:
                threshold = custom_threshold
                threshold_type = 'fixed'
            elif use_dynamic_threshold:
                if streaming_mode:
                    pass
                else:
                    threshold, _ = self.dual_synergy.adaptive_fusion_strategy(
                        goe_scores_norm, mlnn_scores_norm, None,
                        use_dynamic=True, dynamic_thresholder=self.dynamic_thresholder
                    )
                threshold_type = 'dynamic'
            else:
                threshold, _ = EnhancedDualEngineSynergy.adaptive_fusion_strategy(
                    goe_scores_norm, mlnn_scores_norm, None, use_dynamic=False
                )
                threshold_type = 'static'
            
            thresholds = np.full_like(dual_scores, threshold)
            predictions = (dual_scores > threshold).astype(int)
            
            return {
                'goe_scores': goe_scores_norm,
                'mlnn_scores': mlnn_scores_norm,
                'dual_scores': dual_scores,
                'threshold': threshold,
                'thresholds': thresholds,   
                'predictions': predictions,
                'threshold_type': threshold_type,
                'streaming_mode': streaming_mode
            }
         
    
    def save_model(self, filepath):
        """Save model state dictionary"""
        checkpoint = {
            'goe_eigenvectors': self.goe_engine.eigenvectors,
            'goe_eigenvalues': self.goe_engine.eigenvalues,
            'goe_reference_mean': self.goe_engine.reference_mean,
            'goe_reference_cov': self.goe_engine.reference_cov,
            'goe_projection_basis': self.goe_engine.projection_basis,
            'mlnn_engine_state_dict': self.mlnn_engine.state_dict(),
            'training_history': self.training_history,
            'lambda_reg': self.lambda_reg,
            'model_type': 'DualEngineADF_Dynamic',
            'dynamic_thresholder': self.dynamic_thresholder if hasattr(self, 'dynamic_thresholder') else None
        }
        
        torch.save(checkpoint, filepath)
        print(f"\nModel saved to: {filepath}")
        
        
    def print_training_debug(self, epoch):
        if hasattr(self, '_debug_info'):
            debug = self._debug_info
            print(f"Epoch {epoch}: boundary ratio={debug['boundary_ratio']:.3f}, "
                  f"boundary loss={debug['boundary_loss']:.4f}, "
                  f"non-boundary loss={debug['non_boundary_loss']:.4f}, "
                  f"MLNN variance={debug['mlnn_std']:.4f}")
'''=======================================================================================================''' 
        
        
        

'''======================================================================================================='''         
''' ########################    Training Strategy    ############# '''

class ProgressiveTrainingStrategy:
    """Progressive training strategy as described in the paper"""
    
    def __init__(self, model):
        self.model = model
        self.stage_results = {}
        
 
    def train_with_progressive_strategy(self, X_train, y_train, X_val, y_val):
        """Execute progressive training strategy with boundary-aware focus"""
        print("Starting boundary-aware progressive training strategy...")
        
        stages_config = [
            {
                'name': 'Stage 1: Boundary Sample Identification',
                'epochs': 25,
                'lr': 0.001,
                'lambda_reg': 0.3,
                'focus': 'independent',   # Phase 1: Independent learning, identifying boundaries
                'patience': 8
            },
            {
                'name': 'Stage 2: Boundary Discrimination Enhancement', 
                'epochs': 40,
                'lr': 0.0005,
                'lambda_reg': 0.5,
                'focus': 'complementary',  # Phase 2: Complementary learning to enhance boundary discrimination
                'patience': 12
            },
            {
                'name': 'Stage 3: Whole-Space Optimization',
                'epochs': 25,
                'lr': 0.0001,
                'lambda_reg': 0.2,
                'focus': 'fine_tune', # Phase 3: Overall fine-tuning
                'patience': 6
            }
        ]
        
        overall_history = {
            'mlnn_loss': [], 'goe_loss': [], 'dual_loss': [],
            'mlnn_accuracy': [], 'mlnn_f1': [], 'goe_accuracy': [], 'goe_f1': [],
            'dual_accuracy': [], 'dual_f1': [], 'stage': []
        }
        
        total_epoch_offset = 0
        for stage_idx, stage_config in enumerate(stages_config):
            print(f"\n{stage_config['name']}")
            print(f"  Focus: {stage_config['focus']}")
            
            self.model.lambda_reg = stage_config['lambda_reg']
            stage_result = self._train_stage(
                X_train, y_train, X_val, y_val,
                epochs=stage_config['epochs'],
                lr=stage_config['lr'],
                patience=stage_config['patience'],
                focus=stage_config['focus'],
                stage_idx=stage_idx
            )
            
            self.stage_results[stage_config['name']] = stage_result
            
            for key in overall_history:
                if key in stage_result['history']:
                    overall_history[key].extend(stage_result['history'][key])
                elif key == 'stage':
                    overall_history[key].extend([stage_idx] * len(stage_result['history'].get('dual_loss', [])))
        
        self.model.training_history = overall_history
        
        print("Boundary-aware progressive training strategy completed")
        return self.stage_results
        
    
    def _train_stage(self, X_train, y_train, X_val, y_val, epochs, lr, patience, focus, stage_idx):
       
                    """Execute a single training phase - optimize training strategies for different focuses"""
                    sequence_length = 5
                    
                    y_train = ensure_numpy_array(y_train)
                    y_val = ensure_numpy_array(y_val)

                    X_seq = self._create_sequences(X_train, sequence_length)
                    y_seq = self._create_sequence_labels(y_train, sequence_length)
                    
                    X_val_seq = self._create_sequences(X_val, sequence_length)
                    y_val_seq = self._create_sequence_labels(y_val, sequence_length)
                    
                    X_tensor = torch.FloatTensor(X_seq).to(self.model.device)
                    y_tensor = torch.FloatTensor(y_seq).to(self.model.device)
                    X_val_tensor = torch.FloatTensor(X_val_seq).to(self.model.device)
                    
                    optimizer = optim.Adam(self.model.mlnn_engine.parameters(), lr=lr)
                    
                    # Adjust the loss function according to different training stages
                    if focus == 'independent':
                        # MLNN independent training phase: almost no use of GOE regularization, emphasizing MLNN autonomy
                        print(f"\n   Initial Phase: MLNN independent training stage->emphasizes self-learning, with extremely low GOE regularization weights. \n")
                        
                        criterion = nn.BCEWithLogitsLoss()
                        
                        stage_history = {
                            'mlnn_loss': [], 'dual_loss': [],
                            'train_mlnn_accuracy': [], 'train_mlnn_precision': [], 'train_mlnn_recall': [], 'train_mlnn_f1': [], 'train_mlnn_gmean': [],
                            'train_dual_accuracy': [], 'train_dual_precision': [], 'train_dual_recall': [], 'train_dual_f1': [], 'train_dual_gmean': []
                        }
                        
                        csv_path = 'CredictCard_results/training_metrics_consistent.csv'
                        is_new_file = not os.path.exists(csv_path)
                        
                        for epoch in range(epochs):
                            self.model.mlnn_engine.train()
                            self.model.training_epoch = epoch   
                            optimizer.zero_grad()
                            
                            mlnn_scores = self.model.mlnn_engine(X_tensor)
                            mlnn_loss = criterion(mlnn_scores, y_tensor)
                            
                            # Independent training phase: extremely low GOE regularization (only maintains direction, does not affect primary learning)
                            try:
                                goe_regularization = self.model._compute_goe_regularization(X_tensor, mlnn_scores)
                                dual_loss = mlnn_loss + 0.01 * goe_regularization  
                            except Exception as e:
                                print(f"GOE regularization failure: {e}")
                                dual_loss = mlnn_loss
                            
                            dual_loss.backward()
                            torch.nn.utils.clip_grad_norm_(self.model.mlnn_engine.parameters(), max_norm=1.0)
                            optimizer.step()
                            
                            train_metrics = self._compute_training_metrics_consistent(X_train, y_train, X_tensor, y_tensor)
                            
                            goe_reg_value = goe_regularization.item() if 'goe_regularization' in locals() else 0.0
                            self._save_training_metrics_to_csv(csv_path, stage_idx, epoch, train_metrics, 
                                                              mlnn_loss.item(), goe_reg_value, dual_loss.item(),
                                                              is_new_file and epoch == 0)
                            
                            stage_history['mlnn_loss'].append(mlnn_loss.item())
                            stage_history['dual_loss'].append(dual_loss.item())
                            
                            for key in train_metrics:
                                if key in stage_history:
                                    stage_history[key].append(train_metrics[key])
                            
                            if (epoch + 1) % 5 == 0:
                                dual_accuracy = train_metrics.get('train_dual_accuracy', 0)
                                dual_f1 = train_metrics.get('train_dual_f1', 0)
                                mlnn_f1 = train_metrics.get('train_mlnn_f1', 0)
                                print(f"  Epoch {epoch+1}/{epochs}: MLNN F1={mlnn_f1:.4f}, Dual F1={dual_f1:.4f}")
                        
                        return {
                            'best_metrics': train_metrics,
                            'best_f1': train_metrics.get('train_dual_f1', 0),
                            'history': stage_history
                        }
                        
                    elif focus == 'complementary':
                        # Complementary learning stage: Moderate GOE guidance, emphasizing complementary learning
                        print(f"\n  GOE Regularization Phase: GOE guided complementary learning stage->emphasizing the complementarity between GOE and MLNN")
                        
                        n_normal = np.sum(y_train == 0)
                        n_anomaly = np.sum(y_train == 1)
                        if n_anomaly > 0:
                            weight_for_0 = 1.0
                            weight_for_1 = (n_normal / n_anomaly) * 0.8  
                            pos_weight = torch.tensor([weight_for_1 / weight_for_0]).to(self.model.device)
                            criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
                        else:
                            criterion = nn.BCEWithLogitsLoss()
                        
                        stage_history = {
                            'mlnn_loss': [], 'goe_loss': [], 'dual_loss': [],
                            'train_mlnn_accuracy': [], 'train_mlnn_precision': [], 'train_mlnn_recall': [], 'train_mlnn_f1': [], 'train_mlnn_gmean': [],
                            'train_goe_accuracy': [], 'train_goe_precision': [], 'train_goe_recall': [], 'train_goe_f1': [], 'train_goe_gmean': [],
                            'train_dual_accuracy': [], 'train_dual_precision': [], 'train_dual_recall': [], 'train_dual_f1': [], 'train_dual_gmean': []
                        }
                        
                        csv_path = 'CredictCard_results/training_metrics_consistent.csv'
                        is_new_file = not os.path.exists(csv_path)
                        
                        best_f1 = 0.0
                        best_model_state = None
                        best_metrics = {}
                        
                        for epoch in range(epochs):
                            self.model.mlnn_engine.train()
                            self.model.training_epoch = epoch   
                            optimizer.zero_grad()
                            
                            mlnn_scores = self.model.mlnn_engine(X_tensor)
                            mlnn_loss = criterion(mlnn_scores, y_tensor)
                            
                            # Complementary Learning Stage: Moderate GOE Regularization
                            try:
                                goe_regularization = self.model._compute_goe_regularization(X_tensor, mlnn_scores)
                                
                                # Dynamic adjustment of fusion weights: MLNN is mainly used in the early stage, and GOE guidance is added in the later stage
                                progress = epoch / max(1, epochs-1)
                                
                                # Early low GOE guidance
                                if progress < 0.5:
                                    lambda_weight = 0.3  
                                else:
                                    # Add GOE guidance in the later stage
                                    lambda_weight = 0.6   
                                
                                dual_loss = mlnn_loss + lambda_weight * goe_regularization
                                
                            except Exception as e:
                                print(f"GOE regularization failed, using MLNN loss: {e}")
                                dual_loss = mlnn_loss
                                goe_regularization = torch.tensor(0.0, device=self.model.device)
                            
                            dual_loss.backward()
                            torch.nn.utils.clip_grad_norm_(self.model.mlnn_engine.parameters(), max_norm=1.0)
                            optimizer.step()
                            
                            train_metrics = self._compute_training_metrics_consistent(X_train, y_train, X_tensor, y_tensor)
                            
                            goe_reg_value = goe_regularization.item() if hasattr(goe_regularization, 'item') else goe_regularization
                            self._save_training_metrics_to_csv(csv_path, stage_idx, epoch, train_metrics, mlnn_loss.item(), goe_reg_value, dual_loss.item(),is_new_file and epoch == 0)
                            
                            stage_history['mlnn_loss'].append(mlnn_loss.item())
                            stage_history['goe_loss'].append(goe_regularization.item() if hasattr(goe_regularization, 'item') else goe_regularization)
                            stage_history['dual_loss'].append(dual_loss.item())
                            
                            for key in train_metrics:
                                if key in stage_history:
                                    stage_history[key].append(train_metrics[key])
                            
                            if (epoch + 1) % 5 == 0:
                                dual_accuracy = train_metrics.get('train_dual_accuracy', 0)
                                dual_precision = train_metrics.get('train_dual_precision', 0)
                                dual_recall = train_metrics.get('train_dual_recall', 0)
                                dual_f1 = train_metrics.get('train_dual_f1', 0)
                                print(f"  Epoch {epoch+1}/{epochs}: Train Dual Accuracy={dual_accuracy:.4f}, F1={dual_f1:.4f}")
                            
                            # Early stop check (using validation set)
                            self.model.mlnn_engine.eval()
                            with torch.no_grad():
                                val_scores = self.model.predict_anomaly_scores(X_val)
                                val_dual_scores = val_scores['dual_scores']
                                val_goe_scores = val_scores['goe_scores'][:len(val_dual_scores)]
                                
                                y_val_adj = y_val[:len(val_dual_scores)]
                                y_val_int = y_val_adj.astype(int)
                                
                                val_threshold, val_final_scores = TheoremBasedThresholdDynamic.enhanced_synergy_strategy(
                                    val_goe_scores, val_dual_scores, y_val_int
                                )
                                val_predictions = (val_final_scores > val_threshold).astype(int)
                                val_f1 = f1_score(y_val_int, val_predictions, zero_division=0)
                                
                                if val_f1 > best_f1:
                                    best_f1 = val_f1
                                    best_model_state = self.model.mlnn_engine.state_dict().copy()
                                    best_metrics = train_metrics.copy()
                        
                        if best_model_state is not None:
                            self.model.mlnn_engine.load_state_dict(best_model_state)
                        
                        return {
                            'best_metrics': best_metrics,
                            'best_f1': best_f1,
                            'history': stage_history
                        }
                        
                    elif focus == 'fine_tune':
                        # Fine tuning stage: Balance two engines and optimize overall performance
                        print(f"\n Stable Alignment Phase: Dual engine fine-tuning stage->optimizing overall performance \n")
                        
                        n_normal = np.sum(y_train == 0)
                        n_anomaly = np.sum(y_train == 1)
                        if n_anomaly > 0:
                            weight_for_0 = 1.0
                            weight_for_1 = (n_normal / n_anomaly) * 1.0  
                            pos_weight = torch.tensor([weight_for_1 / weight_for_0]).to(self.model.device)
                            criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
                        else:
                            criterion = nn.BCEWithLogitsLoss()
                        
                        stage_history = {
                            'mlnn_loss': [], 'goe_loss': [], 'dual_loss': [],
                            'train_mlnn_accuracy': [], 'train_mlnn_precision': [], 'train_mlnn_recall': [], 'train_mlnn_f1': [], 'train_mlnn_gmean': [],
                            'train_goe_accuracy': [], 'train_goe_precision': [], 'train_goe_recall': [], 'train_goe_f1': [], 'train_goe_gmean': [],
                            'train_dual_accuracy': [], 'train_dual_precision': [], 'train_dual_recall': [], 'train_dual_f1': [], 'train_dual_gmean': []
                        }
                        
                        csv_path = 'CredictCard_results/training_metrics_consistent.csv'
                        is_new_file = not os.path.exists(csv_path)
                        
                        best_f1 = 0.0
                        best_model_state = None
                        best_metrics = {}
                        
                        for epoch in range(epochs):
                            self.model.mlnn_engine.train()
                            self.model.training_epoch = epoch  
                            optimizer.zero_grad()
                            
                            mlnn_scores = self.model.mlnn_engine(X_tensor)
                            mlnn_loss = criterion(mlnn_scores, y_tensor)
                            
                            # Fine tuning stage: Moderate GOE regularization, emphasizing fusion optimization
                            try:
                                goe_regularization = self.model._compute_goe_regularization(X_tensor, mlnn_scores)
                                dual_loss = mlnn_loss + 0.1 * goe_regularization  # Lower GOE guidance
                            except Exception as e:
                                print(f"GOE regularization failed, using MLNN loss: {e}")
                                dual_loss = mlnn_loss
                                goe_regularization = torch.tensor(0.0, device=self.model.device)
                            
                            dual_loss.backward()
                            torch.nn.utils.clip_grad_norm_(self.model.mlnn_engine.parameters(), max_norm=1.0)
                            optimizer.step()
                            
                            train_metrics = self._compute_training_metrics_consistent(X_train, y_train, X_tensor, y_tensor)
                            
                            goe_reg_value = goe_regularization.item() if hasattr(goe_regularization, 'item') else goe_regularization
                            self._save_training_metrics_to_csv(csv_path, stage_idx, epoch, train_metrics, 
                                                              mlnn_loss.item(), goe_reg_value, dual_loss.item(),
                                                              is_new_file and epoch == 0)
                            
                            stage_history['mlnn_loss'].append(mlnn_loss.item())
                            stage_history['goe_loss'].append(goe_regularization.item() if hasattr(goe_regularization, 'item') else goe_regularization)
                            stage_history['dual_loss'].append(dual_loss.item())
                            
                            for key in train_metrics:
                                if key in stage_history:
                                    stage_history[key].append(train_metrics[key])
                            
                            if (epoch + 1) % 5 == 0:
                                dual_f1 = train_metrics.get('train_dual_f1', 0)
                                mlnn_f1 = train_metrics.get('train_mlnn_f1', 0)
                                goe_f1 = train_metrics.get('train_goe_f1', 0)
                                print(f"  Epoch {epoch+1}/{epochs}: MLNN F1={mlnn_f1:.4f}, GOE F1={goe_f1:.4f}, Dual F1={dual_f1:.4f}")
                            
                            # Early stop check
                            self.model.mlnn_engine.eval()
                            with torch.no_grad():
                                val_scores = self.model.predict_anomaly_scores(X_val)
                                val_dual_scores = val_scores['dual_scores']
                                val_goe_scores = val_scores['goe_scores'][:len(val_dual_scores)]
                                
                                y_val_adj = y_val[:len(val_dual_scores)]
                                y_val_int = y_val_adj.astype(int)
                                
                                val_threshold, val_final_scores = TheoremBasedThresholdDynamic.enhanced_synergy_strategy(
                                    val_goe_scores, val_dual_scores, y_val_int
                                )
                                val_predictions = (val_final_scores > val_threshold).astype(int)
                                val_f1 = f1_score(y_val_int, val_predictions, zero_division=0)
                                
                                if val_f1 > best_f1:
                                    best_f1 = val_f1
                                    best_model_state = self.model.mlnn_engine.state_dict().copy()
                                    best_metrics = train_metrics.copy()
                        
                        if best_model_state is not None:
                            self.model.mlnn_engine.load_state_dict(best_model_state)
                        
                        return {
                            'best_metrics': best_metrics,
                            'best_f1': best_f1,
                            'history': stage_history
                        }
                        
                    else:
                        print("...........call backup training strategy\n................")
                        return self._train_stage_fallback(X_train, y_train, X_val, y_val, epochs, lr, patience, focus, stage_idx)
        
    
    def _train_stage_fallback(self, X_train, y_train, X_val, y_val, epochs, lr, patience, focus, stage_idx):
            """Backup Training Method - Training Loop Based on Deterministic Learning"""
            
            sequence_length = 5
            
            y_train = ensure_numpy_array(y_train)
            y_val = ensure_numpy_array(y_val)

            X_seq = self._create_sequences(X_train, sequence_length)
            y_seq = self._create_sequence_labels(y_train, sequence_length)
            
            X_val_seq = self._create_sequences(X_val, sequence_length)
            y_val_seq = self._create_sequence_labels(y_val, sequence_length)
            
            X_tensor = torch.FloatTensor(X_seq).to(self.model.device)
            y_tensor = torch.FloatTensor(y_seq).to(self.model.device)
            X_val_tensor = torch.FloatTensor(X_val_seq).to(self.model.device)
            
            optimizer = optim.Adam(self.model.mlnn_engine.parameters(), lr=lr)
            
            # 1. Regularization loss: learning deterministic patterns of GOE
            # 2. Auxiliary loss: When GOE is determined, MLNN should be consistent with GOE decision
            
            stage_history = {
                'mlnn_loss': [], 'goe_loss': [], 'dual_loss': [],
                'train_mlnn_accuracy': [], 'train_mlnn_precision': [], 'train_mlnn_recall': [], 'train_mlnn_f1': [], 'train_mlnn_gmean': [],
                'train_goe_accuracy': [], 'train_goe_precision': [], 'train_goe_recall': [], 'train_goe_f1': [], 'train_goe_gmean': [],
                'train_dual_accuracy': [], 'train_dual_precision': [], 'train_dual_recall': [], 'train_dual_f1': [], 'train_dual_gmean': []
            }
            
            csv_path = 'CredictCard_results/training_metrics_consistent.csv'
            is_new_file = not os.path.exists(csv_path)
            
            best_f1 = 0.0
            best_model_state = None
            best_metrics = {}
            
            for epoch in range(epochs):
                self.model.mlnn_engine.train()
                optimizer.zero_grad()
                
                # MLNN outputs deterministic score (forward directly outputs determinism)
                mlnn_certainty = self.model.mlnn_engine(X_tensor)
                
                # Calculate GOE regularization loss
                goe_regularization = self.model._compute_goe_regularization(X_tensor, mlnn_certainty)
                
                # Auxiliary loss: Encourage MLNN to make correct judgments when GOE is determined
                # Obtain GOE score
                X_flat = X_tensor.reshape(-1, X_tensor.shape[-1])
                X_np = X_flat.detach().cpu().numpy()
                goe_scores = self.model.goe_engine.compute_anomaly_scores(X_np)
                goe_scores_reshaped = goe_scores.reshape(X_tensor.shape[0], -1)
                goe_scores_avg = np.mean(goe_scores_reshaped, axis=1)
                goe_norm = (goe_scores_avg - np.min(goe_scores_avg)) / (np.max(goe_scores_avg) - np.min(goe_scores_avg) + 1e-8)
                
                # Certainty of GOE
                goe_certainty = 1.0 - 2.0 * np.abs(goe_norm - 0.5)
                
                # GOE's decision (when certainty is high)
                high_certainty_mask = (goe_certainty > 0.8)
                if np.sum(high_certainty_mask) > 0:
                    goe_decisions = (goe_norm > 0.5).astype(float)
                    
                    # Select high certainty samples
                    mlnn_high_certainty = mlnn_certainty[high_certainty_mask]
                    goe_high_decisions = torch.FloatTensor(goe_decisions[high_certainty_mask]).to(self.model.device)
                    
                    # Auxiliary loss: MLNN should be consistent with GOE's high certainty decision
                    auxiliary_loss = nn.BCELoss()(mlnn_high_certainty, goe_high_decisions)
                else:
                    auxiliary_loss = torch.tensor(0.0, device=self.model.device)
                
                # Total loss: mainly using GOE regularization loss, with auxiliary loss as a guide
                # Adjust the loss weight based on the training phase
                if focus == 'boundary_identification' or focus == 'independent':
                    # Phase 1: Smaller auxiliary loss weights
                    lambda_aux = 0.05  
                elif focus == 'boundary_discrimination' or focus == 'complementary':
                    # Phase 2: Moderate auxiliary loss weights
                    lambda_aux = 0.1   
                else:  
                    # Phase 3: Higher auxiliary loss weights
                    lambda_aux = 0.15  
                
                dual_loss = goe_regularization + lambda_aux * auxiliary_loss
                
                dual_loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.mlnn_engine.parameters(), max_norm=1.0)
                optimizer.step()
                
                train_metrics = self._compute_training_metrics_consistent(X_train, y_train, X_tensor, y_tensor)
                
                self._save_training_metrics_to_csv(csv_path, stage_idx, epoch, train_metrics, 
                                                  dual_loss.item(), goe_regularization.item(), dual_loss.item(),
                                                  is_new_file and epoch == 0)
                
                stage_history['mlnn_loss'].append(dual_loss.item())
                stage_history['goe_loss'].append(goe_regularization.item())
                stage_history['dual_loss'].append(dual_loss.item())
                
                for key in train_metrics:
                    if key in stage_history:
                        stage_history[key].append(train_metrics[key])
                
                if (epoch + 1) % 5 == 0:
                    dual_f1 = train_metrics.get('train_dual_f1', 0)
                    mlnn_f1 = train_metrics.get('train_mlnn_f1', 0)
                    goe_f1 = train_metrics.get('train_goe_f1', 0)
                    print(f"  Epoch {epoch+1}/{epochs}: MLNN F1={mlnn_f1:.4f}, GOE F1={goe_f1:.4f}, Dual F1={dual_f1:.4f}")
                
                self.model.mlnn_engine.eval()
                with torch.no_grad():
                    val_scores = self.model.predict_anomaly_scores(X_val)
                    val_goe_scores = val_scores['goe_scores']
                    val_mlnn_scores = val_scores['mlnn_scores']
                    
                    min_val_length = min(len(val_goe_scores), len(val_mlnn_scores))
                    val_goe_scores = val_goe_scores[:min_val_length]
                    val_mlnn_scores = val_mlnn_scores[:min_val_length]
                    
                    y_val_adj = y_val[:min_val_length]
                    y_val_int = y_val_adj.astype(int)
                    
                    val_threshold, val_final_scores = EnhancedDualEngineSynergy.adaptive_fusion_strategy(
                        val_goe_scores, val_mlnn_scores, y_val_int
                    )
                    val_predictions = (val_final_scores > val_threshold).astype(int)
                    val_f1 = f1_score(y_val_int, val_predictions, zero_division=0)
                    
                    if val_f1 > best_f1:
                        best_f1 = val_f1
                        best_model_state = self.model.mlnn_engine.state_dict().copy()
                        best_metrics = train_metrics.copy()
            
            if best_model_state is not None:
                self.model.mlnn_engine.load_state_dict(best_model_state)
            
            return {
                'best_metrics': best_metrics,
                'best_f1': best_f1,
                'history': stage_history
            }
    
    
    """####### calculate training metrics#############"""
    def _compute_training_metrics_consistent(self, X_train_flat, y_train_flat, X_tensor, y_tensor):
        
        self.model.mlnn_engine.eval()
        metrics = {}
        
        with torch.no_grad():
            train_scores = self.model.predict_anomaly_scores(X_train_flat)
            
            train_dual_scores = train_scores['dual_scores']
            train_goe_scores = train_scores['goe_scores'][:len(train_dual_scores)]
            
            y_train_adj = y_train_flat[:len(train_dual_scores)]
            y_train_int = y_train_adj.astype(int)
            
            train_threshold, train_final_scores = TheoremBasedThresholdDynamic.enhanced_synergy_strategy(
                train_goe_scores, train_dual_scores, y_train_int
            )
            
            train_predictions = (train_final_scores > train_threshold).astype(int)
            
            goe_norm = (train_goe_scores - np.min(train_goe_scores)) / (np.max(train_goe_scores) - np.min(train_goe_scores) + 1e-8)
            goe_threshold, goe_final_scores = TheoremBasedThresholdDynamic.enhanced_synergy_strategy(
                goe_norm, goe_norm, y_train_int
            )
            goe_predictions = (goe_final_scores > goe_threshold).astype(int)
            
            mlnn_probabilities = train_scores['mlnn_scores'][:len(train_dual_scores)]
            mlnn_norm = (mlnn_probabilities - np.min(mlnn_probabilities)) / (np.max(mlnn_probabilities) - np.min(mlnn_probabilities) + 1e-8)
            mlnn_threshold, mlnn_final_scores = TheoremBasedThresholdDynamic.enhanced_synergy_strategy(
                mlnn_norm, mlnn_norm, y_train_int
            )
            mlnn_predictions = (mlnn_final_scores > mlnn_threshold).astype(int)

            metrics['train_dual_accuracy'] = accuracy_score(y_train_int, train_predictions)
            metrics['train_dual_precision'] = precision_score(y_train_int, train_predictions, zero_division=0)
            metrics['train_dual_recall'] = recall_score(y_train_int, train_predictions, zero_division=0)
            metrics['train_dual_f1'] = f1_score(y_train_int, train_predictions, zero_division=0)
            metrics['train_dual_gmean'] = calculate_gmean(y_train_int, train_predictions)
            metrics['train_dual_threshold'] = train_threshold
            
            metrics['train_mlnn_accuracy'] = accuracy_score(y_train_int, mlnn_predictions)
            metrics['train_mlnn_precision'] = precision_score(y_train_int, mlnn_predictions, zero_division=0)
            metrics['train_mlnn_recall'] = recall_score(y_train_int, mlnn_predictions, zero_division=0)
            metrics['train_mlnn_f1'] = f1_score(y_train_int, mlnn_predictions, zero_division=0)
            metrics['train_mlnn_gmean'] = calculate_gmean(y_train_int, mlnn_predictions)
            metrics['train_mlnn_threshold'] = mlnn_threshold
            
            metrics['train_goe_accuracy'] = accuracy_score(y_train_int, goe_predictions)
            metrics['train_goe_precision'] = precision_score(y_train_int, goe_predictions, zero_division=0)
            metrics['train_goe_recall'] = recall_score(y_train_int, goe_predictions, zero_division=0)
            metrics['train_goe_f1'] = f1_score(y_train_int, goe_predictions, zero_division=0)
            metrics['train_goe_gmean'] = calculate_gmean(y_train_int, goe_predictions)
            metrics['train_goe_threshold'] = goe_threshold
            
            metrics['train_dual_scores_mean'] = np.mean(train_final_scores)
            metrics['train_dual_scores_std'] = np.std(train_final_scores)
            metrics['train_anomaly_rate'] = np.mean(y_train_int)
        
        self.model.mlnn_engine.train()
        return metrics
        
        
    def _save_training_metrics_to_csv(self, csv_path, stage, epoch, train_metrics, mlnn_loss, goe_loss, dual_loss, is_header):
        """ ################## save training metrics to CSV file #####################"""
        engines = ['mlnn', 'goe', 'dual']
        
        mode = 'a' if not is_header else 'w'
        
        with open(csv_path, mode, newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            
            if is_header:
                writer.writerow(['stage', 'epoch', 'engine', 'accuracy', 'precision', 'recall', 'f1', 'gmean', 'threshold', 'loss'])
            
            for engine in engines:
                row = [
                    stage,
                    epoch,
                    engine,
                    train_metrics.get(f'train_{engine}_accuracy', 0.0),
                    train_metrics.get(f'train_{engine}_precision', 0.0),
                    train_metrics.get(f'train_{engine}_recall', 0.0),
                    train_metrics.get(f'train_{engine}_f1', 0.0),
                    train_metrics.get(f'train_{engine}_gmean', 0.0),
                    train_metrics.get(f'train_{engine}_threshold', 0.0),
                    mlnn_loss if engine == 'mlnn' else (goe_loss if engine == 'goe' else dual_loss)
                ]
                writer.writerow(row)
                
                
    
    def _create_sequences(self, X, sequence_length):
        """Create time sequences"""
        sequences = []
        for i in range(len(X) - sequence_length + 1):
            sequences.append(X[i:i+sequence_length])
        if not sequences:
            sequences = [X]
        return np.array(sequences)
    
    
    def _create_sequence_labels(self, y, sequence_length):
        """Create sequence labels"""
        if len(y) <= sequence_length:
            return y[-1:] if len(y) > 0 else np.array([0])
        return y[sequence_length-1:]
    
    
    def _assign_global_epochs(self, df):
        current_global_epoch = 0
        stage_epoch_combos = df[['stage', 'epoch']].drop_duplicates().sort_values(['stage', 'epoch'])
        
        # Create a mapping dictionary
        stage_epoch_to_global = {}
        for _, row in stage_epoch_combos.iterrows():
            stage, epoch = row['stage'], row['epoch']
            stage_epoch_to_global[(stage, epoch)] = current_global_epoch
            current_global_epoch += 1
        
        global_epochs = []
        for _, row in df.iterrows():
            key = (row['stage'], row['epoch'])
            global_epochs.append(stage_epoch_to_global[key])
        
        return global_epochs
    
        
    def _extract_engine_data(self, df):
        """Extract each engine's data from DataFrame"""
        engines = ['mlnn', 'goe', 'dual']
        metrics = ['accuracy', 'precision', 'recall', 'f1', 'gmean', 'loss']
        
        # Initialize data structure - use dictionary to store lists
        engine_data = {engine: {metric: {'epochs': [], 'values': []} for metric in metrics} for engine in engines}

        # Fill data by engine and global epoch
        for engine in engines:
            engine_df = df[df['engine'] == engine]
            if len(engine_df) > 0:
                # Ensure sorted by global epoch
                engine_df = engine_df.sort_values('global_epoch')
                
                for metric in metrics:
                    if metric in engine_df.columns:
                        # Get all non-NaN values
                        metric_series = engine_df[['global_epoch', metric]].dropna()
                        
                        if len(metric_series) > 0:
                            engine_data[engine][metric]['epochs'] = metric_series['global_epoch'].tolist()
                            engine_data[engine][metric]['values'] = metric_series[metric].tolist()

        return engine_data
'''======================================================================================================='''



  
'''   save training and validation resutls and training time and inference time  ''' 
'''======================================================================================================='''    
    
def plot_train_test_time(model, X_train, y_train, X_val, y_val):
    """Calculate and save training/inference times and validation results"""
    
    print("\nCalculating training and inference times...")
    
    # 1. Get training time (from training history)
    training_times = {}
    
    if hasattr(model, 'training_history'):
        history = model.training_history
        
        # GOE training time
        if 'goe_training_time' in history:
            training_times['goe'] = history['goe_training_time']
        else:
            # If not recorded, estimate GOE training time
            start_time = time.time()
            model.goe_engine.fit(X_train)
            training_times['goe'] = time.time() - start_time
        
        # MLNN training time
        if 'mlnn_training_time' in history:
            training_times['mlnn'] = history['mlnn_training_time']
        else:
            training_times['mlnn'] = 0  # If not recorded, set to 0
        
        # Dual total training time
        if 'total_training_time' in history:
            training_times['dual'] = history['total_training_time']
        else:
            # Estimate as GOE+MLNN time
            training_times['dual'] = training_times['goe'] + training_times['mlnn']
    else:
        # If training history does not exist, remeasure
        print("Training history not found, measuring times...")
        
        # GOE training time
        start_time = time.time()
        model.goe_engine.fit(X_train)
        training_times['goe'] = time.time() - start_time
        
        # MLNN training time (estimate)
        training_times['mlnn'] = 0  # Simplified processing
        
        # Dual total training time
        training_times['dual'] = training_times['goe'] + training_times['mlnn']
    
    # 2. Calculate inference time
    inference_times = {}
    n_samples = len(X_val)
    
    # GOE inference time
    start_time = time.time()
    goe_scores = model.goe_engine.compute_anomaly_scores(X_val)
    inference_times['goe'] = time.time() - start_time
    
    # MLNN inference time
    sequence_length = 5
    X_seq = model._create_sequences(X_val, sequence_length)
    X_tensor = torch.FloatTensor(X_seq).to(model.device)
    
    model.mlnn_engine.eval()
    start_time = time.time()
    with torch.no_grad():
        mlnn_scores = model.mlnn_engine(X_tensor)
    inference_times['mlnn'] = time.time() - start_time
    
    # Dual inference time (including fusion)
    start_time = time.time()
    dual_scores = model.predict_anomaly_scores(X_val)
    inference_times['dual'] = time.time() - start_time
    
    # 3. Calculate validation set performance (using dynamic threshold)
    print("\nEvaluating dual engine on validation set with dynamic thresholding...")
    
    # Get dual scores
    dual_scores_val = dual_scores['dual_scores']
    
    # Get corresponding true labels
    min_length = min(len(dual_scores_val), len(y_val))
    dual_scores_val = dual_scores_val[:min_length]
    y_val_adj = y_val[:min_length]
    y_val_int = y_val_adj.astype(int)
    
    # Use EnhancedDualEngineSynergy to get threshold and prediction (using dynamic threshold)
    goe_scores_val = dual_scores['goe_scores'][:min_length]
    mlnn_scores_val = dual_scores['mlnn_scores'][:min_length]
    
    # Get fused scores and threshold (using dynamic threshold)
    threshold, final_scores = EnhancedDualEngineSynergy.adaptive_fusion_strategy(
        goe_scores_val, mlnn_scores_val, y_val_int, use_dynamic=True
    )
    
    # Generate predictions
    predictions = (final_scores > threshold).astype(int)
    
    # Calculate various metrics
    accuracy = accuracy_score(y_val_int, predictions)
    precision = precision_score(y_val_int, predictions, zero_division=0)
    recall = recall_score(y_val_int, predictions, zero_division=0)
    f1 = f1_score(y_val_int, predictions, zero_division=0)
    gmean = calculate_gmean(y_val_int, predictions)
    
    # 4. Save to CSV file
    os.makedirs('CredictCard_results', exist_ok=True)
    
    # 4.1 Save time data
    time_data = {
        'Engine': ['GOE', 'MLNN', 'Dual'],
        'Training_Time_Seconds': [
            training_times['goe'],
            training_times['mlnn'], 
            training_times['dual']
        ],
        'Inference_Time_Seconds': [
            inference_times['goe'],
            inference_times['mlnn'],
            inference_times['dual']
        ],
        'Inference_Speed_SamplesPerSecond': [
            n_samples / inference_times['goe'] if inference_times['goe'] > 0 else 0,
            n_samples / inference_times['mlnn'] if inference_times['mlnn'] > 0 else 0,
            n_samples / inference_times['dual'] if inference_times['dual'] > 0 else 0
        ]
    }
    
    time_df = pd.DataFrame(time_data)
    time_csv_path = 'CredictCard_results/time_results.csv'
    time_df.to_csv(time_csv_path, index=False)
    print(f"Time data saved to: {time_csv_path}")
    
    # Print time information
    print("\n=== Training and Inference Times (Dynamic Threshold) ===")
    print("Engine | Training Time | Inference Time | Inference Speed")
    print("-" * 65)
    for i, engine in enumerate(time_data['Engine']):
        train_time = time_data['Training_Time_Seconds'][i]
        infer_time = time_data['Inference_Time_Seconds'][i]
        speed = time_data['Inference_Speed_SamplesPerSecond'][i]
        print(f"{engine:6s} | {train_time:12.2f}s | {infer_time:13.4f}s | {speed:16.2f} samples/s")
    
    # 4.2 Save validation results
    validation_data = {
        'Metric': ['Accuracy', 'Precision', 'Recall', 'F1-Score', 'G-Mean', 'Threshold'],
        'Value': [accuracy, precision, recall, f1, gmean, threshold],
        'Threshold_Type': ['Dynamic'] * 6
    }
    
    validation_df = pd.DataFrame(validation_data)
    validation_csv_path = 'CredictCard_results/validation_results.csv'
    validation_df.to_csv(validation_csv_path, index=False)
    print(f"\nValidation results saved to: {validation_csv_path}")
    
    
    # 5. Create visualization charts
    fig, axes = plt.subplots(1, 2, figsize=(16, 6))
    
    # 5.1 Time comparison chart
    ax1 = axes[0]
    engines = time_data['Engine']
    training_times_list = time_data['Training_Time_Seconds']
    inference_times_list = time_data['Inference_Time_Seconds']
    
    x = np.arange(len(engines))
    width = 0.35
    
    bars1 = ax1.bar(x - width/2, training_times_list, width, label='Training Time', color='skyblue', alpha=0.8)
    bars2 = ax1.bar(x + width/2, inference_times_list, width, label='Inference Time', color='lightcoral', alpha=0.8)
    
    ax1.set_xlabel('Engine', fontsize=14, fontweight='bold')
    ax1.set_ylabel('Time (seconds)', fontsize=14, fontweight='bold')
    ax1.set_title('(a) Training and Inference Times Comparison', fontsize=16, fontweight='bold', pad=20)
    ax1.set_xticks(x)
    ax1.set_xticklabels(engines, fontsize=12)
    ax1.legend(fontsize=12)
    ax1.grid(True, alpha=0.3, linestyle='--')
    
    # Add numerical labels on bars
    for bar in bars1:
        height = bar.get_height()
        ax1.annotate(f'{height:.1f}s',
                    xy=(bar.get_x() + bar.get_width() / 2, height),
                    xytext=(0, 3),
                    textcoords="offset points",
                    ha='center', va='bottom', fontsize=10)
    
    for bar in bars2:
        height = bar.get_height()
        ax1.annotate(f'{height:.3f}s',
                    xy=(bar.get_x() + bar.get_width() / 2, height),
                    xytext=(0, 3),
                    textcoords="offset points",
                    ha='center', va='bottom', fontsize=10)
    
    # 5.2 Validation metrics radar chart
    ax2 = axes[1]
    
    # Prepare radar chart data
    metrics = ['Accuracy', 'Precision', 'Recall', 'F1', 'G-Mean']
    values = [accuracy, precision, recall, f1, gmean]
    
    # Complete radar chart
    angles = np.linspace(0, 2 * np.pi, len(metrics), endpoint=False).tolist()
    values += values[:1]  # Close radar chart
    angles += angles[:1]  # Close angles
    
    ax2 = plt.subplot(122, polar=True)
    ax2.plot(angles, values, 'o-', linewidth=2, color='red', alpha=0.8)
    ax2.fill(angles, values, alpha=0.25, color='red')
    ax2.set_thetagrids(np.degrees(angles[:-1]), metrics, fontsize=12)
    
    # Set radar chart range
    ax2.set_ylim(0, 1.0)
    ax2.set_yticks([0.2, 0.4, 0.6, 0.8, 1.0])
    ax2.set_yticklabels(['0.2', '0.4', '0.6', '0.8', '1.0'], fontsize=10)
    ax2.grid(True, alpha=0.3)
    ax2.set_title('(b) Dual Engine Validation Metrics (Dynamic)', fontsize=16, fontweight='bold', pad=20)
    
    # Add numerical labels on radar chart
    for angle, value, metric in zip(angles[:-1], values[:-1], metrics):
        deg_angle = np.degrees(angle)
        ax2.annotate(f'{value:.3f}',
                    xy=(angle, value),
                    xytext=(0, 10),
                    textcoords="offset points",
                    ha='center', va='bottom',
                    fontsize=10,
                    bbox=dict(boxstyle="round,pad=0.2", facecolor="yellow", alpha=0.7))
    
    plt.tight_layout()
    
    # Save chart
    time_plot_path = 'CredictCard_results/time_and_validation.png'
    plt.savefig(time_plot_path, dpi=600, bbox_inches='tight')
    print(f"\nTime and validation plot saved to: {time_plot_path}")
    
    plt.show()
    

    
    results = {
        'time_data': time_data,
        'validation_metrics': {
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1': f1,
            'gmean': gmean,
            'threshold': threshold,
            'threshold_type': 'dynamic'
        },
        'val': {
            'dual': {
                'accuracy': accuracy,
                'precision': precision,
                'recall': recall,
                'f1': f1,
                'gmean': gmean
            }
        }
    }
    
    return results
'''======================================================================================================='''
    



'''======================================================================================================='''
'''                    Enhanced Advanced Threshold Analysis Function (2x2 layout)                   '''
'''======================================================================================================='''

"""Function to plot dynamic threshold evolution and confidence levels"""

def plot_advanced_threshold_analysis(dynamic_thresholder, save_path='CredictCard_results/advanced_threshold_analysis.png'):
    """
    Advanced analysis of threshold dynamics including drift detection - 2x2 layout
    
    Parameters:
    dynamic_thresholder: DynamicAdaptiveThreshold object
    save_path: Path to save the plot
    """
    if not hasattr(dynamic_thresholder, 'threshold_history') or len(dynamic_thresholder.threshold_history) < 20:
        print("Not enough threshold history for advanced analysis")
        return
    
    thresholds = np.array(dynamic_thresholder.threshold_history)
    samples = np.arange(len(thresholds))
    
    # Calculate statistics
    threshold_mean = np.mean(thresholds)
    threshold_std = np.std(thresholds)
    
    # Calculate rolling statistics
    window_size = min(20, len(thresholds) // 5)
    rolling_mean = []
    rolling_std = []
    
    for i in range(len(thresholds)):
        start_idx = max(0, i - window_size)
        window = thresholds[start_idx:i+1]
        rolling_mean.append(np.mean(window))
        rolling_std.append(np.std(window))
    
    rolling_mean = np.array(rolling_mean)
    rolling_std = np.array(rolling_std)
    
    # Detect significant changes
    significant_changes = []
    change_magnitudes = []
    
    for i in range(1, len(thresholds)):
        change_pct = abs((thresholds[i] - thresholds[i-1]) / (thresholds[i-1] + 1e-8))
        if change_pct > 0.1:  # More than 10% change
            significant_changes.append(i)
            change_magnitudes.append(change_pct)
    
    # Get confidence history if available
    if hasattr(dynamic_thresholder, 'confidence_history') and len(dynamic_thresholder.confidence_history) > 0:
        confidence_values = dynamic_thresholder.confidence_history[:len(thresholds)]
    else:
        # Generate synthetic confidence values
        confidence_values = []
        for i in range(len(thresholds)):
            if i < 10:
                confidence_values.append(0.5 + 0.3 * (i / 10))
            else:
                recent = thresholds[max(0, i-5):i+1]
                stability = 1.0 / (1.0 + np.std(recent))
                confidence_values.append(stability)
    
    # Ensure confidence values are in valid range
    confidence_values = np.clip(confidence_values, 0.0, 1.0)
    
    # Create figure with 2x2 layout
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    
    # Plot 1: Threshold Evolution with Rolling Statistics (top-left)
    ax1 = axes[0]
    
    # Plot main threshold line
    ax1.plot(samples, thresholds, 
             color='#1f77b4',  # Nature blue
             linewidth=3,
             alpha=0.9,
             label='Dynamic Threshold',
             zorder=3)
    
    # Plot rolling mean
    ax1.plot(samples, rolling_mean,
             color='#d62728',  # Nature red
             linewidth=2.5,
             linestyle='--',
             alpha=0.8,
             label='Rolling Mean',
             zorder=4)
    
    # Plot confidence band (mean ± 1 std)
    ax1.fill_between(samples, 
                     rolling_mean - rolling_std,
                     rolling_mean + rolling_std,
                     color='#1f77b4',
                     alpha=0.3,
                     label='95% Confidence Band',
                     zorder=2)
    
    # Mark significant changes
    if significant_changes:
        for i, change_idx in enumerate(significant_changes[:3]):  # Show first 3 significant changes
            ax1.scatter(change_idx, thresholds[change_idx],
                       color='#ff7f0e',  # Nature orange
                       s=100,
                       edgecolors='black',
                       linewidth=1.5,
                       zorder=5,
                       label=f'Major Change ({change_magnitudes[i]:.1%})' if i == 0 else None)
    
    # Customize Plot 1
    ax1.set_xlabel('Samples', fontsize=16, labelpad=10)
    ax1.set_ylabel('Threshold Value', fontsize=16, labelpad=10)
    ax1.set_title('(a) Threshold Evolution with Rolling Statistics', 
                 fontsize=16, fontweight='bold', pad=15)
    
    ax1.tick_params(axis='both', labelsize=16)
    ax1.grid(True, alpha=0.3, linestyle='--')
    ax1.legend(loc='upper right', fontsize=16, framealpha=0.95)
    
    
    
    
    # Plot 2: Confidence Level Evolution (bottom-right) - Moved from threshold_confidence
    ax2 = axes[1]
    
    # Plot confidence line
    ax2.plot(samples, confidence_values,
            color='black',  # Nature green
            linewidth=3,
            alpha=0.9,
            label='Threshold Confidence',
            zorder=3)
    
    # Add fill under confidence curve
    ax2.fill_between(samples, 0, confidence_values,
                    color='gray',
                    alpha=0.4,
                    zorder=2)
    
    # Add horizontal reference lines
    ax2.axhline(y=0.9, color='#d62728', linestyle=':', linewidth=2, alpha=0.9, label='High Confidence (0.9)')
    ax2.axhline(y=0.7, color='#ff7f0e', linestyle=':', linewidth=3, alpha=0.9, label='Medium Confidence (0.7)')
    ax2.axhline(y=0.5, color='#1f77b4', linestyle=':', linewidth=3, alpha=0.9, label='Low Confidence (0.5)')
    
    # Add confidence statistics
    avg_confidence = np.mean(confidence_values)
    ax2.axhline(y=avg_confidence, color='blue', linestyle='--', linewidth=3, alpha=0.9, 
                label=f'Avg Confidence: {avg_confidence:.3f}')
    
    # Customize Plot 4
    ax2.set_xlabel('Samples', fontsize=16, labelpad=10)
    ax2.set_ylabel('Confidence Level', fontsize=16,  labelpad=10)
    ax2.set_title('(d) Threshold Confidence Evolution', 
                 fontsize=16, fontweight='bold', pad=15)
    
    # Set y-limits and ticks
    ax2.set_ylim(0, 1.05)
    ax2.set_yticks([0, 0.2, 0.4, 0.6, 0.8, 1.0])
    ax2.set_yticklabels(['0.0', '0.2', '0.4', '0.6', '0.8', '1.0'], fontsize=16)
    
    # Set tick parameters with larger labels
    ax2.tick_params(axis='both', labelsize=16)
    ax2.tick_params(axis='both',  labelsize=16)
    
    # Add grid
    ax2.grid(True, alpha=0.3, linestyle='--', linewidth=0.5)
    
    # Add legend
    ax2.legend(loc='lower right', fontsize=16, framealpha=0.95, frameon=True)
    
    # Adjust layout
    plt.tight_layout(pad=3.0)
    
    # Save figure
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path, dpi=600, bbox_inches='tight', facecolor='white', edgecolor='none')
    
    print(f"Advanced threshold analysis (2x2 layout) saved to: {save_path}")
    
    # Create and save detailed analysis report
    save_threshold_analysis_report(dynamic_thresholder, thresholds, confidence_values, 
                                 significant_changes, change_magnitudes, save_path.replace('.png', '_report.txt'))
    
    # Show plot
    plt.show()
    
    return fig


def save_threshold_analysis_report(dynamic_thresholder, thresholds, confidence_values,
                                 significant_changes, change_magnitudes, save_path='CredictCard_results/threshold.txt'):
    """
    Save detailed threshold analysis report
    
    Parameters:
    dynamic_thresholder: DynamicAdaptiveThreshold object
    thresholds: Array of threshold values
    confidence_values: Array of confidence values
    significant_changes: List of indices where significant changes occurred
    change_magnitudes: List of change magnitudes
    save_path: Path to save the report
    """
    
    print(f"\nGenerating detailed threshold analysis report...")
    
    # Calculate statistics
    threshold_mean = np.mean(thresholds)
    threshold_std = np.std(thresholds)
    threshold_min = np.min(thresholds)
    threshold_max = np.max(thresholds)
    threshold_range = threshold_max - threshold_min
    
    confidence_mean = np.mean(confidence_values)
    confidence_std = np.std(confidence_values)
    confidence_min = np.min(confidence_values)
    confidence_max = np.max(confidence_values)
    
    # Calculate stability metrics
    threshold_stability = 1.0 / (1.0 + threshold_std)  # Higher stability when std is lower
    confidence_stability = 1.0 / (1.0 + confidence_std)
    
    # Calculate adaptation metrics
    if len(significant_changes) > 0:
        avg_change_magnitude = np.mean(change_magnitudes)
        max_change_magnitude = np.max(change_magnitudes)
        change_frequency = len(significant_changes) / len(thresholds)
    else:
        avg_change_magnitude = 0
        max_change_magnitude = 0
        change_frequency = 0
    
    with open(save_path, 'w', encoding='utf-8') as f:
        # Write header
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        f.write("="*80 + "\n")
        f.write("DYNAMIC THRESHOLD ANALYSIS REPORT\n")
        f.write(f"Generated: {current_time}\n")
        f.write("="*80 + "\n\n")
        
        # 1. Executive Summary
        f.write("1. EXECUTIVE SUMMARY\n")
        f.write("-"*80 + "\n")
        f.write("This report provides a comprehensive analysis of the dynamic threshold adaptation\n")
        f.write("mechanism used in the Dual-Engine Anomaly Detection Framework. The analysis covers\n")
        f.write("threshold evolution, confidence levels, stability metrics, and adaptation patterns.\n\n")
        
        # 2. Threshold Statistics
        f.write("2. THRESHOLD STATISTICS\n")
        f.write("-"*80 + "\n")
        f.write(f"• Total samples analyzed: {len(thresholds)}\n")
        f.write(f"• Mean threshold value: {threshold_mean:.6f}\n")
        f.write(f"• Standard deviation: {threshold_std:.6f}\n")
        f.write(f"• Minimum threshold: {threshold_min:.6f}\n")
        f.write(f"• Maximum threshold: {threshold_max:.6f}\n")
        f.write(f"• Threshold range: {threshold_range:.6f}\n")
        f.write(f"• Threshold stability index: {threshold_stability:.4f} (0-1, higher is more stable)\n\n")
        
        # 3. Confidence Statistics
        f.write("3. CONFIDENCE STATISTICS\n")
        f.write("-"*80 + "\n")
        f.write(f"• Mean confidence level: {confidence_mean:.4f}\n")
        f.write(f"• Confidence standard deviation: {confidence_std:.4f}\n")
        f.write(f"• Minimum confidence: {confidence_min:.4f}\n")
        f.write(f"• Maximum confidence: {confidence_max:.4f}\n")
        f.write(f"• Confidence stability index: {confidence_stability:.4f} (0-1, higher is more stable)\n\n")
        
        # 4. Adaptation Analysis
        f.write("4. ADAPTATION ANALYSIS\n")
        f.write("-"*80 + "\n")
        f.write(f"• Number of significant changes (>10%): {len(significant_changes)}\n")
        if len(significant_changes) > 0:
            f.write(f"• Average change magnitude: {avg_change_magnitude:.2%}\n")
            f.write(f"• Maximum change magnitude: {max_change_magnitude:.2%}\n")
            f.write(f"• Change frequency: {change_frequency:.4f} changes per sample\n")
            
            # Identify major adaptation events
            f.write(f"\n• Major adaptation events (top 3):\n")
            top_changes = sorted(zip(significant_changes, change_magnitudes), 
                               key=lambda x: x[1], reverse=True)[:3]
            for i, (idx, magnitude) in enumerate(top_changes, 1):
                f.write(f"  {i}. Sample {idx}: {magnitude:.2%} change\n")
        else:
            f.write("• No significant adaptation events detected\n")
        f.write("\n")
        
        # 5. Performance Evaluation
        f.write("5. PERFORMANCE EVALUATION\n")
        f.write("-"*80 + "\n")
        
        # Evaluate threshold stability
        if threshold_std < 0.01:
            stability_rating = "Excellent"
            stability_reason = "Threshold shows very low variability, indicating stable operation."
        elif threshold_std < 0.05:
            stability_rating = "Good"
            stability_reason = "Threshold shows moderate variability, within acceptable range."
        else:
            stability_rating = "Needs Improvement"
            stability_reason = "Threshold shows high variability, may indicate over-adaptation."
        
        f.write(f"• Threshold Stability: {stability_rating}\n")
        f.write(f"  - Reason: {stability_reason}\n")
        
        # Evaluate confidence levels
        if confidence_mean > 0.8:
            confidence_rating = "High"
            confidence_reason = "System shows high confidence in threshold decisions."
        elif confidence_mean > 0.6:
            confidence_rating = "Moderate"
            confidence_reason = "System shows reasonable confidence in threshold decisions."
        else:
            confidence_rating = "Low"
            confidence_reason = "System shows low confidence, may need more data for reliable thresholds."
        
        f.write(f"• Confidence Level: {confidence_rating}\n")
        f.write(f"  - Reason: {confidence_reason}\n")
        
        # Evaluate adaptation pattern
        if change_frequency > 0.1:
            adaptation_rating = "Over-sensitive"
            adaptation_reason = "System adapts too frequently, may be reacting to noise."
        elif change_frequency > 0.01:
            adaptation_rating = "Well-tuned"
            adaptation_reason = "System shows appropriate adaptation to data changes."
        else:
            adaptation_rating = "Under-sensitive"
            adaptation_reason = "System adapts too slowly, may miss important data shifts."
        
        f.write(f"• Adaptation Pattern: {adaptation_rating}\n")
        f.write(f"  - Reason: {adaptation_reason}\n")
        f.write("\n")
        
        # 6. Recommendations
        f.write("6. RECOMMENDATIONS\n")
        f.write("-"*80 + "\n")
        
        recommendations = []
        
        # Threshold stability recommendations
        if threshold_std > 0.05:
            recommendations.append("Consider increasing the adaptation smoothing factor to reduce threshold volatility")
        
        # Confidence recommendations
        if confidence_mean < 0.6:
            recommendations.append("Increase the window size for threshold calculation to improve confidence")
            recommendations.append("Consider adjusting the base percentile based on expected anomaly rate")
        
        # Adaptation recommendations
        if change_frequency > 0.1:
            recommendations.append("Decrease the adaptation rate to reduce sensitivity to minor fluctuations")
        elif change_frequency < 0.001:
            recommendations.append("Increase the adaptation rate to better track data distribution changes")
        
        # Drift detection recommendations
        if len(significant_changes) == 0 and len(thresholds) > 100:
            recommendations.append("Consider making drift detection more sensitive to catch subtle changes")
        
        if recommendations:
            for i, rec in enumerate(recommendations, 1):
                f.write(f"{i}. {rec}\n")
        else:
            f.write("No major adjustments needed. Current parameters appear well-tuned.\n")
        
        f.write("\n")
        
        # 7. Configuration Parameters
        f.write("7. CONFIGURATION PARAMETERS\n")
        f.write("-"*80 + "\n")
        if hasattr(dynamic_thresholder, 'window_size'):
            f.write(f"• Window size: {dynamic_thresholder.window_size}\n")
        if hasattr(dynamic_thresholder, 'base_percentile'):
            f.write(f"• Base percentile: {dynamic_thresholder.base_percentile}\n")
        if hasattr(dynamic_thresholder, 'adaptation_rate'):
            f.write(f"• Adaptation rate: {dynamic_thresholder.adaptation_rate}\n")
        
        f.write("\n")
        
        # 8. Conclusion
        f.write("8. CONCLUSION\n")
        f.write("-"*80 + "\n")
        f.write("The dynamic threshold mechanism demonstrates ")
        
        overall_rating = []
        if threshold_stability > 0.7:
            overall_rating.append("good stability")
        if confidence_mean > 0.7:
            overall_rating.append("high confidence")
        if 0.01 <= change_frequency <= 0.1:
            overall_rating.append("appropriate adaptation")
        
        if overall_rating:
            f.write(f"{', '.join(overall_rating)}. ")
        else:
            f.write("moderate performance. ")
        
        f.write("The system effectively balances stability and adaptability,\n")
        f.write("making it suitable for financial anomaly detection in non-stationary environments.\n")
        
        f.write("\n" + "="*80 + "\n")
        f.write("END OF REPORT\n")
        f.write("="*80 + "\n")
    
    print(f"Detailed threshold analysis report saved to: {save_path}")
    print(f"Report summary:")
    print(f"  - Threshold stability: {threshold_stability:.4f}")
    print(f"  - Confidence level: {confidence_mean:.4f}")
    print(f"  - Adaptation events: {len(significant_changes)}")
    
    return save_path
'''======================================================================================================='''



'''======================================================================================================='''

def highlight_subplot_border(ax, linewidth=1.5, color='#000000', alpha=1.0):
    ax.spines['top'].set_linewidth(linewidth)
    ax.spines['top'].set_color(color)
    ax.spines['top'].set_alpha(alpha)
    
    ax.spines['right'].set_linewidth(linewidth)
    ax.spines['right'].set_color(color)
    ax.spines['right'].set_alpha(alpha)
    
    ax.spines['bottom'].set_linewidth(linewidth)
    ax.spines['bottom'].set_color(color)
    ax.spines['bottom'].set_alpha(alpha)
    
    ax.spines['left'].set_linewidth(linewidth)
    ax.spines['left'].set_color(color)
    ax.spines['left'].set_alpha(alpha)
    
    for spine in ax.spines.values():
        spine.set_zorder(10)
    
    return ax



def predict_with_drift_adaptation(model, X_test, val_dual_scores, val_threshold, 
                                   adaptation_method='percentile',  
                                   target_percentile=99.0):
    """
    Adaptively adjust the threshold during testing to cope with data drift.
    """
    scores = model.predict_anomaly_scores(X_test, use_dynamic_threshold=False)
    test_dual_scores = scores['dual_scores']
    
    if adaptation_method == 'percentile':
        percentile = np.sum(val_dual_scores <= val_threshold) / len(val_dual_scores) * 100
        adjusted_threshold = np.percentile(test_dual_scores, percentile)
        predictions = (test_dual_scores > adjusted_threshold).astype(int)
        return predictions, adjusted_threshold
    
    elif adaptation_method == 'zscore':
        val_mean, val_std = np.mean(val_dual_scores), np.std(val_dual_scores)
        test_mean, test_std = np.mean(test_dual_scores), np.std(test_dual_scores)
        adjusted_threshold = (val_threshold - val_mean) / val_std * test_std + test_mean
        predictions = (test_dual_scores > adjusted_threshold).astype(int)
        return predictions, adjusted_threshold
    
    else:
        predictions = (test_dual_scores > val_threshold).astype(int)
        return predictions, val_threshold
    

def evaluate_on_test(model, X_test, y_test, val_dual_scores, val_threshold,
                             val_percentile=None, adaptation='percentile_val',
                             save_path='CredictCard_results/Test/result.csv'):
        """
        Evaluate on test set using a fixed threshold.
        
        Parameters:
            model: trained DualEngineADF model
            X_test, y_test: test data
            fixed_threshold: threshold to use for binarization
            save_path: path to save CSV results
        """
        test_scores = model.predict_anomaly_scores(X_test, use_dynamic_threshold=False)
        test_dual = test_scores['dual_scores']

        if adaptation == 'percentile_val':
            if val_percentile is None:
                raise ValueError("val_percentile must be provided for percentile adaptation")
            used_threshold = np.percentile(test_dual, val_percentile)
            print(f"Percentile adaptation (p={val_percentile:.2f}%): test threshold={used_threshold:.6f}")
        else:
            used_threshold = val_threshold
            print(f"No adaptation: test threshold={used_threshold:.6f}")

        min_len = min(len(test_dual), len(y_test))
        test_dual = test_dual[:min_len]
        y_true = y_test[:min_len].astype(int)
        predictions = (test_dual > used_threshold).astype(int)

        from sklearn.metrics import average_precision_score
        auc = roc_auc_score(y_true, test_dual)
        pr_auc = average_precision_score(y_true, test_dual)
        accuracy = accuracy_score(y_true, predictions)
        precision = precision_score(y_true, predictions, zero_division=0)
        recall = recall_score(y_true, predictions, zero_division=0)
        f1 = f1_score(y_true, predictions, zero_division=0)
        gmean = calculate_gmean(y_true, predictions)

        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        results_df = pd.DataFrame({
            'Metric': ['AUC', 'PR-AUC', 'Accuracy', 'Precision', 'Recall', 'F1-Score', 'G-Mean'],
            'Value': [auc, pr_auc, accuracy, precision, recall, f1, gmean]
        })
        results_df.to_csv(save_path, index=False)

        print(f"\n=== Test Results (adaptation={adaptation}) ===")
        print(results_df.to_string(index=False))
        print(f"Used threshold: {used_threshold:.6f}")
        return results_df
    
    
    
def find_optimal_threshold(model, X_val, y_val, metric='f1', num_candidates=100):
    """
    Find optimal threshold on validation set that maximizes the given metric.
    
    Parameters:
        model: trained DualEngineADF model
        X_val, y_val: validation data
        metric: one of 'f1', 'gmean', 'recall', 'precision', 'accuracy'
        num_candidates: number of threshold candidates to evaluate
    
    Returns:
        best_threshold: float
        best_score: float
    """
    scores = model.predict_anomaly_scores(X_val, use_dynamic_threshold=False)
    dual_scores = scores['dual_scores']
    min_len = min(len(dual_scores), len(y_val))
    dual_scores = dual_scores[:min_len]
    y_val = y_val[:min_len].astype(int)

    low_percentile, high_percentile = 80, 99.9
    low = np.percentile(dual_scores, low_percentile)
    high = np.percentile(dual_scores, high_percentile)
    if high <= low:
        low, high = np.min(dual_scores), np.max(dual_scores)

    thresholds = np.linspace(low, high, num_candidates)
    best_th = thresholds[0]
    best_score = 0.0

    for th in thresholds:
        pred = (dual_scores > th).astype(int)
        if metric == 'f1':
            score = f1_score(y_val, pred, zero_division=0)
        elif metric == 'gmean':
            score = calculate_gmean(y_val, pred)
        elif metric == 'recall':
            score = recall_score(y_val, pred, zero_division=0)
        elif metric == 'precision':
            score = precision_score(y_val, pred, zero_division=0)
        else:
            score = accuracy_score(y_val, pred)
        if score > best_score:
            best_score = score
            best_th = th

    # 计算最优阈值对应的百分位
    percentile = np.sum(dual_scores <= best_th) / len(dual_scores) * 100

    print(f"Best threshold on validation set ({metric}): {best_th:.6f} with score {best_score:.4f}, percentile={percentile:.2f}%")
    return best_th, best_score, dual_scores, percentile
    




'''======================================================================================================='''
'''                            Main function               '''

def main():
    """Main function for training and evaluation with dynamic thresholding"""
    print("=== Dual-Engine Anomaly Detection Framework with Dynamic Thresholding ===")
    
    def set_seed(seed=42):
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)

    set_seed(42)

    processor = DataProcessor()
    processed_data = processor.load_and_preprocess_data()

    if processed_data is None:
        print("Data loading failed, exiting program")
        return

    X_train, y_train, X_val, y_val, X_test, y_test = processed_data

    y_train = ensure_numpy_array(y_train)
    y_val = ensure_numpy_array(y_val)
    y_test = ensure_numpy_array(y_test)

    input_size = X_train.shape[1]
    print(f"Input dimension: {input_size}")

    print("\nTraining dEADF model with dynamic thresholding...")
    os.makedirs('CredictCard_results', exist_ok=True)
    dEADF_model = DualEngineADF(input_size=input_size, perturbation_strength=0.1, lambda_reg=0.1, window_size=500)
    dEADF_model.fit(X_train, y_train, X_val, y_val, use_progressive_training=True)
    dEADF_model.save_model('./CredictCard_results/dEADF_model_CredictCard.pth')


    print("\n" + "="*60)
    print("Finding optimal threshold on validation set...")

    best_th_gmean, best_gmean_score, val_dual_scores, percentile_gmean = find_optimal_threshold(
        dEADF_model, X_val, y_val, metric='gmean', num_candidates=200
    )
    
    
    print("\n" + "="*60)
    print("Evaluating on test set with percentile adaptation (based on G-mean)...")
    evaluate_on_test(
        dEADF_model, X_test, y_test, val_dual_scores, best_th_gmean,
        val_percentile=percentile_gmean, adaptation='percentile_val',
        save_path='CredictCard_results/Test/result_final.csv'
    )

    

    
    '''                      genearte training and  valiaiton results and inference and training time            '''
    print("\n...Training Completed !...")
    _plot_metric = plot_train_test_time(dEADF_model, X_train, y_train, X_val, y_val)
        
    
    '''                        invoke training process                     '''
    if hasattr(dEADF_model.progressive_trainer, 'training_visualization_chart_consistent'):
        csv_path = 'CredictCard_results/training_metrics_consistent.csv'
        if os.path.exists(csv_path):
            dEADF_model.progressive_trainer.training_visualization_chart_consistent()
        else:
            print(f"Training metrics CSV not found: {csv_path}, skipping visualization.")

        
        
    '''                        Plot threshold confidence and evolution                    '''
    print("\nPlotting dynamic threshold evolution and confidence...")
    if hasattr(dEADF_model, 'dynamic_thresholder'):
        # Plot basic threshold confidence
       plot_advanced_threshold_analysis(
           dynamic_thresholder=dEADF_model.dynamic_thresholder,
           save_path='CredictCard_results/advanced_threshold_analysis.png'
        )
        
    print("\nFinal performance evaluation with dynamic thresholding...")
    baseline_metrics = _plot_metric['val']['dual']
    

    test_predictions = dEADF_model.predict_anomaly_scores(X_test)
    
    
    print("\n" + "="*80)
    print("Evaluating on test set...")
#    test_results = evaluate_on_test(dEADF_model, X_test, y_test)
    print("="*80)
        
    return dEADF_model, _plot_metric
'''======================================================================================================='''



if __name__ == "__main__":
    model, _plot_metric = main()