# -*- coding: utf-8 -*-
"""
Created on Tue Dec 16 22:04:30 2025

@author: hp
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

class DataProcessor:
 
    
    def __init__(self):
        self.scaler = StandardScaler()
        self.attribute_columns = None
        
    def load_and_preprocess_data(self):

        try:

            print("正在加载训练数据...")
            train_data = pd.read_csv('./DataSample/trainingSample.csv', skiprows=1, header=None)
            train_data = train_data.iloc[:, :-2]   
            
            train_labels = pd.read_csv('./DataSample/trainingLabel.csv', skiprows=1, header=None)
            
            print("Loading data...")
            val_data = pd.read_csv('./DataSample/validationSample.csv', skiprows=1, header=None)
            val_data = val_data.iloc[:, :-2]   
            val_labels = pd.read_csv('./DataSample/validationLabel.csv', skiprows=1, header=None)
            

            print("Loading testing data...")
            test_data = pd.read_csv('./DataSample/smalltestSample.csv', skiprows=1, header=None)
            test_data = test_data.iloc[:, :-2]   
            
            test_labels = pd.read_csv('./DataSample/smalltestLabel.csv', skiprows=1, header=None)
            

            
        except FileNotFoundError as e:
            print(f"file error: {e}")
            return None
        
 
        self.attribute_columns = list(range(train_data.shape[1]))
        
        print(f"find {len(self.attribute_columns)} attributes")
        print(f"training data shape: {train_data.shape}")
        print(f"validation data shape: {val_data.shape}")
        print(f"testing data shape: {test_data.shape}")
        
 
        X_train = train_data.values.astype(float)
        X_val = val_data.values.astype(float)
        X_test = test_data.values.astype(float)
        
        y_train = train_labels.values.flatten().astype(int)
        y_val = val_labels.values.flatten().astype(int)
        y_test = test_labels.values.flatten().astype(int)
        
        
 
        print("stander data...")
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_val_scaled = self.scaler.transform(X_val)
        X_test_scaled = self.scaler.transform(X_test)
        
        print(f"training data shape: {X_train_scaled.shape}, 标签形状: {y_train.shape}")
        print(f"validation data shape: {X_val_scaled.shape}, 标签形状: {y_val.shape}")
        print(f"testing data shape: {X_test_scaled.shape}, 标签形状: {y_test.shape}")
        
        self._check_data_quality(X_train_scaled, X_val_scaled, X_test_scaled, y_train, y_val, y_test)

        return X_train_scaled, y_train, X_val_scaled, y_val , X_test_scaled, y_test


    
    def _check_data_quality(self, X_train, X_val, X_test, y_train, y_val, y_test):

        """check data"""
        print("\n=== data check ===")
        print(f"training data - NaN values: {np.isnan(X_train).sum()}, Inf values: {np.isinf(X_train).sum()}")
        print(f"validation data - NaN values: {np.isnan(X_val).sum()}, Inf values: {np.isinf(X_val).sum()}")
        print(f"testing data - NaN values: {np.isnan(X_test).sum()}, Inf values: {np.isinf(X_test).sum()}")
        
 
        unique_train, counts_train = np.unique(y_train, return_counts=True)
        unique_val, counts_val = np.unique(y_val, return_counts=True)
        unique_test, counts_test = np.unique(y_test, return_counts=True)
        
        
        print(f"training lable distribution: {dict(zip(unique_train, counts_train))}")
        print(f"validation lable distribution: {dict(zip(unique_val, counts_val))}")
        print(f"testing lable distribution: {dict(zip(unique_test, counts_test))}")
        

        print(f"Range of training set features: [{X_train.min():.4f}, {X_train.max():.4f}]")
        print(f"Mean of training set features: {X_train.mean():.4f} ± {X_train.std():.4f}")
        

 
if __name__ == "__main__":
    processor = DataProcessor()
    processed_data = processor.load_and_preprocess_data()
    
    if processed_data is not None:
        print("finish data process!")
    else:
        print("data process failure!")