# G3AD_fixed.py
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch_geometric.nn import GATConv, GCNConv
import matplotlib.pyplot as plt
import pandas as pd
import time
import os
from tqdm import tqdm

# 读取数据集（保持不变）
'''======================================================================================================='''
'''                                           Read dataset                       '''
#from ReadFinanceDataSet import DataProcessor 

'''################################## Credit Card #####################'''
from ReadCreditcardDataset import DataProcessor


'''################################## Network Attack #####################'''
#from ReadCoAtSetDataset import DataProcessor

# ------------------------------------------
# 早停机制（保持不变）
class EarlyStopping:
    def __init__(self, patience=10, min_delta=0.001, mode='min'):
        self.patience = patience
        self.min_delta = min_delta
        self.mode = mode
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.best_model_state = None
        if mode == 'min':
            self.monitor_op = np.less
            self.best_score = np.inf
        else:
            self.monitor_op = np.greater
            self.best_score = -np.inf

    def __call__(self, current_score, model=None):
        if self.monitor_op(current_score - self.min_delta, self.best_score):
            self.best_score = current_score
            self.counter = 0
            if model is not None:
                self.best_model_state = model.state_dict().copy()
        else:
            self.counter += 1
            if self.counter >= self.patience:
                self.early_stop = True
        return self.early_stop

    def restore_best_model(self, model):
        if self.best_model_state is not None:
            model.load_state_dict(self.best_model_state)

# ------------------------------------------
# 图构建器（保持不变）
class GraphBuilder:
    @staticmethod
    def build_simple_graph(n_nodes, avg_degree=5):
        edges = []
        for i in range(n_nodes):
            j = (i + 1) % n_nodes
            edges.append([i, j])
            edges.append([j, i])
        n_additional = int(n_nodes * avg_degree / 2) - n_nodes
        for _ in range(n_additional):
            i, j = np.random.randint(0, n_nodes, size=2)
            if i != j:
                edges.append([i, j])
                edges.append([j, i])
        edge_index = np.array(edges).T
        return edge_index

# ------------------------------------------
# 子模块定义（GATEncoder, ACModule, GCNReconstructor 完全不变）
class GATEncoder(nn.Module):
    def __init__(self, in_features, out_features, heads=8):
        super(GATEncoder, self).__init__()
        self.conv1 = GATConv(in_features, out_features // heads, heads=heads)
        self.conv2 = GATConv(out_features, out_features, heads=1, concat=False)

    def forward(self, x, edge_index):
        x = F.elu(self.conv1(x, edge_index))
        x = self.conv2(x, edge_index)
        return x

class ACModule(nn.Module):
    def __init__(self, hidden_dim):
        super(ACModule, self).__init__()
        self.fusion_mlp = nn.Linear(2 * hidden_dim, 1)

    def forward(self, H1, H2):
        concat_features = torch.cat([H1, H2], dim=1)
        imp = torch.tanh(self.fusion_mlp(concat_features))
        return imp * H1 + (1 - imp) * H2

class GCNReconstructor(nn.Module):
    def __init__(self, in_features, out_features):
        super(GCNReconstructor, self).__init__()
        self.conv1 = GCNConv(in_features, in_features)
        self.conv2 = GCNConv(in_features, out_features)

    def forward(self, x, edge_index):
        x = F.leaky_relu(self.conv1(x, edge_index), negative_slope=0.2)
        x = self.conv2(x, edge_index)
        return x

# ===================== 关键修复 =====================
# 1. 移除 InnerProductDecoder，替换为边采样解码器
class EdgeDecoder(nn.Module):
    """边级别解码器，避免构造全邻接矩阵"""
    def __init__(self):
        super(EdgeDecoder, self).__init__()

    def forward(self, z, pos_edge_index, neg_edge_index=None):
        """
        计算正负边的二分类损失（BCE）
        z: [N, d] 节点嵌入
        pos_edge_index: [2, E_pos] 正边
        neg_edge_index: [2, E_neg] 负边，若为None则自动采样与正边等量的负边
        """
        pos_score = (z[pos_edge_index[0]] * z[pos_edge_index[1]]).sum(dim=1)
        pos_loss = -torch.log(torch.sigmoid(pos_score) + 1e-15).mean()

        if neg_edge_index is None:
            neg_edge_index = self.sample_negative_edges(pos_edge_index, z.size(0))
        neg_score = (z[neg_edge_index[0]] * z[neg_edge_index[1]]).sum(dim=1)
        neg_loss = -torch.log(1 - torch.sigmoid(neg_score) + 1e-15).mean()

        return pos_loss + neg_loss

    @staticmethod
    def sample_negative_edges(pos_edge_index, num_nodes, num_neg=None):
        """随机采样不存在于pos_edge_index中的边"""
        if num_neg is None:
            num_neg = pos_edge_index.size(1)  # 默认正负样本1:1
        # 转换为set加速查找
        pos_set = set()
        for i in range(pos_edge_index.size(1)):
            u = pos_edge_index[0, i].item()
            v = pos_edge_index[1, i].item()
            pos_set.add((u, v))

        neg_edges = []
        device = pos_edge_index.device
        while len(neg_edges) < num_neg:
            u = np.random.randint(0, num_nodes)
            v = np.random.randint(0, num_nodes)
            if u != v and (u, v) not in pos_set:
                neg_edges.append([u, v])
        return torch.tensor(neg_edges, device=device).t()

# ------------------------------------------
# 2. 修改后的G3AD主模型
class G3AD(nn.Module):
    def __init__(self, num_features, hidden_dim=64, num_heads=8,
                 lambda1=0.7, lambda2=0.3, neg_samples=10):
        """
        neg_samples: 计算节点异常分数时，每个节点采样的负边数量
        """
        super(G3AD, self).__init__()
        self.hidden_dim = hidden_dim
        self.lambda1 = lambda1
        self.lambda2 = lambda2
        self.neg_samples = neg_samples

        # GNN编码器
        self.gnn_encoder = GATEncoder(num_features, hidden_dim, heads=num_heads)
        # 辅助编码器
        self.attr_encoder = nn.Sequential(
            nn.Linear(num_features, hidden_dim),
            nn.LeakyReLU(negative_slope=0.2),
            nn.Linear(hidden_dim, hidden_dim)
        )
        self.topology_encoder = nn.Sequential(
            nn.Linear(num_features, hidden_dim),
            nn.LeakyReLU(negative_slope=0.2),
            nn.Linear(hidden_dim, hidden_dim)
        )
        # 自适应缓存模块
        self.ac_attr = ACModule(hidden_dim)
        self.ac_topo = ACModule(hidden_dim)
        # 属性重构解码器
        self.attr_reconstructor = GCNReconstructor(hidden_dim, num_features)
        # ========== 修复：拓扑重构解码器替换为边采样版本 ==========
        self.topology_reconstructor = EdgeDecoder()

    def adaptive_caching(self, H1, H2, ac_module):
        concat_features = torch.cat([H1, H2], dim=1)
        imp = torch.tanh(ac_module.fusion_mlp(concat_features))
        return imp * H1 + (1 - imp) * H2

    def compute_correlation_constraint(self, H1, H2):
        H1_centered = H1 - H1.mean(dim=0, keepdim=True)
        H2_centered = H2 - H2.mean(dim=0, keepdim=True)
        cov = (H1_centered * H2_centered).mean(dim=0)
        var1 = H1_centered.pow(2).mean(dim=0)
        var2 = H2_centered.pow(2).mean(dim=0)
        correlation = cov / (torch.sqrt(var1 * var2) + 1e-8)
        return torch.abs(correlation).mean()

    def compute_global_consistency(self, H):
        graph_summary = torch.mean(H, dim=0, keepdim=True)
        distances = torch.norm(H - graph_summary, p=2, dim=1)
        consistency_loss = torch.log(torch.sqrt(distances.pow(2).sum()) + 1e-2)
        return consistency_loss, graph_summary

    def forward(self, x, edge_index):
        H_c = self.gnn_encoder(x, edge_index)
        H_a = self.attr_encoder(x)
        H_t = self.topology_encoder(x)
        Z_A = self.adaptive_caching(H_a, H_c, self.ac_attr)
        Z_T = self.adaptive_caching(H_t, H_c, self.ac_topo)
        return H_a, H_t, H_c, Z_A, Z_T

    def compute_losses(self, x, edge_index, H_a, H_t, H_c, Z_A, Z_T):
        n = x.size(0)

        # 相关性约束损失
        L_cc = (self.compute_correlation_constraint(H_a, H_t) +
                self.compute_correlation_constraint(H_a, H_c) +
                self.compute_correlation_constraint(H_t, H_c))

        # 局部属性重构损失
        X_recon = self.attr_reconstructor(Z_A, edge_index)
        L_attr = F.mse_loss(X_recon, x, reduction='mean')

        # ========== 修复：拓扑重构损失（边采样版）==========
        # 负边自动采样（数量与正边相等）
        neg_edge_index = self.topology_reconstructor.sample_negative_edges(
            edge_index, n, edge_index.size(1))
        L_topo = self.topology_reconstructor(Z_T, edge_index, neg_edge_index)

        # 全局一致性损失
        L_cons, _ = self.compute_global_consistency(H_c)

        # 总损失
        total_loss = (self.lambda1 * L_attr +
                      (1 - self.lambda1) * L_topo +
                      self.lambda2 * L_cons +
                      L_cc)

        return {
            'total': total_loss,
            'attr_recon': L_attr,
            'topo_recon': L_topo,
            'consistency': L_cons,
            'correlation': L_cc
        }

    # ========== 修复：节点级异常分数计算（避免全邻接矩阵）==========
    def compute_anomaly_scores(self, x, edge_index):
        """返回每个节点的异常分数，使用采样边近似拓扑重构误差"""
        H_a, H_t, H_c, Z_A, Z_T = self.forward(x, edge_index)

        # 1. 属性重构误差（节点级）
        X_recon = self.attr_reconstructor(Z_A, edge_index)
        attr_error = torch.norm(x - X_recon, p=2, dim=1).pow(2)  # [N]

        # 2. 拓扑重构误差（节点级，基于正边+负采样）
        topo_error = self._compute_node_topo_error(Z_T, edge_index)

        # 3. 全局一致性误差
        _, graph_summary = self.compute_global_consistency(H_c)
        global_error = torch.log(torch.sqrt(torch.norm(H_c - graph_summary, p=2, dim=1).pow(2)) + 1e-2)

        # 组合异常分数
        anomaly_scores = (self.lambda1 * attr_error +
                          (1 - self.lambda1) * topo_error +
                          self.lambda2 * global_error)
        return anomaly_scores.detach().cpu().numpy()

    def _compute_node_topo_error(self, z, pos_edge_index):
        """为每个节点计算拓扑重构误差（正边误差 + 负采样边误差）"""
        device = z.device
        num_nodes = z.size(0)
        # 初始化误差向量
        topo_error = torch.zeros(num_nodes, device=device)

        # ---- 正边贡献：对每条边 (i,j)，误差均分给两个节点 ----
        pos_score = (z[pos_edge_index[0]] * z[pos_edge_index[1]]).sum(dim=1)
        pos_err = F.mse_loss(torch.sigmoid(pos_score), torch.ones_like(pos_score), reduction='none')
        # 每个正边误差分配到两个端点
        topo_error.scatter_add_(0, pos_edge_index[0], pos_err / 2)
        topo_error.scatter_add_(0, pos_edge_index[1], pos_err / 2)

        # ---- 负边贡献：为每个节点采样 self.neg_samples 条负边 ----
        # 构建邻居集合以加速负采样
        adj_list = [[] for _ in range(num_nodes)]
        for i in range(pos_edge_index.size(1)):
            u = pos_edge_index[0, i].item()
            v = pos_edge_index[1, i].item()
            adj_list[u].append(v)
            adj_list[v].append(u)

        for node in range(num_nodes):
            neighbors = set(adj_list[node])
            neighbors.add(node)  # 自环不采样
            neg_count = 0
            neg_err_sum = 0.0
            # 采样负边，直到达到 self.neg_samples 条
            while neg_count < self.neg_samples:
                neg_node = np.random.randint(0, num_nodes)
                if neg_node not in neighbors:
                    score = (z[node] * z[neg_node]).sum()
                    err = F.mse_loss(torch.sigmoid(score), torch.tensor(0.0, device=device), reduction='none')
                    neg_err_sum += err.item()
                    neg_count += 1
                    # 可选：为了避免重复采样，可以将采样过的负节点加入临时禁止集
            if neg_count > 0:
                topo_error[node] += neg_err_sum / neg_count  # 平均负边误差

        return topo_error

# ------------------------------------------
# 训练器（少量修改）
class G3ADTrainer:
    def __init__(self, model, device='cuda' if torch.cuda.is_available() else 'cpu'):
        self.model = model.to(device)
        self.device = device
        self.train_losses = []
        self.val_losses = []

    def train(self, train_data, val_data, optimizer, epochs=100, patience=10):
        early_stopping = EarlyStopping(patience=patience, mode='min')

        for epoch in range(epochs):
            # 训练阶段
            self.model.train()
            x = train_data.x.to(self.device)
            edge_index = train_data.edge_index.to(self.device)

            H_a, H_t, H_c, Z_A, Z_T = self.model(x, edge_index)
            # 注意：compute_losses 现在不需要 adj_matrix 参数
            losses = self.model.compute_losses(x, edge_index, H_a, H_t, H_c, Z_A, Z_T)

            optimizer.zero_grad()
            losses['total'].backward()
            optimizer.step()

            self.train_losses.append(losses['total'].item())

            # 验证阶段
            self.model.eval()
            with torch.no_grad():
                x_val = val_data.x.to(self.device)
                edge_index_val = val_data.edge_index.to(self.device)

                H_a_val, H_t_val, H_c_val, Z_A_val, Z_T_val = self.model(x_val, edge_index_val)
                val_losses = self.model.compute_losses(x_val, edge_index_val,
                                                       H_a_val, H_t_val, H_c_val, Z_A_val, Z_T_val)
                self.val_losses.append(val_losses['total'].item())

                if early_stopping(val_losses['total'].item(), self.model):
                    early_stopping.restore_best_model(self.model)
                    break

        return self.train_losses, self.val_losses

    def evaluate(self, data, y_true):
        self.model.eval()
        with torch.no_grad():
            x = data.x.to(self.device)
            edge_index = data.edge_index.to(self.device)

            anomaly_scores = self.model.compute_anomaly_scores(x, edge_index)

            min_len = min(len(anomaly_scores), len(y_true))
            anomaly_scores = anomaly_scores[:min_len]
            y_true = y_true[:min_len]

            metrics = self._compute_metrics(y_true, anomaly_scores)
            metrics['anomaly_scores'] = anomaly_scores
            return metrics

    def _compute_metrics(self, y_true, anomaly_scores):
        metrics = {}
        try:
            from sklearn.metrics import roc_auc_score
            metrics['auc'] = roc_auc_score(y_true, anomaly_scores)
        except:
            metrics['auc'] = 0.5
        try:
            from sklearn.metrics import average_precision_score
            metrics['pr_auc'] = average_precision_score(y_true, anomaly_scores)
        except:
            metrics['pr_auc'] = 0.5

        k = int(np.sum(y_true))
        if k > 0:
            top_k_indices = np.argsort(anomaly_scores)[-k:]
            y_pred = np.zeros_like(anomaly_scores)
            y_pred[top_k_indices] = 1

            from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
            tn = np.sum((y_true == 0) & (y_pred == 0))
            fp = np.sum((y_true == 0) & (y_pred == 1))
            fn = np.sum((y_true == 1) & (y_pred == 0))
            tp = np.sum((y_true == 1) & (y_pred == 1))

            metrics['accuracy'] = accuracy_score(y_true, y_pred)
            metrics['precision'] = precision_score(y_true, y_pred, zero_division=0)
            metrics['recall'] = recall_score(y_true, y_pred, zero_division=0)
            metrics['f1_score'] = f1_score(y_true, y_pred, zero_division=0)

            specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
            sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0
            metrics['g_mean'] = np.sqrt(sensitivity * specificity) if sensitivity * specificity > 0 else 0
        else:
            metrics['accuracy'] = 0.0
            metrics['precision'] = 0.0
            metrics['recall'] = 0.0
            metrics['f1_score'] = 0.0
            metrics['g_mean'] = 0.0
        return metrics

    def save_model(self, path):
        torch.save(self.model.state_dict(), path)

# ------------------------------------------
# 主函数（基本不变，仅调整lambda传参）
def main():
    torch.manual_seed(42)
    np.random.seed(42)

    os.makedirs('13G3AD', exist_ok=True)

    print("加载数据...")
    processor = DataProcessor()
    processed_data = processor.load_and_preprocess_data()

    if isinstance(processed_data, tuple) and len(processed_data) == 6:
        X_train, y_train, X_val, y_val, X_test, y_test = processed_data

        print(f"训练数据形状: {X_train.shape}")
        print(f"验证数据形状: {X_val.shape}")

        print("构建图结构...")
        train_edge_index = GraphBuilder.build_simple_graph(X_train.shape[0], avg_degree=5)
        val_edge_index = GraphBuilder.build_simple_graph(X_val.shape[0], avg_degree=5)
        test_edge_index = GraphBuilder.build_simple_graph(X_test.shape[0], avg_degree=5)

        from torch_geometric.data import Data
        train_data = Data(x=torch.FloatTensor(X_train), edge_index=torch.LongTensor(train_edge_index))
        val_data = Data(x=torch.FloatTensor(X_val), edge_index=torch.LongTensor(val_edge_index))
        test_data = Data(x=torch.FloatTensor(X_test), edge_index=torch.LongTensor(test_edge_index))

        print(f"训练图: {train_data.num_nodes} 个节点, {train_data.num_edges} 条边")
    else:
        print("数据格式不符合预期")
        return

    num_features = X_train.shape[1]
    model = G3AD(
        num_features=num_features,
        hidden_dim=64,
        num_heads=8,
        lambda1=0.7,
        lambda2=0.3,
        neg_samples=10   # 每个节点评估时采样的负边数
    )

    print("开始训练模型...")
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"使用设备: {device}")

    trainer = G3ADTrainer(model, device=device)
    optimizer = optim.Adam(model.parameters(), lr=0.001)

    train_start_time = time.time()
    train_losses, val_losses = trainer.train(train_data, val_data, optimizer, epochs=100)
    train_time = time.time() - train_start_time
    print(f"训练完成! 耗时: {train_time:.2f}秒")

    trainer.save_model('13G3AD/G3AD.pth')

    print("评估模型...")
    inference_start_time = time.time()
    train_metrics = trainer.evaluate(train_data, y_train)
    inference_time = time.time() - inference_start_time
    val_metrics = trainer.evaluate(val_data, y_val)
    test_metrics = trainer.evaluate(test_data, y_test)

    total_samples = len(y_train) + len(y_val) + len(y_test)
    inference_speed = total_samples / inference_time if inference_time > 0 else 0

    # 保存结果
    results_df = pd.DataFrame({
        'dataset': ['train', 'val', 'test'],
        'auc': [f"{train_metrics.get('auc', 0):.4f}",
                f"{val_metrics.get('auc', 0):.4f}",
                f"{test_metrics.get('auc', 0):.4f}"],
        'pr_auc': [f"{train_metrics.get('pr_auc', 0):.4f}",
                   f"{val_metrics.get('pr_auc', 0):.4f}",
                   f"{test_metrics.get('pr_auc', 0):.4f}"],
        'accuracy': [f"{train_metrics.get('accuracy', 0):.4f}",
                     f"{val_metrics.get('accuracy', 0):.4f}",
                     f"{test_metrics.get('accuracy', 0):.4f}"],
        'precision': [f"{train_metrics.get('precision', 0):.4f}",
                      f"{val_metrics.get('precision', 0):.4f}",
                      f"{test_metrics.get('precision', 0):.4f}"],
        'recall': [f"{train_metrics.get('recall', 0):.4f}",
                   f"{val_metrics.get('recall', 0):.4f}",
                   f"{test_metrics.get('recall', 0):.4f}"],
        'f1_score': [f"{train_metrics.get('f1_score', 0):.4f}",
                     f"{val_metrics.get('f1_score', 0):.4f}",
                     f"{test_metrics.get('f1_score', 0):.4f}"],
        'g_mean': [f"{train_metrics.get('g_mean', 0):.4f}",
                   f"{val_metrics.get('g_mean', 0):.4f}",
                   f"{test_metrics.get('g_mean', 0):.4f}"]
    })
    results_df.to_csv('13G3AD/results.csv', index=False)

    time_df = pd.DataFrame({
        'metric': ['Training_Time_Seconds', 'Inference_Time_Seconds', 'Inference_Speed_SamplesPerSecond'],
        'value': [f"{train_time:.4f}", f"{inference_time:.4f}", f"{inference_speed:.4f}"]
    })
    time_df.to_csv('13G3AD/time.csv', index=False)

    print("结果已保存到13G3AD/目录")
    print("训练完成!")

if __name__ == "__main__":
    main()