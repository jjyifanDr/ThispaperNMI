import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import pandas as pd
import math
import os
import time
from torch.utils.data import Dataset, DataLoader
from sklearn.metrics import (accuracy_score, precision_score, recall_score, 
                             f1_score, roc_auc_score, average_precision_score, 
                             roc_curve, auc, confusion_matrix)

# ==================== TFD-Net 模型定义 ====================

class PositionalEmbedding(nn.Module):
    """位置编码层 - 与论文公式(1)一致"""
    def __init__(self, M, D):
        super(PositionalEmbedding, self).__init__()
        self.pos_embedding = nn.Parameter(torch.randn(1, M, D))
        
    def forward(self, x):
        batch_size = x.shape[0]
        pos_embedding = self.pos_embedding.expand(batch_size, -1, -1)
        return x + pos_embedding

class MultiHeadSelfAttention(nn.Module):
    """多头自注意力层 - 与论文公式(2)-(6)一致"""
    def __init__(self, D, num_heads):
        super(MultiHeadSelfAttention, self).__init__()
        self.D = D
        self.num_heads = num_heads
        self.head_dim = D // num_heads
        
        assert self.head_dim * num_heads == D, f"D ({D}) must be divisible by num_heads ({num_heads})"
        
        self.qkv_proj = nn.Linear(D, 3 * D)
        self.output_proj = nn.Linear(D, D)
        
    def forward(self, x):
        batch_size, M, D = x.shape
        
        qkv = self.qkv_proj(x)
        qkv = qkv.reshape(batch_size, M, 3, self.num_heads, self.head_dim)
        qkv = qkv.permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]
        
        scale = 1.0 / math.sqrt(self.head_dim)
        attention_scores = torch.matmul(q, k.transpose(-2, -1)) * scale
        attention_probs = F.softmax(attention_scores, dim=-1)
        
        context = torch.matmul(attention_probs, v)
        context = context.transpose(1, 2).reshape(batch_size, M, D)
        
        output = self.output_proj(context)
        return output

class EncoderLayer(nn.Module):
    """Transformer编码器层 - 与论文公式(8)-(9)一致"""
    def __init__(self, D, num_heads, dropout=0.1):
        super(EncoderLayer, self).__init__()
        self.attention = MultiHeadSelfAttention(D, num_heads)
        self.norm1 = nn.LayerNorm(D)
        self.norm2 = nn.LayerNorm(D)
        
        self.ffn = nn.Sequential(
            nn.Linear(D, 4 * D),
            nn.ReLU(),
            nn.Linear(4 * D, D),
            nn.Dropout(dropout)
        )
        
    def forward(self, x):
        attn_output = self.attention(x)
        x = self.norm1(x + attn_output)
        ffn_output = self.ffn(x)
        x = self.norm2(x + ffn_output)
        return x

class TransformerFeatureExtractionModule(nn.Module):
    """Transformer特征提取模块 - 与论文算法1一致"""
    def __init__(self, input_dim, M=10, D=64, num_heads=8, num_layers=8):
        super().__init__()
        self.M = M
        self.D = D
        self.input_dim = input_dim
        
        # 计算是否需要调整M或padding
        self.padding_needed = 0
        if input_dim % M != 0:
            # 尝试寻找更小的可整除M
            found = False
            for new_M in range(M-1, 1, -1):
                if input_dim % new_M == 0:
                    self.M = new_M
                    self.block_size = input_dim // new_M
                    found = True
                    break
            if not found:
                # 无法整除，使用ceil计算block_size并padding
                self.block_size = (input_dim + M - 1) // M
                self.padding_needed = self.M * self.block_size - input_dim
        else:
            self.block_size = input_dim // self.M
        
        self.feature_proj = nn.Linear(self.block_size, D)
        self.pos_embedding = PositionalEmbedding(self.M, D)
        
        self.encoder_layers = nn.ModuleList([
            EncoderLayer(D, num_heads) for _ in range(num_layers)
        ])
        
        self.output_proj = nn.Linear(self.M * D, D)
        
    def forward(self, x):
        batch_size = x.shape[0]
        
        if self.padding_needed > 0:
            x = F.pad(x, (0, self.padding_needed), "constant", 0)
        
        
        x_blocks = x.view(batch_size, self.M, self.block_size)
        
        x_proj = self.feature_proj(x_blocks)
        x_embedded = self.pos_embedding(x_proj)
        
        encoder_output = x_embedded
        for encoder_layer in self.encoder_layers:
            encoder_output = encoder_layer(encoder_output)
        
        encoder_output_flat = encoder_output.view(batch_size, -1)
        feature_output = self.output_proj(encoder_output_flat)
        
        return feature_output

class AnomalyScoreGenerator(nn.Module):
    """异常分数生成器 - 与论文公式(11)-(13)一致"""
    def __init__(self, input_dim, hidden_dims=[128, 64]):
        super(AnomalyScoreGenerator, self).__init__()
        
        layers = []
        prev_dim = input_dim
        
        for hidden_dim in hidden_dims:
            layers.append(nn.Linear(prev_dim, hidden_dim))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(0.1))
            prev_dim = hidden_dim
        
        layers.append(nn.Linear(prev_dim, 1))
        
        self.model = nn.Sequential(*layers)
        
    def forward(self, x):
        score = self.model(x)
        anomaly_score = torch.sigmoid(score)
        return anomaly_score

class TFDNet(nn.Module):
    """TFD-Net: Transformer Deviation Network"""
    def __init__(self, input_dim, M=10, D=64, num_heads=8, num_layers=8, 
                 hidden_dims=[128, 64], device='cpu'):
        super(TFDNet, self).__init__()
        
        self.input_dim = input_dim
        self.M = M
        self.D = D
        self.device = device
        
        if D % num_heads != 0:
            D = (D // num_heads) * num_heads
            if D == 0:
                D = num_heads
            self.D = D
        
        self.tfem = TransformerFeatureExtractionModule(
            input_dim=input_dim,
            M=M,
            D=D,
            num_heads=num_heads,
            num_layers=num_layers
        )
        
        self.asg = AnomalyScoreGenerator(
            input_dim=D,
            hidden_dims=hidden_dims
        )
        
    def forward(self, x):
        features = self.tfem(x)
        anomaly_scores = self.asg(features)
        return anomaly_scores

class TFDLoss(nn.Module):
    """TFD-Loss: Transformer Deviation Loss Function - 与论文公式(15)一致"""
    def __init__(self, mu=0.1, sigma=2.0, gamma=1, m=1.5):
        super(TFDLoss, self).__init__()
        self.mu = mu
        self.sigma = sigma
        self.gamma = gamma
        self.m = m
        
    def forward(self, anomaly_scores, labels):
        anomaly_scores = anomaly_scores.squeeze()
        labels = labels.float()
        
        # 计算Z-score - 与论文公式(14)一致
        z_scores = (anomaly_scores - self.mu) / self.sigma
        
        # 双曲正切函数映射
        tanh_z = torch.tanh(z_scores)
        
        # 正常和异常样本掩码
        normal_mask = (labels == 0).float()
        anomaly_mask = (labels == 1).float()
        
        # 计算损失 - 与论文公式(15)完全一致
        normal_loss = normal_mask * torch.pow(tanh_z, 2 * self.gamma)
        anomaly_loss = anomaly_mask * torch.pow(self.m - z_scores, 2)
        
        total_loss = torch.mean(normal_loss + anomaly_loss)
        
        return total_loss

# ==================== 数据集和数据加载器 ====================

class AnomalyDataset(Dataset):
    """异常检测数据集类"""
    def __init__(self, features, labels):
        if isinstance(features, pd.DataFrame):
            features = features.values
        if isinstance(labels, pd.Series) or isinstance(labels, pd.DataFrame):
            labels = labels.values
        
        self.features = torch.FloatTensor(features)
        self.labels = torch.FloatTensor(labels.flatten())
        
    def __len__(self):
        return len(self.features)
    
    def __getitem__(self, idx):
        return self.features[idx], self.labels[idx]

# ==================== TFD-Net训练器 ====================

class TFDNetTrainer:
    """TFD-Net训练器 - 严格遵循论文实验设置"""
    def __init__(self, input_dim, config=None):
        self.input_dim = input_dim
        self.config = config or {}
        
        # 设置默认配置 - 严格遵循论文参数
        self.config.setdefault('M', 10)
        self.config.setdefault('D', 64)
        self.config.setdefault('num_heads', 8)
        self.config.setdefault('num_layers', 8)
        self.config.setdefault('hidden_dims', [128, 64])
        self.config.setdefault('batch_size', 512)  # 论文batch_size=512
        self.config.setdefault('learning_rate', 1e-3)
        self.config.setdefault('num_epochs', 200)  # 论文训练200轮
        self.config.setdefault('device', 'cuda' if torch.cuda.is_available() else 'cpu')
        
        # TFD-Loss参数 - 严格遵循论文默认值
        self.config.setdefault('mu', 0.1)    # μ=0.1
        self.config.setdefault('sigma', 2.0) # σ=2.0
        self.config.setdefault('gamma', 1)   # γ∈{1,2,3}, 默认1
        self.config.setdefault('m', 1.5)     # m∈[1,2], 默认1.5
        
        # 调整M值
        M = min(self.config['M'], input_dim // 2)
        if M < 2:
            M = 2
        self.config['M'] = M
        
        # 初始化模型
        self.model = TFDNet(
            input_dim=input_dim,
            M=self.config['M'],
            D=self.config['D'],
            num_heads=self.config['num_heads'],
            num_layers=self.config['num_layers'],
            hidden_dims=self.config['hidden_dims'],
            device=self.config['device']
        ).to(self.config['device'])
        
        # 初始化损失函数
        self.criterion = TFDLoss(
            mu=self.config['mu'],
            sigma=self.config['sigma'],
            gamma=self.config['gamma'],
            m=self.config['m']
        )
        
        # 初始化优化器
        self.optimizer = torch.optim.Adam(
            self.model.parameters(),
            lr=self.config['learning_rate']
        )
        
        # 存储训练历史
        self.train_losses = []
        self.val_losses = []
        
        #  - 用于计算分类指标
        self.threshold = 90
        
    def calculate_metrics(self, y_true, y_score, threshold=90):
        """计算评估指标 - 使用固定阈值90"""
        y_pred = (y_score > threshold).astype(int)
        
        # 基础分类指标
        accuracy = accuracy_score(y_true, y_pred)
        precision = precision_score(y_true, y_pred, zero_division=0)
        recall = recall_score(y_true, y_pred, zero_division=0)
        f1 = f1_score(y_true, y_pred, zero_division=0)
        
        # G-mean
        tn = np.sum((y_pred == 0) & (y_true == 0))
        fp = np.sum((y_pred == 1) & (y_true == 0))
        tp = np.sum((y_pred == 1) & (y_true == 1))
        fn = np.sum((y_pred == 0) & (y_true == 1))
        
        sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0
        specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
        g_mean = np.sqrt(sensitivity * specificity) if sensitivity > 0 and specificity > 0 else 0
        
        # AUC-ROC
        auc_score = roc_auc_score(y_true, y_score) if len(np.unique(y_true)) > 1 else 90
        
        # AUC-PR (Precision-Recall AUC)
        pr_auc = average_precision_score(y_true, y_score) if len(np.unique(y_true)) > 1 else 90
        
        return {
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1': f1,
            'g_mean': g_mean,
            'auc': auc_score,
            'pr_auc': pr_auc
        }
    
    def train_epoch(self, train_loader):
        """训练一个epoch"""
        self.model.train()
        total_loss = 0
        num_batches = 0
        
        for batch_features, batch_labels in train_loader:
            batch_features = batch_features.to(self.config['device'])
            batch_labels = batch_labels.to(self.config['device'])
            
            anomaly_scores = self.model(batch_features)
            loss = self.criterion(anomaly_scores, batch_labels)
            
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()
            
            total_loss += loss.item()
            num_batches += 1
        
        return total_loss / num_batches
    
    def validate(self, data_loader):
        """验证模型"""
        self.model.eval()
        total_loss = 0
        num_batches = 0
        
        all_scores = []
        all_labels = []
        
        with torch.no_grad():
            for batch_features, batch_labels in data_loader:
                batch_features = batch_features.to(self.config['device'])
                batch_labels = batch_labels.to(self.config['device'])
                
                anomaly_scores = self.model(batch_features)
                loss = self.criterion(anomaly_scores, batch_labels)
                
                total_loss += loss.item()
                num_batches += 1
                
                all_scores.extend(anomaly_scores.cpu().numpy())
                all_labels.extend(batch_labels.cpu().numpy())
        
        avg_loss = total_loss / num_batches
        all_scores = np.array(all_scores).flatten()
        all_labels = np.array(all_labels)
        
        return avg_loss, all_scores, all_labels
    
    def train(self, train_loader, val_loader=None):
        """训练模型 - 严格遵循论文训练流程"""
        print("开始训练TFD-Net模型...")
        print(f"设备: {self.config['device']}")
        print(f"训练轮数: {self.config['num_epochs']}")
        print(f"批量大小: {self.config['batch_size']}")
        print(f"TFD-Loss参数: μ={self.config['mu']}, σ={self.config['sigma']}, γ={self.config['gamma']}, m={self.config['m']}")
        
        start_time = time.time()
        
        for epoch in range(self.config['num_epochs']):
            # 训练阶段
            train_loss = self.train_epoch(train_loader)
            self.train_losses.append(train_loss)
            
            # 验证阶段
            if val_loader is not None:
                val_loss, val_scores, val_labels = self.validate(val_loader)
                self.val_losses.append(val_loss)
                
                # 计算验证集指标
                val_metrics = self.calculate_metrics(val_labels, val_scores, self.threshold)
                
                if (epoch + 1) % 10 == 0:
                    print(f"Epoch [{epoch+1}/{self.config['num_epochs']}]")
                    print(f"  训练损失: {train_loss:.4f}")
                    print(f"  验证损失: {val_loss:.4f}")
                    print(f"  验证AUC: {val_metrics['auc']:.4f}, PR-AUC: {val_metrics['pr_auc']:.4f}, F1: {val_metrics['f1']:.4f}")
            else:
                if (epoch + 1) % 10 == 0:
                    print(f"Epoch [{epoch+1}/{self.config['num_epochs']}], 训练损失: {train_loss:.4f}")
        
        training_time = time.time() - start_time
        print(f"\n训练完成! 总训练时间: {training_time:.2f} 秒")
        
        return training_time
    
    def evaluate(self, data_loader):
        """评估模型"""
        start_time = time.time()
        _, scores, labels = self.validate(data_loader)
        inference_time = time.time() - start_time
        
        metrics = self.calculate_metrics(labels, scores, self.threshold)
        
        return metrics, inference_time, len(scores)
    
    def save_model(self, path='TFD_Net.pth'):
        """保存模型"""
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'config': self.config,
            'input_dim': self.input_dim,
            'train_losses': self.train_losses,
            'val_losses': self.val_losses
        }, path)
        print(f"模型已保存到: {path}")
    
    def load_model(self, path='TFD_Net.pth'):
        """加载模型"""
        checkpoint = torch.load(path, map_location=self.config['device'])
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.config = checkpoint['config']
        self.input_dim = checkpoint['input_dim']
        self.train_losses = checkpoint.get('train_losses', [])
        self.val_losses = checkpoint.get('val_losses', [])
        print(f"模型已从 {path} 加载")

# ==================== 数据加载器 ====================
# 从提供的模块导入数据处理器
'''======================================================================================================='''
'''                                           Read dataset                       '''
#from ReadFinanceDataSet import DataProcessor 

'''################################## Credit Card #####################'''
from ReadCreditcardDataset import DataProcessor


'''################################## Network Attack #####################'''
#from ReadCoAtSetDataset import DataProcessor

# ==================== 主函数 ====================

def main():
    """主函数 - 执行完整的训练、验证、测试流程"""
    
    # 创建结果目录
    results_dir = "6TFD_Net"
    os.makedirs(results_dir, exist_ok=True)
    
    # 1. 加载和预处理数据
    print("=" * 80)
    print("TFD-Net: Transformer Deviation Network for Weakly Supervised Anomaly Detection")
    print("=" * 80)
    
    print("\n1. 加载和预处理数据...")
    processor = DataProcessor()
    processed_data = processor.load_and_preprocess_data()
    
    # 假设返回6个数据集：X_train, y_train, X_val, y_val, X_test, y_test
    if len(processed_data) == 6:
        X_train, y_train, X_val, y_val, X_test, y_test = processed_data
        
        print(f"训练集: {X_train.shape[0]} 样本, {X_train.shape[1]} 特征")
        print(f"验证集: {X_val.shape[0]} 样本")
        print(f"测试集: {X_test.shape[0]} 样本")
    else:
        raise ValueError("数据集格式不正确，期望6个数组")
    
    # 2. 创建数据加载器
    input_dim = X_train.shape[1]
    
    train_dataset = AnomalyDataset(X_train, y_train)
    val_dataset = AnomalyDataset(X_val, y_val)
    test_dataset = AnomalyDataset(X_test, y_test)
    
    # 调整batch_size
    batch_size = 512
    if len(train_dataset) < batch_size:
        batch_size = min(32, len(train_dataset))
    
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
    
    # 3. 创建训练器
    config = {
        'M': 10,
        'D': 64,
        'num_heads': 8,
        'num_layers': 8,
        'hidden_dims': [128, 64],
        'batch_size': batch_size,
        'learning_rate': 1e-3,
        'num_epochs': 200,
        'mu': 0.1,
        'sigma': 2.0,
        'gamma': 1,
        'm': 1.5,
    }
    
    trainer = TFDNetTrainer(input_dim=input_dim, config=config)
    
    # 4. 训练模型
    print("\n2. 训练模型...")
    training_time = trainer.train(train_loader, val_loader)
    
    # 5. 保存模型
    print("\n3. 保存模型...")
    trainer.save_model(os.path.join(results_dir, "TFD_Net.pth"))
    
    # 6. 评估模型
    print("\n4. 评估模型...")
    
    # 评估训练集
    print("评估训练集...")
    train_metrics, train_inf_time, train_samples = trainer.evaluate(train_loader)
    
    # 评估验证集
    print("评估验证集...")
    val_metrics, val_inf_time, val_samples = trainer.evaluate(val_loader)
    
    # 评估测试集
    print("评估测试集...")
    test_metrics, test_inf_time, test_samples = trainer.evaluate(test_loader)
    
    # 7. 保存结果到CSV文件
    print("\n5. 保存结果...")
    
    # 保存评估指标
    results_data = {
        'dataset': ['train', 'val', 'test'],
        'auc': [
            round(train_metrics['auc'], 4),
            round(val_metrics['auc'], 4),
            round(test_metrics['auc'], 4)
        ],
        'pr_auc': [
            round(train_metrics['pr_auc'], 4),
            round(val_metrics['pr_auc'], 4),
            round(test_metrics['pr_auc'], 4)
        ],
        'accuracy': [
            round(train_metrics['accuracy'], 4),
            round(val_metrics['accuracy'], 4),
            round(test_metrics['accuracy'], 4)
        ],
        'precision': [
            round(train_metrics['precision'], 4),
            round(val_metrics['precision'], 4),
            round(test_metrics['precision'], 4)
        ],
        'recall': [
            round(train_metrics['recall'], 4),
            round(val_metrics['recall'], 4),
            round(test_metrics['recall'], 4)
        ],
        'f1_score': [
            round(train_metrics['f1'], 4),
            round(val_metrics['f1'], 4),
            round(test_metrics['f1'], 4)
        ],
        'g_mean': [
            round(train_metrics['g_mean'], 4),
            round(val_metrics['g_mean'], 4),
            round(test_metrics['g_mean'], 4)
        ]
    }
    
    results_df = pd.DataFrame(results_data)
    results_path = os.path.join(results_dir, "results.csv")
    results_df.to_csv(results_path, index=False)
    print(f"评估结果已保存到: {results_path}")
    
    # 保存时间信息
    total_inference_time = train_inf_time + val_inf_time + test_inf_time
    total_samples = train_samples + val_samples + test_samples
    inference_speed = total_samples / total_inference_time if total_inference_time > 0 else 0
    
    time_data = {
        'metric': ['Training_Time_Seconds', 'Inference_Time_Seconds', 'Inference_Speed_SamplesPerSecond'],
        'value': [
            round(training_time, 4),
            round(total_inference_time, 4),
            round(inference_speed, 4)
        ]
    }
    
    time_df = pd.DataFrame(time_data)
    time_path = os.path.join(results_dir, "time.csv")
    time_df.to_csv(time_path, index=False)
    print(f"时间信息已保存到: {time_path}")
    
    # 8. 打印最终结果
    print("\n" + "=" * 80)
    print("最终评估结果:")
    print("=" * 80)
    
    print(f"\n训练集 ({train_samples} 样本):")
    print(f"  AUC-ROC: {train_metrics['auc']:.4f}, AUC-PR: {train_metrics['pr_auc']:.4f}")
    print(f"  准确率: {train_metrics['accuracy']:.4f}, 精确率: {train_metrics['precision']:.4f}")
    print(f"  召回率: {train_metrics['recall']:.4f}, F1分数: {train_metrics['f1']:.4f}")
    print(f"  G-Mean: {train_metrics['g_mean']:.4f}")
    
    print(f"\n验证集 ({val_samples} 样本):")
    print(f"  AUC-ROC: {val_metrics['auc']:.4f}, AUC-PR: {val_metrics['pr_auc']:.4f}")
    print(f"  准确率: {val_metrics['accuracy']:.4f}, 精确率: {val_metrics['precision']:.4f}")
    print(f"  召回率: {val_metrics['recall']:.4f}, F1分数: {val_metrics['f1']:.4f}")
    print(f"  G-Mean: {val_metrics['g_mean']:.4f}")
    
    print(f"\n测试集 ({test_samples} 样本):")
    print(f"  AUC-ROC: {test_metrics['auc']:.4f}, AUC-PR: {test_metrics['pr_auc']:.4f}")
    print(f"  准确率: {test_metrics['accuracy']:.4f}, 精确率: {test_metrics['precision']:.4f}")
    print(f"  召回率: {test_metrics['recall']:.4f}, F1分数: {test_metrics['f1']:.4f}")
    print(f"  G-Mean: {test_metrics['g_mean']:.4f}")
    
    print(f"\n时间统计:")
    print(f"  训练时间: {training_time:.4f} 秒")
    print(f"  总推理时间: {total_inference_time:.4f} 秒")
    print(f"  推理速度: {inference_speed:.4f} 样本/秒")
    
    print(f"\n模型文件: {os.path.join(results_dir, 'TFD_Net.pth')}")
    print("=" * 80)

if __name__ == "__main__":
    main()