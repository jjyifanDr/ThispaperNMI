import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import pandas as pd
import time
import os
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, 
    f1_score, roc_auc_score, average_precision_score, confusion_matrix
)

# 创建结果目录
os.makedirs('10BiGAN', exist_ok=True)
'''======================================================================================================='''
'''                                           Read dataset                       '''
from ReadFinanceDataSet import DataProcessor 

'''################################## Credit Card #####################'''
#from ReadCreditcardDataset import DataProcessor


'''################################## Network Attack #####################'''
#from ReadCoAtSetDataset import DataProcessor

# ==================== 网络架构（严格按论文） ====================
class Encoder(nn.Module):
    """编码器网络 - 按论文实现"""
    def __init__(self, input_dim, latent_dim=100, hidden_dims=[128, 256, 128]):
        super(Encoder, self).__init__()
        
        layers = []
        prev_dim = input_dim
        
        for h_dim in hidden_dims:
            layers.extend([
                nn.Linear(prev_dim, h_dim),
                nn.BatchNorm1d(h_dim),
                nn.LeakyReLU(0.2, inplace=True),
                nn.Dropout(0.1)
            ])
            prev_dim = h_dim
        
        self.features = nn.Sequential(*layers)
        self.mu = nn.Linear(prev_dim, latent_dim)
        self.logvar = nn.Linear(prev_dim, latent_dim)
        
    def forward(self, x):
        features = self.features(x)
        mu = self.mu(features)
        logvar = self.logvar(features)
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std, mu, logvar

class Generator(nn.Module):
    """生成器网络 - 按论文实现"""
    def __init__(self, latent_dim=100, output_dim=None, hidden_dims=[128, 256, 128]):
        super(Generator, self).__init__()
        
        layers = []
        prev_dim = latent_dim
        
        for h_dim in hidden_dims[::-1]:
            layers.extend([
                nn.Linear(prev_dim, h_dim),
                nn.BatchNorm1d(h_dim),
                nn.ReLU(inplace=True),
                nn.Dropout(0.1)
            ])
            prev_dim = h_dim
        
        self.features = nn.Sequential(*layers)
        self.output = nn.Linear(prev_dim, output_dim)
        self.tanh = nn.Tanh()
        
    def forward(self, z):
        features = self.features(z)
        x_recon = self.output(features)
        return self.tanh(x_recon)

class Discriminator(nn.Module):
    """判别器网络 - 按论文实现，能区分三种样本"""
    def __init__(self, input_dim, latent_dim=100, hidden_dims=[256, 128, 64]):
        super(Discriminator, self).__init__()
        
        combined_dim = input_dim + latent_dim
        
        layers = []
        prev_dim = combined_dim
        
        for h_dim in hidden_dims:
            layers.extend([
                nn.Linear(prev_dim, h_dim),
                nn.LeakyReLU(0.2, inplace=True),
                nn.Dropout(0.2)
            ])
            prev_dim = h_dim
        
        self.features = nn.Sequential(*layers)
        self.output = nn.Linear(prev_dim, 1)
        
    def forward(self, x, z):
        combined = torch.cat([x, z], dim=1)
        features = self.features(combined)
        return torch.sigmoid(self.output(features))

# ==================== CIBiGANr模型（按论文定理2实现） ====================
class CIBiGANr:
    """Contamination-Immune BiGAN with relaxed assumptions (Theorem 2)"""
    def __init__(self, input_dim, latent_dim=100, 
                 encoder_hidden=[128, 256, 128],
                 generator_hidden=[128, 256, 128],
                 discriminator_hidden=[256, 128, 64],
                 gamma_p=0.1,  # 污染率，必须知道（按论文定理2）
                 c_param=0.75,  # c参数，按论文可设为0.75
                 lr=0.0001,
                 device='cuda' if torch.cuda.is_available() else 'cpu'):
        
        self.input_dim = input_dim
        self.latent_dim = latent_dim
        self.gamma_p = gamma_p
        self.c_param = c_param
        self.device = device
        
        # 根据论文定理2计算d参数：d = (1 - 2γ_p) / (2 - γ_p)
        self.d_param = (1 - 2 * gamma_p) / (2 - gamma_p)
        
        # 初始化网络（严格按论文）
        self.encoder = Encoder(input_dim, latent_dim, encoder_hidden).to(device)
        self.generator = Generator(latent_dim, input_dim, generator_hidden).to(device)
        self.discriminator = Discriminator(input_dim, latent_dim, discriminator_hidden).to(device)
        
        # 优化器（按论文使用Adam）
        self.optimizer_E = torch.optim.Adam(self.encoder.parameters(), lr=lr, betas=(0.5, 0.999))
        self.optimizer_G = torch.optim.Adam(self.generator.parameters(), lr=lr, betas=(0.5, 0.999))
        self.optimizer_D = torch.optim.Adam(self.discriminator.parameters(), lr=lr*0.25, betas=(0.5, 0.999))
        
        self.losses = {'D': [], 'G': [], 'E': []}
    
    def compute_anomaly_scores(self, X):
        """计算异常分数（按论文：使用潜在表示范数）"""
        self.encoder.eval()
        with torch.no_grad():
            X_tensor = torch.FloatTensor(X).to(self.device)
            z, _, _ = self.encoder(X_tensor)
            # 使用L2范数作为异常分数（论文方法）
            scores = torch.norm(z, dim=1).cpu().numpy()
        return scores
    
    def train_step(self, X_contaminated, X_anomaly):
        """训练一步（严格按论文公式23和10）"""
        self.encoder.train()
        self.generator.train()
        self.discriminator.train()
        
        batch_size = X_contaminated.size(0)
        
        # 从标准正态分布采样潜在变量
        z = torch.randn(batch_size, self.latent_dim).to(self.device)
        
        # ========== 训练判别器（公式23） ==========
        self.optimizer_D.zero_grad()
        
        # 1. 污染数据（目标为1）
        z_contaminated, _, _ = self.encoder(X_contaminated)
        D_real = self.discriminator(X_contaminated, z_contaminated)
        loss_D_real = F.mse_loss(D_real, torch.ones_like(D_real))
        
        # 2. 生成数据（目标为0）
        X_gen = self.generator(z)
        D_fake = self.discriminator(X_gen, z)
        loss_D_fake = F.mse_loss(D_fake, torch.zeros_like(D_fake))
        
        # 3. 已知异常数据（目标为d）
        z_anomaly, _, _ = self.encoder(X_anomaly)
        D_anomaly = self.discriminator(X_anomaly, z_anomaly)
        d_target = torch.full_like(D_anomaly, self.d_param).to(self.device)
        loss_D_anomaly = F.mse_loss(D_anomaly, d_target)
        
        loss_D = loss_D_real + loss_D_fake + loss_D_anomaly
        loss_D.backward()
        self.optimizer_D.step()
        
        # ========== 训练生成器和编码器（公式10） ==========
        self.optimizer_G.zero_grad()
        self.optimizer_E.zero_grad()
        
        # 重新计算
        z = torch.randn(batch_size, self.latent_dim).to(self.device)
        z_contaminated, _, _ = self.encoder(X_contaminated)
        
        # 调整异常数据批次大小
        if X_anomaly.size(0) != batch_size:
            if X_anomaly.size(0) < batch_size:
                repeat_factor = batch_size // X_anomaly.size(0) + 1
                X_anomaly_expanded = X_anomaly.repeat(repeat_factor, 1)[:batch_size]
                z_anomaly, _, _ = self.encoder(X_anomaly_expanded)
            else:
                indices = torch.randperm(X_anomaly.size(0))[:batch_size]
                X_anomaly_expanded = X_anomaly[indices]
                z_anomaly, _, _ = self.encoder(X_anomaly_expanded)
        else:
            z_anomaly, _, _ = self.encoder(X_anomaly)
            X_anomaly_expanded = X_anomaly
        
        # 计算判别器输出
        X_gen = self.generator(z)
        D_fake = self.discriminator(X_gen, z)
        D_real = self.discriminator(X_contaminated, z_contaminated)
        D_anomaly = self.discriminator(X_anomaly_expanded, z_anomaly)
        
        # 损失（目标为c）
        target = torch.full_like(D_fake, self.c_param).to(self.device)
        loss_G = F.mse_loss(D_fake, target)
        loss_E_contaminated = F.mse_loss(D_real, target)
        loss_E_anomaly = F.mse_loss(D_anomaly, target)
        
        loss_GE = loss_G + loss_E_contaminated + loss_E_anomaly
        loss_GE.backward()
        self.optimizer_G.step()
        self.optimizer_E.step()
        
        self.losses['D'].append(loss_D.item())
        self.losses['G'].append(loss_G.item())
        self.losses['E'].append(loss_E_contaminated.item())
        
        return loss_D.item(), loss_GE.item()
    
    def fit(self, X_train_contaminated, X_anomaly, X_val=None, y_val=None, 
            epochs=100, batch_size=64, patience=10):
        """训练模型（按论文训练流程）"""
        train_losses_D, train_losses_GE = [], []
        
        X_train_tensor = torch.FloatTensor(X_train_contaminated).to(self.device)
        X_anomaly_tensor = torch.FloatTensor(X_anomaly).to(self.device)
        
        n_train = len(X_train_tensor)
        n_anomaly = len(X_anomaly_tensor)
        
        best_val_score = -np.inf
        patience_counter = 0
        best_model_state = None
        
        for epoch in range(epochs):
            indices = torch.randperm(n_train)
            anomaly_indices = torch.randperm(n_anomaly)
            
            epoch_loss_D, epoch_loss_GE = 0, 0
            n_batches = 0
            
            for i in range(0, n_train, batch_size):
                end_idx = min(i + batch_size, n_train)
                batch_contaminated = X_train_tensor[indices[i:end_idx]]
                current_batch_size = len(batch_contaminated)
                
                anomaly_start = (i % n_anomaly)
                anomaly_end = min(anomaly_start + current_batch_size, n_anomaly)
                batch_anomaly = X_anomaly_tensor[anomaly_indices[anomaly_start:anomaly_end]]
                
                if len(batch_anomaly) < current_batch_size:
                    repeat_factor = current_batch_size // len(batch_anomaly) + 1
                    batch_anomaly = batch_anomaly.repeat(repeat_factor, 1)[:current_batch_size]
                
                loss_D, loss_GE = self.train_step(batch_contaminated, batch_anomaly)
                epoch_loss_D += loss_D
                epoch_loss_GE += loss_GE
                n_batches += 1
            
            avg_loss_D = epoch_loss_D / n_batches if n_batches > 0 else 0
            avg_loss_GE = epoch_loss_GE / n_batches if n_batches > 0 else 0
            train_losses_D.append(avg_loss_D)
            train_losses_GE.append(avg_loss_GE)
            
            # 验证（按论文使用验证集）
            if X_val is not None and y_val is not None:
                val_scores = self.compute_anomaly_scores(X_val)
                try:
                    val_auc = roc_auc_score(y_val, val_scores)
                    
                    print(f'Epoch {epoch+1}/{epochs}, Loss_D: {avg_loss_D:.4f}, Loss_GE: {avg_loss_GE:.4f}, Val AUC: {val_auc:.4f}')
                    
                    if val_auc > best_val_score:
                        best_val_score = val_auc
                        patience_counter = 0
                        best_model_state = {
                            'encoder': self.encoder.state_dict(),
                            'generator': self.generator.state_dict(),
                            'discriminator': self.discriminator.state_dict(),
                            'epoch': epoch
                        }
                    else:
                        patience_counter += 1
                        if patience_counter >= patience:
                            print(f'Early stopping at epoch {epoch+1}')
                            break
                except:
                    print(f'Epoch {epoch+1}/{epochs}, Loss_D: {avg_loss_D:.4f}, Loss_GE: {avg_loss_GE:.4f}')
        
        # 恢复最佳模型
        if best_model_state is not None:
            self.encoder.load_state_dict(best_model_state['encoder'])
            self.generator.load_state_dict(best_model_state['generator'])
            self.discriminator.load_state_dict(best_model_state['discriminator'])
            print(f"Loaded best model from epoch {best_model_state['epoch']+1}")
        
        return train_losses_D, train_losses_GE

# ==================== 指标计算（严格按论文评估） ====================
def calculate_metrics(y_true, scores):
    """计算所有指标（按论文使用的指标）"""
    if len(np.unique(y_true)) < 2:
        return {
            'auc': 0.0,
            'pr_auc': 0.0,
            'accuracy': 0.0,
            'precision': 0.0,
            'recall': 0.0,
            'f1_score': 0.0,
            'g_mean': 0.0
        }
    
    # 按论文：在验证集上找到最佳阈值（最大化F1分数）
    thresholds = np.linspace(np.min(scores), np.max(scores), 100)
    best_f1 = 0
    best_threshold = 0.5
    
    for threshold in thresholds:
        y_pred = (scores > threshold).astype(int)
        f1 = f1_score(y_true, y_pred, zero_division=0)
        if f1 > best_f1:
            best_f1 = f1
            best_threshold = threshold
    
    # 使用最佳阈值进行预测
    y_pred = (scores > best_threshold).astype(int)
    
    # 计算指标
    accuracy = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred, zero_division=0)
    recall = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    
    # 计算AUC
    try:
        auc = roc_auc_score(y_true, scores)
    except:
        auc = 0.0
    
    # 计算PR-AUC
    try:
        pr_auc = average_precision_score(y_true, scores)
    except:
        pr_auc = 0.0
    
    # 计算G-Mean
    try:
        tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
        specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
        g_mean = np.sqrt(recall * specificity) if recall > 0 and specificity > 0 else 0
    except:
        g_mean = 0.0
    
    return {
        'auc': round(auc, 4),
        'pr_auc': round(pr_auc, 4),
        'accuracy': round(accuracy, 4),
        'precision': round(precision, 4),
        'recall': round(recall, 4),
        'f1_score': round(f1, 4),
        'g_mean': round(g_mean, 4)
    }

# ==================== 主训练函数 ====================
def train_and_evaluate():
    """主训练和评估函数（严格按论文流程）"""
    # 设置随机种子
    torch.manual_seed(42)
    np.random.seed(42)
    
    # 读取数据
    processor = DataProcessor()
    processed_data = processor.load_and_preprocess_data()
    X_train, y_train, X_val, y_val, X_test, y_test = processed_data
    
    print(f"数据形状: X_train={X_train.shape}, y_train={y_train.shape}")
    print(f"类别分布: 正常={np.sum(y_train==0)}, 异常={np.sum(y_train==1)}")
    
    # 设置污染率（按论文实验）
    gamma_p = 0.1
    
    # 分离污染训练数据（按论文设置）
    normal_indices = np.where(y_train == 0)[0]
    anomaly_indices = np.where(y_train == 1)[0]
    
    n_normal = len(normal_indices)
    n_contamination = int(gamma_p * n_normal / (1 - gamma_p))
    
    if len(anomaly_indices) < n_contamination:
        n_contamination = len(anomaly_indices)
    
    # 创建污染数据集（正常+部分异常）
    contaminated_indices = list(normal_indices)
    if n_contamination > 0:
        contaminated_indices.extend(anomaly_indices[:n_contamination])
    
    X_contaminated = X_train[contaminated_indices]
    print(f"污染数据集: {len(X_contaminated)}个样本 ({n_contamination}个异常)")
    
    # 已知异常数据集
    known_anomaly_indices = anomaly_indices[n_contamination:]
    if len(known_anomaly_indices) == 0:
        known_anomaly_indices = anomaly_indices
    
    X_known_anomaly = X_train[known_anomaly_indices]
    print(f"已知异常集: {len(X_known_anomaly)}个样本")
    
    # 创建模型（使用CIBiGANr，按论文）
    input_dim = X_train.shape[1]
    
    model = CIBiGANr(
        input_dim=input_dim,
        latent_dim=100,
        encoder_hidden=[128, 256, 128],
        generator_hidden=[128, 256, 128],
        discriminator_hidden=[256, 128, 64],
        gamma_p=gamma_p,
        c_param=0.75,
        lr=0.0001
    )
    
    # 训练模型
    print("开始训练CIBiGANr...")
    start_time = time.time()
    
    train_losses_D, train_losses_GE = model.fit(
        X_contaminated,
        X_known_anomaly,
        X_val,
        y_val,
        epochs=100,
        batch_size=64,
        patience=10
    )
    
    training_time = time.time() - start_time
    print(f"训练时间: {training_time:.2f}秒")
    
    # 保存模型
    torch.save(model, '10BiGAN/BiGAN.pth')
    
    # 计算训练集异常分数和指标
    train_scores_start = time.time()
    train_scores = model.compute_anomaly_scores(X_contaminated)
    train_labels = np.zeros(len(X_contaminated))
    if n_contamination > 0:
        train_labels[-n_contamination:] = 1
    train_metrics = calculate_metrics(train_labels, train_scores)
    train_inference_time = time.time() - train_scores_start
    
    # 计算验证集异常分数和指标
    val_scores_start = time.time()
    val_scores = model.compute_anomaly_scores(X_val)
    val_metrics = calculate_metrics(y_val, val_scores)
    val_inference_time = time.time() - val_scores_start
    
    # 计算测试集异常分数和指标
    test_scores_start = time.time()
    test_scores = model.compute_anomaly_scores(X_test)
    test_metrics = calculate_metrics(y_test, test_scores)
    test_inference_time = time.time() - test_scores_start
    
    # 总推理时间
    total_inference_time = train_inference_time + val_inference_time + test_inference_time
    total_samples = len(X_contaminated) + len(X_val) + len(X_test)
    
    # 保存结果到CSV
    results_df = pd.DataFrame({
        'Dataset': ['Training', 'Validation', 'Testing'],
        'auc': [train_metrics['auc'], val_metrics['auc'], test_metrics['auc']],
        'pr_auc': [train_metrics['pr_auc'], val_metrics['pr_auc'], test_metrics['pr_auc']],
        'accuracy': [train_metrics['accuracy'], val_metrics['accuracy'], test_metrics['accuracy']],
        'precision': [train_metrics['precision'], val_metrics['precision'], test_metrics['precision']],
        'recall': [train_metrics['recall'], val_metrics['recall'], test_metrics['recall']],
        'f1_score': [train_metrics['f1_score'], val_metrics['f1_score'], test_metrics['f1_score']],
        'g_mean': [train_metrics['g_mean'], val_metrics['g_mean'], test_metrics['g_mean']]
    })
    
    results_df.to_csv('10BiGAN/results.csv', index=False, float_format='%.4f')
    
    # 保存时间信息
    time_df = pd.DataFrame({
        'Metric': ['Training_Time_Seconds', 'Inference_Time_Seconds', 'Inference_Speed_SamplesPerSecond'],
        'Value': [
            round(training_time, 4),
            round(total_inference_time, 4),
            round(total_samples / total_inference_time, 4) if total_inference_time > 0 else 0.0
        ]
    })
    
    time_df.to_csv('10BiGAN/time.csv', index=False, float_format='%.4f')
    
    print("\n" + "="*60)
    print("训练完成！结果已保存到10BiGAN目录")
    print("="*60)
    
    # 打印结果
    print("\n训练结果:")
    print(f"AUC: {train_metrics['auc']:.4f}, PR-AUC: {train_metrics['pr_auc']:.4f}, "
          f"Accuracy: {train_metrics['accuracy']:.4f}, F1: {train_metrics['f1_score']:.4f}")
    
    print("\n验证结果:")
    print(f"AUC: {val_metrics['auc']:.4f}, PR-AUC: {val_metrics['pr_auc']:.4f}, "
          f"Accuracy: {val_metrics['accuracy']:.4f}, F1: {val_metrics['f1_score']:.4f}")
    
    print("\n测试结果:")
    print(f"AUC: {test_metrics['auc']:.4f}, PR-AUC: {test_metrics['pr_auc']:.4f}, "
          f"Accuracy: {test_metrics['accuracy']:.4f}, F1: {test_metrics['f1_score']:.4f}")
    
    print(f"\n训练时间: {training_time:.4f}秒")
    print(f"总推理时间: {total_inference_time:.4f}秒")
    print(f"推理速度: {total_samples/total_inference_time:.4f} 样本/秒")
    
    return model, train_metrics, val_metrics, test_metrics

# ==================== 主程序 ====================
if __name__ == "__main__":
    train_and_evaluate()