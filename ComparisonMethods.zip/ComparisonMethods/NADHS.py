# -*- coding: utf-8 -*-
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import time
import os
import csv
from typing import List, Tuple, Dict
import warnings
warnings.filterwarnings('ignore')

#======================read different dataset===================================#
'''======================================================================================================='''
'''                                           Read dataset                       '''
#from ReadFinanceDataSet import DataProcessor 

'''################################## Credit Card #####################'''
#from ReadCreditcardDataset import DataProcessor


'''################################## Network Attack #####################'''
from ReadCoAtSetDataset import DataProcessor

# DSC-Net (Deep Subspace Clustering Network)
class DSCNet(nn.Module):
    """深度子空间聚类网络"""
    
    def __init__(self, input_dim: int, hidden_dims: List[int] = None, latent_dim: int = 32, 
                 lambda1: float = 0.1, lambda2: float = 0.01):
        super(DSCNet, self).__init__()
        
        if hidden_dims is None:
            self.hidden_dims = [input_dim * 2, input_dim]
        else:
            self.hidden_dims = hidden_dims
            
        self.latent_dim = latent_dim
        self.input_dim = input_dim
        
        # 编码器
        encoder_layers = []
        prev_dim = input_dim
        for h_dim in self.hidden_dims:
            encoder_layers.append(nn.Linear(prev_dim, h_dim))
            encoder_layers.append(nn.ReLU())
            prev_dim = h_dim
            
        encoder_layers.append(nn.Linear(prev_dim, latent_dim))
        self.encoder = nn.Sequential(*encoder_layers)
        
        # 自表达层
        self.self_expression = nn.Linear(latent_dim, latent_dim, bias=False)
        
        # 解码器
        decoder_layers = []
        prev_dim = latent_dim
        for h_dim in reversed(self.hidden_dims):
            decoder_layers.append(nn.Linear(prev_dim, h_dim))
            decoder_layers.append(nn.ReLU())
            prev_dim = h_dim
            
        decoder_layers.append(nn.Linear(prev_dim, input_dim))
        self.decoder = nn.Sequential(*decoder_layers)
        
        # 正则化参数
        self.lambda1 = lambda1
        self.lambda2 = lambda2
        
    def forward(self, x):
        # 编码
        z = self.encoder(x)
        
        # 自表达
        z_self = self.self_expression(z)
        
        # 解码
        x_recon = self.decoder(z_self)
        
        return x_recon, z, z_self
    
    def compute_loss(self, x, x_recon, z, z_self):
        # 重构损失
        recon_loss = torch.mean(torch.norm(x - x_recon, dim=1)**2)
        
        # 自表达正则化
        self_expr_loss = self.lambda1 * torch.norm(self.self_expression.weight, p='fro')**2
        
        # 潜在表示差异
        latent_diff_loss = self.lambda2 * torch.mean(torch.norm(z - z_self, dim=1)**2)
        
        total_loss = recon_loss + self_expr_loss + latent_diff_loss
        
        return total_loss, recon_loss.item(), self_expr_loss.item(), latent_diff_loss.item()
    
    def get_affinity_matrix(self, X: torch.Tensor) -> np.ndarray:
        """计算亲和度矩阵"""
        self.eval()
        with torch.no_grad():
            z = self.encoder(X)
            z_norm = z / torch.norm(z, dim=1, keepdim=True)
            affinity = torch.mm(z_norm, z_norm.t())
            affinity = torch.clamp(affinity, -1, 1)
            
        return affinity.cpu().numpy()

# Sequential Leader Clustering (SLC) with order sensitivity
class SequentialLeaderClustering:
    """顺序领导者聚类"""
    
    def __init__(self, delta_s: float = 0.7, delta_c: int = 5, delta_d: float = 0.3):
        self.delta_s = delta_s
        self.delta_c = delta_c
        self.delta_d = delta_d
        self.clusters = []
        self.cluster_centers = []
        self.cluster_sizes = []
        
    def order_sensitive_clustering(self, X: np.ndarray, affinity_matrix: np.ndarray) -> Tuple[List[List[int]], List[np.ndarray]]:
        """订单敏感的顺序聚类"""
        n = len(X)
        clusters = []
        cluster_centers = []
        cluster_indices = []
        
        # 计算相似度和
        similarity_sums = np.sum(affinity_matrix, axis=1)
        sorted_indices = np.argsort(similarity_sums)[::-1]
        
        # 第一个聚类中心
        first_center_idx = sorted_indices[0]
        clusters.append([first_center_idx])
        cluster_centers.append(X[first_center_idx])
        cluster_indices.append(first_center_idx)
        
        # 剩余观测点
        remaining_indices = list(set(range(n)) - set([first_center_idx]))
        
        # 按照相似度和排序处理剩余观测
        for idx in sorted_indices[1:]:
            max_similarity = -1
            best_cluster_idx = -1
            
            # 找到与该观测最相似的簇
            for cluster_idx, center_idx in enumerate(cluster_indices):
                similarity = affinity_matrix[idx, center_idx]
                if similarity > max_similarity:
                    max_similarity = similarity
                    best_cluster_idx = cluster_idx
            
            # 判断是否加入现有簇
            if max_similarity >= self.delta_s:
                clusters[best_cluster_idx].append(idx)
                cluster_members = clusters[best_cluster_idx]
                cluster_centers[best_cluster_idx] = np.mean(X[cluster_members], axis=0)
            else:
                clusters.append([idx])
                cluster_centers.append(X[idx])
                cluster_indices.append(idx)
        
        self.clusters = clusters
        self.cluster_centers = cluster_centers
        self.cluster_sizes = [len(cluster) for cluster in clusters]
        
        return clusters, cluster_centers

# Change Point Detection
class ChangePointDetector:
    """变点检测器"""
    
    def __init__(self, delta_cd: float = 10.0):
        self.delta_cd = delta_cd
        self.reconstruction_errors = []
        self.change_points = []
        
    def detect(self, reconstruction_error: float) -> bool:
        """检测是否为变点"""
        self.reconstruction_errors.append(reconstruction_error)
        
        if len(self.reconstruction_errors) < 2:
            return False
        
        error_diff = abs(self.reconstruction_errors[-1] - self.reconstruction_errors[-2])
        is_change_point = error_diff > self.delta_cd
        
        if is_change_point:
            self.change_points.append(len(self.reconstruction_errors) - 1)
            
        return is_change_point

# NADHS Main Framework
class NADHS:
    """NADHS主框架"""
    
    def __init__(self, input_dim: int, 
                 delta_s: float = 0.7,
                 delta_c: int = 5,
                 delta_d: float = 0.3,
                 delta_cd: float = 10.0,
                 learning_rate: float = 0.001,
                 hidden_dims: List[int] = None,
                 latent_dim: int = 32,
                 lambda1: float = 0.1,
                 lambda2: float = 0.01):
        
        # 初始化参数
        self.input_dim = input_dim
        self.delta_s = delta_s
        self.delta_c = delta_c
        self.delta_d = delta_d
        self.delta_cd = delta_cd
        
        # 初始化组件
        self.dsc_net = DSCNet(input_dim, hidden_dims, latent_dim, lambda1, lambda2)
        self.slc = SequentialLeaderClustering(delta_s, delta_c, delta_d)
        self.change_detector = ChangePointDetector(delta_cd)
        
        # 训练参数
        self.learning_rate = learning_rate
        self.optimizer = optim.Adam(self.dsc_net.parameters(), lr=learning_rate)
        
        # 存储历史
        self.reconstruction_errors = []
        self.anomaly_labels = []
        
        # 设备设置
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.dsc_net.to(self.device)
        
    def train_dsc_net(self, X: np.ndarray, epochs: int = 200, batch_size: int = 32) -> float:
        """训练DSC-Net"""
        X_tensor = torch.FloatTensor(X).to(self.device)
        
        # 划分训练集（论文中使用全部数据）
        train_data = X_tensor
        
        train_loader = DataLoader(TensorDataset(train_data), batch_size=batch_size, shuffle=True)
        
        best_loss = float('inf')
        
        for epoch in range(epochs):
            # 训练阶段
            self.dsc_net.train()
            train_losses = []
            
            for batch in train_loader:
                batch_data = batch[0]
                
                self.optimizer.zero_grad()
                x_recon, z, z_self = self.dsc_net(batch_data)
                loss, _, _, _ = self.dsc_net.compute_loss(batch_data, x_recon, z, z_self)
                
                loss.backward()
                self.optimizer.step()
                
                train_losses.append(loss.item())
            
            avg_train_loss = np.mean(train_losses)
            
            if avg_train_loss < best_loss:
                best_loss = avg_train_loss
            
            if (epoch + 1) % 50 == 0:
                print(f"Epoch {epoch+1}/{epochs}, Loss: {avg_train_loss:.4f}")
        
        return best_loss
    
    def anomaly_detection(self, X: np.ndarray, clusters: List[List[int]], 
                         cluster_centers: List[np.ndarray],
                         reconstruction_errors: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """异常检测算法（论文第IV-B节）"""
        n = len(X)
        
        # 1. 预检测阶段
        candidate_anomalies = np.zeros(n, dtype=int)  # 0:正常, 1:异常候选
        anomaly_types = np.zeros(n, dtype=int)  # 0:正常, 1:点异常, 2:集体异常, 3:上下文异常
        
        for cluster_idx, cluster in enumerate(clusters):
            cluster_size = len(cluster)
            
            # 规则1: 点异常（孤立簇）
            if cluster_size == 1:
                for obs_idx in cluster:
                    candidate_anomalies[obs_idx] = 1
                    anomaly_types[obs_idx] = 1
            
            # 规则2: 集体异常（微簇）
            elif 1 < cluster_size <= self.delta_c:
                for obs_idx in cluster:
                    candidate_anomalies[obs_idx] = 1
                    anomaly_types[obs_idx] = 2
            
            # 规则3: 上下文异常（大簇中的离群点）
            elif cluster_size > self.delta_c:
                center = cluster_centers[cluster_idx]
                for obs_idx in cluster:
                    # 使用相似度倒数作为距离
                    similarity = np.dot(X[obs_idx], center) / (np.linalg.norm(X[obs_idx]) * np.linalg.norm(center) + 1e-8)
                    distance = 1 - similarity
                    
                    if distance > self.delta_d:
                        candidate_anomalies[obs_idx] = 1
                        anomaly_types[obs_idx] = 3
        
        # 2. 细调阶段
        # 计算正常观测的平均重构误差
        normal_indices = np.where(candidate_anomalies == 0)[0]
        if len(normal_indices) > 0:
            normal_recon_errors = reconstruction_errors[normal_indices]
            delta_r = np.mean(normal_recon_errors)
        else:
            delta_r = np.mean(reconstruction_errors)
        
        # 最终异常标签
        final_anomaly_labels = np.zeros(n, dtype=int)
        
        for i in range(n):
            if candidate_anomalies[i] == 1:
                # 如果重构误差小于阈值，认为是正常
                if reconstruction_errors[i] < delta_r:
                    final_anomaly_labels[i] = 0
                else:
                    final_anomaly_labels[i] = 1
            else:
                final_anomaly_labels[i] = 0
        
        return final_anomaly_labels, anomaly_types
    
    # MODIFIED: 增加返回异常分数（重构误差）
    def process_snapshot(self, X: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """处理一个数据快照，返回异常标签、异常类型和异常分数"""
        X_tensor = torch.FloatTensor(X).to(self.device)
        
        # 计算重构误差
        self.dsc_net.eval()
        with torch.no_grad():
            x_recon, _, _ = self.dsc_net(X_tensor)
            recon_error = torch.mean(torch.norm(X_tensor - x_recon, dim=1)**2).item()
        
        # 变点检测
        is_change_point = self.change_detector.detect(recon_error)
        
        if is_change_point:
            print(f"检测到变点，重新训练DSC-Net...")
            self.train_dsc_net(X, epochs=100)
        
        # 获取亲和度矩阵
        affinity_matrix = self.dsc_net.get_affinity_matrix(X_tensor)
        
        # 顺序聚类
        clusters, cluster_centers = self.slc.order_sensitive_clustering(X, affinity_matrix)
        
        # 计算每个观测的重构误差
        with torch.no_grad():
            individual_recon_errors = torch.norm(X_tensor - x_recon, dim=1).cpu().numpy()
        
        # 异常检测
        anomaly_labels, anomaly_types = self.anomaly_detection(
            X, clusters, cluster_centers, individual_recon_errors
        )
        
        # 存储历史
        self.reconstruction_errors.append(recon_error)
        self.anomaly_labels.extend(anomaly_labels.tolist())
        
        # MODIFIED: 返回异常分数
        return anomaly_labels, anomaly_types, individual_recon_errors
    
    # MODIFIED: 增加 anomaly_scores 参数，并用分数计算 AUC/PR-AUC
    def evaluate(self, anomaly_labels: np.ndarray, anomaly_scores: np.ndarray, y_true: np.ndarray) -> Dict[str, float]:
        """评估模型性能，需要传入离散标签、连续分数和真实标签"""
        from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
        from sklearn.metrics import roc_auc_score, average_precision_score
        from sklearn.metrics import confusion_matrix
        
        # 确保三个数组长度一致
        min_len = min(len(anomaly_labels), len(y_true), len(anomaly_scores))
        anomaly_labels = anomaly_labels[:min_len]
        anomaly_scores = anomaly_scores[:min_len]
        y_true = y_true[:min_len]
        
        # 基础指标（基于离散标签）
        accuracy = accuracy_score(y_true, anomaly_labels)
        precision = precision_score(y_true, anomaly_labels, zero_division=0)
        recall = recall_score(y_true, anomaly_labels, zero_division=0)
        f1 = f1_score(y_true, anomaly_labels, zero_division=0)
        
        # 连续分数指标（基于 anomaly_scores）
        roc_auc = roc_auc_score(y_true, anomaly_scores)
        pr_auc = average_precision_score(y_true, anomaly_scores)
        
        # 计算G-mean
        tn, fp, fn, tp = confusion_matrix(y_true, anomaly_labels).ravel()
        specificity = tn / (tn + fp + 1e-8)
        gmean = np.sqrt(recall * specificity)
        
        return {
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1_score': f1,
            'roc_auc': roc_auc,
            'pr_auc': pr_auc,
            'gmean': gmean
        }
    
    def save_model(self, path: str):
        """保存完整模型"""
        torch.save({
            'model_state_dict': self.dsc_net.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'params': {
                'input_dim': self.input_dim,
                'delta_s': self.delta_s,
                'delta_c': self.delta_c,
                'delta_d': self.delta_d,
                'delta_cd': self.delta_cd
            }
        }, path)

def create_data_snapshots(X: np.ndarray, y: np.ndarray, window_size: int = 100, step_size: int = 50) -> Tuple[List[np.ndarray], List[np.ndarray]]:
    """将时间序列数据划分为快照"""
    snapshots = []
    labels = []
    n_samples = len(X)
    
    for start in range(0, n_samples - window_size + 1, step_size):
        end = start + window_size
        snapshot = X[start:end]
        snapshot_labels = y[start:end]
        snapshots.append(snapshot)
        labels.append(snapshot_labels)
    
    return snapshots, labels

def save_results_to_csv(results: Dict[str, float], filename: str):
    """保存结果到CSV文件"""
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    
    with open(filename, 'w', newline='') as csvfile:
        fieldnames = ['auc', 'pr_auc', 'accuracy', 'precision', 'recall', 'f1_score', 'g_mean']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        
        writer.writeheader()
        writer.writerow({
            'auc': f"{results['roc_auc']:.4f}",
            'pr_auc': f"{results['pr_auc']:.4f}",
            'accuracy': f"{results['accuracy']:.4f}",
            'precision': f"{results['precision']:.4f}",
            'recall': f"{results['recall']:.4f}",
            'f1_score': f"{results['f1_score']:.4f}",
            'g_mean': f"{results['gmean']:.4f}"
        })

def save_time_to_csv(training_time: float, total_time: float, inference_speed: float, filename: str):
    """保存时间指标到CSV文件"""
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    
    with open(filename, 'w', newline='') as csvfile:
        fieldnames = ['Training_Time_Seconds', 'Inference_Time_Seconds', 'Inference_Speed_SamplesPerSecond']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        
        writer.writeheader()
        writer.writerow({
            'Training_Time_Seconds': f"{training_time:.4f}",
            'Inference_Time_Seconds': f"{total_time:.4f}",
            'Inference_Speed_SamplesPerSecond': f"{inference_speed:.4f}"
        })

def main():
    """主函数"""
    import random
    def set_seed(seed=42):
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
            
    set_seed(42)
    
    print("NADHS: Online Anomaly Detection for High-Dimensional Data Streams")
    
    # 1. 加载和预处理数据
    print("\n1. 加载和预处理数据...")
    processor = DataProcessor()
    processed_data = processor.load_and_preprocess_data()
    
    if len(processed_data) == 6:
        X_train, y_train, X_val, y_val, X_test, y_test = processed_data
    else:
        print("数据格式不正确，预期6个返回值")
        return
    
    print(f"训练数据形状: {X_train.shape}, 训练标签形状: {y_train.shape}")
    print(f"验证数据形状: {X_val.shape}, 验证标签形状: {y_val.shape}")
    print(f"测试数据形状: {X_test.shape}, 测试标签形状: {y_test.shape}")
    
    # 2. 创建数据快照
    print("\n2. 创建数据快照...")
    window_size = 100
    step_size = 50
    
    train_snapshots, train_labels_snapshots = create_data_snapshots(X_train, y_train, window_size, step_size)
    val_snapshots, val_labels_snapshots = create_data_snapshots(X_val, y_val, window_size, step_size)
    test_snapshots, test_labels_snapshots = create_data_snapshots(X_test, y_test, window_size, step_size)
    
    print(f"训练快照数量: {len(train_snapshots)}")
    print(f"验证快照数量: {len(val_snapshots)}")
    print(f"测试快照数量: {len(test_snapshots)}")
    
    # 3. 初始化NADHS模型
    print("\n3. 初始化NADHS模型...")
    input_dim = X_train.shape[1]
    
    model = NADHS(
        input_dim=input_dim,
        delta_s=0.7,      # 论文中的δ_s
        delta_c=5,        # 论文中的δ_c
        delta_d=0.3,      # 论文中的δ_d
        delta_cd=10.0,    # 论文中的δ_cd
        learning_rate=0.001,
        hidden_dims=[input_dim * 2, input_dim],
        latent_dim=32,
        lambda1=0.1,
        lambda2=0.01
    )
    
    # 4. 初始训练
    print("\n4. 初始训练DSC-Net...")
    start_train_time = time.time()
    
    # 使用第一个训练快照进行初始训练（论文做法）
    if len(train_snapshots) > 0:
        initial_snapshot = train_snapshots[0]
        print(f"使用第一个快照进行初始训练，形状: {initial_snapshot.shape}")
        initial_loss = model.train_dsc_net(initial_snapshot, epochs=200)
        print(f"初始训练完成，损失: {initial_loss:.4f}")
    
    # 5. 处理训练数据流
    print("\n5. 处理训练数据流...")
    start_inference_time = time.time()
    
    all_train_labels = []
    all_train_predictions = []
    all_train_scores = []   # MODIFIED: 新增，收集异常分数
    total_samples = 0
    
    for i, (snapshot, labels) in enumerate(zip(train_snapshots, train_labels_snapshots)):
        print(f"处理训练快照 {i+1}/{len(train_snapshots)}...")
        # MODIFIED: 接收异常分数
        anomaly_predictions, anomaly_types, anomaly_scores = model.process_snapshot(snapshot)
        
        all_train_labels.extend(labels.tolist())
        all_train_predictions.extend(anomaly_predictions.tolist())
        all_train_scores.extend(anomaly_scores.tolist())   # MODIFIED: 收集分数
        total_samples += len(snapshot)
    
    train_inference_time = time.time() - start_inference_time
    training_time = time.time() - start_train_time
    
    # 6. 评估训练性能
    print("\n6. 评估训练性能...")
    train_labels_array = np.array(all_train_labels)
    train_predictions_array = np.array(all_train_predictions)
    train_scores_array = np.array(all_train_scores)   # MODIFIED: 转换为数组
    # MODIFIED: 传入分数
    train_results = model.evaluate(train_predictions_array, train_scores_array, train_labels_array)
    
    # 7. 处理验证数据流
    print("\n7. 处理验证数据流...")
    start_val_time = time.time()
    
    all_val_labels = []
    all_val_predictions = []
    all_val_scores = []   # MODIFIED: 新增
    
    for i, (snapshot, labels) in enumerate(zip(val_snapshots, val_labels_snapshots)):
        print(f"处理验证快照 {i+1}/{len(val_snapshots)}...")
        # MODIFIED: 接收异常分数
        anomaly_predictions, anomaly_types, anomaly_scores = model.process_snapshot(snapshot)
        
        all_val_labels.extend(labels.tolist())
        all_val_predictions.extend(anomaly_predictions.tolist())
        all_val_scores.extend(anomaly_scores.tolist())   # MODIFIED: 收集分数
    
    val_inference_time = time.time() - start_val_time
    
    # 8. 评估验证性能
    print("\n8. 评估验证性能...")
    val_labels_array = np.array(all_val_labels)
    val_predictions_array = np.array(all_val_predictions)
    val_scores_array = np.array(all_val_scores)   # MODIFIED: 转换为数组
    # MODIFIED: 传入分数
    val_results = model.evaluate(val_predictions_array, val_scores_array, val_labels_array)
    
    # 9. 处理测试数据流
    print("\n9. 处理测试数据流...")
    start_test_time = time.time()
    
    all_test_labels = []
    all_test_predictions = []
    all_test_scores = []   # MODIFIED: 新增
    
    for i, (snapshot, labels) in enumerate(zip(test_snapshots, test_labels_snapshots)):
        print(f"处理测试快照 {i+1}/{len(test_snapshots)}...")
        # MODIFIED: 接收异常分数
        anomaly_predictions, anomaly_types, anomaly_scores = model.process_snapshot(snapshot)
        
        all_test_labels.extend(labels.tolist())
        all_test_predictions.extend(anomaly_predictions.tolist())
        all_test_scores.extend(anomaly_scores.tolist())   # MODIFIED: 收集分数
    
    test_inference_time = time.time() - start_test_time
    
    # 10. 评估测试性能
    print("\n10. 评估测试性能...")
    test_labels_array = np.array(all_test_labels)
    test_predictions_array = np.array(all_test_predictions)
    test_scores_array = np.array(all_test_scores)   # MODIFIED: 转换为数组
    # MODIFIED: 传入分数
    test_results = model.evaluate(test_predictions_array, test_scores_array, test_labels_array)
    
    # 11. 保存模型和结果
    print("\n11. 保存模型和结果...")
    
    # 保存模型
    model.save_model('4NADHS/NADHS.pth')
    print("模型已保存到: 4NADHS/NADHS.pth")
    
    # 保存结果
    save_results_to_csv(train_results, '4NADHS/results_train.csv')
    save_results_to_csv(val_results, '4NADHS/results_val.csv')
    save_results_to_csv(test_results, '4NADHS/results_test.csv')
    
    # 合并结果到一个文件
    with open('4NADHS/results.csv', 'w', newline='') as csvfile:
        fieldnames = ['dataset', 'auc', 'pr_auc', 'accuracy', 'precision', 'recall', 'f1_score', 'g_mean']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        
        writer.writeheader()
        writer.writerow({
            'dataset': 'train',
            'auc': f"{train_results['roc_auc']:.4f}",
            'pr_auc': f"{train_results['pr_auc']:.4f}",
            'accuracy': f"{train_results['accuracy']:.4f}",
            'precision': f"{train_results['precision']:.4f}",
            'recall': f"{train_results['recall']:.4f}",
            'f1_score': f"{train_results['f1_score']:.4f}",
            'g_mean': f"{train_results['gmean']:.4f}"
        })
        writer.writerow({
            'dataset': 'val',
            'auc': f"{val_results['roc_auc']:.4f}",
            'pr_auc': f"{val_results['pr_auc']:.4f}",
            'accuracy': f"{val_results['accuracy']:.4f}",
            'precision': f"{val_results['precision']:.4f}",
            'recall': f"{val_results['recall']:.4f}",
            'f1_score': f"{val_results['f1_score']:.4f}",
            'g_mean': f"{val_results['gmean']:.4f}"
        })
        writer.writerow({
            'dataset': 'test',
            'auc': f"{test_results['roc_auc']:.4f}",
            'pr_auc': f"{test_results['pr_auc']:.4f}",
            'accuracy': f"{test_results['accuracy']:.4f}",
            'precision': f"{test_results['precision']:.4f}",
            'recall': f"{test_results['recall']:.4f}",
            'f1_score': f"{test_results['f1_score']:.4f}",
            'g_mean': f"{test_results['gmean']:.4f}"
        })
    
    print("结果已保存到: 4NADHS/results.csv")
    
    # 计算总推理时间
    total_inference_time = train_inference_time + val_inference_time + test_inference_time
    total_samples_processed = total_samples + len(all_val_labels) + len(all_test_labels)
    inference_speed = total_samples_processed / total_inference_time if total_inference_time > 0 else 0
    
    # 保存时间指标
    save_time_to_csv(training_time, total_inference_time, inference_speed, '4NADHS/time.csv')
    print("时间指标已保存到: 4NADHS/time.csv")
    
    # 12. 打印总结
    print("\nNADHS模型训练完成!")
    print(f"训练时间: {training_time:.4f} 秒")
    print(f"总推理时间: {total_inference_time:.4f} 秒")
    print(f"推理速度: {inference_speed:.4f} 样本/秒")
    print(f"检测到的变点: {len(model.change_detector.change_points)} 个")
    
    print("\n训练集指标:")
    print(f"  AUC:       {train_results['roc_auc']:.4f}")
    print(f"  PR-AUC:    {train_results['pr_auc']:.4f}")
    print(f"  Accuracy:  {train_results['accuracy']:.4f}")
    print(f"  Precision: {train_results['precision']:.4f}")
    print(f"  Recall:    {train_results['recall']:.4f}")
    print(f"  F1-Score:  {train_results['f1_score']:.4f}")
    print(f"  G-Mean:    {train_results['gmean']:.4f}")
    
    print("\n验证集指标:")
    print(f"  AUC:       {val_results['roc_auc']:.4f}")
    print(f"  PR-AUC:    {val_results['pr_auc']:.4f}")
    print(f"  Accuracy:  {val_results['accuracy']:.4f}")
    print(f"  Precision: {val_results['precision']:.4f}")
    print(f"  Recall:    {val_results['recall']:.4f}")
    print(f"  F1-Score:  {val_results['f1_score']:.4f}")
    print(f"  G-Mean:    {val_results['gmean']:.4f}")
    
    print("\n测试集指标:")
    print(f"  AUC:       {test_results['roc_auc']:.4f}")
    print(f"  PR-AUC:    {test_results['pr_auc']:.4f}")
    print(f"  Accuracy:  {test_results['accuracy']:.4f}")
    print(f"  Precision: {test_results['precision']:.4f}")
    print(f"  Recall:    {test_results['recall']:.4f}")
    print(f"  F1-Score:  {test_results['f1_score']:.4f}")
    print(f"  G-Mean:    {test_results['gmean']:.4f}")

if __name__ == "__main__":
    # 确保目录存在
    os.makedirs('4NADHS', exist_ok=True)
    
    # 运行主程序
    main()