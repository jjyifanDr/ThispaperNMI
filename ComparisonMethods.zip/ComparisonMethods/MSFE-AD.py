import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset
import time
import os
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# 设置随机种子以确保可重复性
torch.manual_seed(42)
np.random.seed(42)

'''======================================================================================================='''
'''                                           Read dataset                       '''
#from ReadFinanceDataSet import DataProcessor 

'''################################## Credit Card #####################'''
from ReadCreditcardDataset import DataProcessor


'''################################## Network Attack #####################'''
#from ReadCoAtSetDataset import DataProcessor

# ============================================================================
# 2. 特征提取器（完全按照论文实现）
# ============================================================================
class FeatureExtractor:
    """特征提取器 - 按照论文实现21个特征"""
    
    def __init__(self):
        # 统计特征
        self.statistical_features = ['mean', 'std', 'skewness', 'kurtosis', 'iqr', 'mad']
        # 频谱特征
        self.spectral_features = ['fft_mean', 'fft_std', 'fft_median', 'fft_max']
        # 时域特征
        self.time_features = ['mean_diff', 'std_diff', 'zero_crossing', 'entropy', 'energy']
        # 其他特征
        self.other_features = ['max', 'min', 'range', 'median', 'variance', 'percentile_25', 'percentile_75']
        
    def extract_features(self, data):
        """提取所有21个特征"""
        features = []
        
        # 统计特征
        features.append(np.mean(data))
        features.append(np.std(data))
        features.append(self._skewness(data))
        features.append(self._kurtosis(data))
        features.append(self._iqr(data))
        features.append(self._mad(data))
        
        # 频谱特征（使用FFT）
        fft_data = np.abs(np.fft.fft(data))
        features.append(np.mean(fft_data))
        features.append(np.std(fft_data))
        features.append(np.median(fft_data))
        features.append(np.max(fft_data))
        
        # 时域特征
        diff_data = np.diff(data) if len(data) > 1 else np.array([0])
        features.append(np.mean(np.abs(diff_data)) if len(diff_data) > 0 else 0)
        features.append(np.std(diff_data) if len(diff_data) > 0 else 0)
        features.append(self._zero_crossing(data))
        features.append(self._entropy(data))
        features.append(np.sum(data ** 2))
        
        # 其他特征
        features.append(np.max(data))
        features.append(np.min(data))
        features.append(np.max(data) - np.min(data))
        features.append(np.median(data))
        features.append(np.var(data))
        features.append(np.percentile(data, 25))
        features.append(np.percentile(data, 75))
        
        return np.array(features)
    
    def _skewness(self, x):
        """计算偏度"""
        n = len(x)
        if n < 3:
            return 0
        mean = np.mean(x)
        std = np.std(x)
        if std == 0:
            return 0
        return np.sum((x - mean) ** 3) / (n * std ** 3)
    
    def _kurtosis(self, x):
        """计算峰度"""
        n = len(x)
        if n < 4:
            return 0
        mean = np.mean(x)
        std = np.std(x)
        if std == 0:
            return 0
        return np.sum((x - mean) ** 4) / (n * std ** 4) - 3
    
    def _iqr(self, x):
        """计算四分位距"""
        q75, q25 = np.percentile(x, [75, 25])
        return q75 - q25
    
    def _mad(self, x):
        """计算平均绝对偏差"""
        return np.mean(np.abs(x - np.mean(x)))
    
    def _zero_crossing(self, x):
        """计算过零率"""
        if len(x) < 2:
            return 0
        zero_crossings = np.where(np.diff(np.sign(x)))[0]
        return len(zero_crossings)
    
    def _entropy(self, x, bins=10):
        """计算香农熵"""
        if len(x) == 0:
            return 0
        hist, _ = np.histogram(x, bins=bins)
        prob = hist / np.sum(hist)
        prob = prob[prob > 0]
        return -np.sum(prob * np.log2(prob)) if len(prob) > 0 else 0

# ============================================================================
# 3. 特征工程（完全按照论文实现）
# ============================================================================
class FeatureEngineering:
    """特征工程 - 按照论文公式(1)-(4)实现"""
    
    def __init__(self, feature_extractor):
        self.feature_extractor = feature_extractor
        self.best_global_feature_idx = None
        self.best_local_feature_idx = None
        self.fG_normal = None
        self.fL_normal = None
        self.fG_boundary = None
        self.fL_boundary = None
        
    def fit(self, normal_data, boundary_data):
        """
        训练特征工程模块
        完全按照论文第III节实现
        """
        n_normal = normal_data.shape[0]
        n_boundary = boundary_data.shape[0]
        
        # 提取正常数据的全局特征 F_G (公式1)
        F_G_normal = []
        for i in range(n_normal):
            features = self.feature_extractor.extract_features(normal_data[i])
            F_G_normal.append(features)
        self.fG_normal = np.array(F_G_normal)
        
        # 提取边界样本的全局特征
        F_G_boundary = []
        for i in range(n_boundary):
            features = self.feature_extractor.extract_features(boundary_data[i])
            F_G_boundary.append(features)
        self.fG_boundary = np.array(F_G_boundary)
        
        # 选择最佳全局特征（欧氏距离最大）
        self.best_global_feature_idx = self._select_best_global_feature()
        
        # 对于二维数据，局部特征与全局特征相同
        self.fL_normal = self.fG_normal.copy()
        self.fL_boundary = self.fG_boundary.copy()
        self.best_local_feature_idx = self.best_global_feature_idx
        
        return self
    
    def _select_best_global_feature(self):
        """选择最佳全局特征（按照论文：欧氏距离最大）"""
        n_features = self.fG_normal.shape[1]
        distances = []
        
        for i in range(n_features):
            # 计算正常数据和边界数据在第i个特征上的均值
            normal_mean = np.mean(self.fG_normal[:, i])
            boundary_mean = np.mean(self.fG_boundary[:, i])
            
            # 计算欧氏距离
            distance = np.abs(normal_mean - boundary_mean)
            distances.append(distance)
        
        return np.argmax(distances)
    
    def enhance_global(self, data, alpha=1.2, lambda_param=0.1):
        """
        全局特征增强 - 公式(3)
        \tilde{d}_G = d + λ(αf_G - f_o)d
        """
        enhanced_data = []
        
        for i in range(data.shape[0]):
            sample = data[i]
            features = self.feature_extractor.extract_features(sample)
            fG_data = features[self.best_global_feature_idx]
            
            # 计算f_G和f_o
            fG_normal = np.mean(self.fG_normal[:, self.best_global_feature_idx])
            fG_boundary = np.mean(self.fG_boundary[:, self.best_global_feature_idx])
            
            # 应用公式(3)
            enhancement = lambda_param * (alpha * fG_normal - fG_boundary) * sample
            enhanced_sample = sample + enhancement
            enhanced_data.append(enhanced_sample)
        
        return np.array(enhanced_data)
    
    def enhance_local(self, data, alpha=1.2, lambda_param=0.1):
        """
        局部特征增强 - 公式(4)
        \tilde{d}_L = d + λαA^T(I + λAA^T)^{-1}(f_L - Ad)
        """
        enhanced_data = []
        
        for i in range(data.shape[0]):
            sample = data[i]
            features = self.feature_extractor.extract_features(sample)
            fL_data = features[self.best_local_feature_idx]
            
            # 简化实现：对于二维数据，A是单位矩阵
            A = np.eye(len(sample))
            
            # 计算f_L（正常数据的局部特征均值）
            fL_normal = np.mean(self.fL_normal[:, self.best_local_feature_idx])
            
            # 计算Ad
            Ad = np.dot(A, sample)
            
            # 应用公式(4)
            I = np.eye(A.shape[0])
            term1 = lambda_param * alpha * A.T
            term2 = np.linalg.inv(I + lambda_param * np.dot(A, A.T))
            term3 = fL_data - Ad
            
            enhancement = np.dot(np.dot(term1, term2), term3)
            enhanced_sample = sample + enhancement
            enhanced_data.append(enhanced_sample)
        
        return np.array(enhanced_data)

# ============================================================================
# 4. VAE-LSTM模型（完全按照论文实现）
# ============================================================================
class VAE_LSTM(nn.Module):
    """VAE-LSTM模型 - 按照论文公式(5)-(8)实现"""
    
    def __init__(self, input_dim, hidden_dim=128, latent_dim=64, lstm_layers=2):
        super(VAE_LSTM, self).__init__()
        
        # LSTM编码器
        self.lstm_encoder = nn.LSTM(
            input_size=input_dim,
            hidden_size=hidden_dim,
            num_layers=lstm_layers,
            batch_first=True,
            bidirectional=False
        )
        
        # 潜在空间映射
        self.fc_mu = nn.Linear(hidden_dim, latent_dim)
        self.fc_logvar = nn.Linear(hidden_dim, latent_dim)
        
        # LSTM解码器
        self.lstm_decoder = nn.LSTM(
            input_size=latent_dim,
            hidden_size=hidden_dim,
            num_layers=lstm_layers,
            batch_first=True,
            bidirectional=False
        )
        
        # 输出层
        self.fc_out = nn.Linear(hidden_dim, input_dim)
        
    def encode(self, x):
        """编码器 - 按照论文公式(8)"""
        # LSTM编码
        _, (h_n, _) = self.lstm_encoder(x)
        h_last = h_n[-1]  # 取最后一层的最后一个隐藏状态
        
        # 计算均值和方差
        mu = self.fc_mu(h_last)
        logvar = self.fc_logvar(h_last)
        
        return mu, logvar
    
    def reparameterize(self, mu, logvar):
        """重参数化技巧 - 按照论文公式(8)"""
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std
    
    def decode(self, z):
        """解码器"""
        # 扩展维度以匹配LSTM输入
        z = z.unsqueeze(1)  # [batch_size, 1, latent_dim]
        
        # LSTM解码
        lstm_out, _ = self.lstm_decoder(z)
        
        # 输出层
        reconstructed = self.fc_out(lstm_out[:, -1, :])
        
        return reconstructed.unsqueeze(1)
    
    def forward(self, x):
        """前向传播"""
        # 编码
        mu, logvar = self.encode(x)
        
        # 重参数化
        z = self.reparameterize(mu, logvar)
        
        # 解码
        recon_x = self.decode(z)
        
        return recon_x, mu, logvar
    
    def loss_function(self, recon_x, x, mu, logvar, beta=1.0):
        """损失函数 - 按照论文公式(5)"""
        # KL散度
        kl_loss = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
        
        # 重构损失
        recon_loss = F.mse_loss(recon_x, x, reduction='sum')
        
        # 总损失
        total_loss = recon_loss + beta * kl_loss
        
        return total_loss, recon_loss, kl_loss

# ============================================================================
# 5. 检测策略（完全按照论文实现）
# ============================================================================
class DetectionStrategy:
    """检测策略 - 按照论文第III节C部分实现"""
    
    def __init__(self):
        self.R = None  # SVDD半径
        self.center = None  # SVDD中心
        self.normal_scores = None
        
    def fit_svdd(self, normal_residuals):
        """
        训练SVDD - 按照论文公式(12)
        优化目标：找到最小球体，中心为α，半径为R
        """
        # 简化实现：使用正常数据的统计特性
        # 在实际应用中，应该实现完整的SVDD优化
        
        # 计算正常数据的均值和标准差
        self.center = np.mean(normal_residuals, axis=0)
        distances = np.linalg.norm(normal_residuals - self.center, axis=1)
        
        # 设置半径R为第95百分位数的距离
        self.R = np.percentile(distances, 95)
        
        # 保存正常数据的异常分数用于归一化
        self.normal_scores = {
            'global': self._compute_global_scores(normal_residuals),
            'local': distances
        }
        
        return self
    
    def _compute_global_scores(self, residuals):
        """计算全局检测分数 - 按照论文公式(9)"""
        # u = Σ|d(t_i) - \hat{d}(t_i)|
        return np.sum(np.abs(residuals), axis=1)
    
    def global_scale_detection(self, residuals):
        """全局尺度检测"""
        return self._compute_global_scores(residuals)
    
    def local_scale_detection(self, residuals):
        """局部尺度检测 - 按照论文公式(10)-(11)"""
        # D(t_i) = d(t_i) - \hat{d}(t_i)
        D = residuals
        
        # 使用1-D平均池化压缩残差序列
        # 简化实现：对整个序列取平均
        if len(D.shape) == 2:
            v = np.mean(np.abs(D), axis=1)
        else:
            v = np.abs(D)
        
        # 计算到SVDD中心的距离
        distances = np.linalg.norm(D - self.center, axis=1) if len(D.shape) == 2 else np.abs(D - self.center)
        
        return distances
    
    def compute_gray_correlation(self, test_sample, boundary_samples, rho=0.5):
        """
        计算灰色关联度 - 按照论文公式(13)
        θ = 1/n Σ [min_min + ρ*max_max] / [|y(t)-x_i(t)| + ρ*max_max]
        """
        correlations = []
        
        for boundary_sample in boundary_samples:
            # 计算差异
            diff = np.abs(boundary_sample - test_sample)
            
            # 计算最小和最大差异
            min_diff = np.min(diff)
            max_diff = np.max(diff)
            
            # 计算灰色关联度
            numerator = min_diff + rho * max_diff
            denominator = diff + rho * max_diff
            
            # 避免除以零
            correlation = np.mean(numerator / (denominator + 1e-8))
            correlations.append(correlation)
        
        # 返回平均关联度
        return np.mean(correlations)
    
    def compute_anomaly_scores(self, l1, l2, l3, theta):
        """
        计算异常分数 - 按照论文公式(14)
        L = (l1 + l2) * l3 / [(1-θ)(l1+l2) + 2θ*l3]
        """
        # 归一化分数到[0, 1]
        l1_norm = self._normalize_scores(l1, 'global')
        l2_norm = self._normalize_scores(l2, 'local')
        l3_norm = self._normalize_scores(l3, 'global')  # 使用相同的归一化
        
        # 应用公式(14)
        numerator = (l1_norm + l2_norm) * l3_norm
        denominator = (1 - theta) * (l1_norm + l2_norm) + 2 * theta * l3_norm + 1e-8
        
        L = numerator / denominator
        
        return L
    
    def _normalize_scores(self, scores, score_type):
        """归一化分数到[0, 1]范围"""
        if self.normal_scores is None:
            # 如果没有正常数据参考，使用min-max归一化
            min_val = np.min(scores)
            max_val = np.max(scores)
            
            if max_val - min_val > 0:
                return (scores - min_val) / (max_val - min_val)
            else:
                return np.zeros_like(scores)
        else:
            # 使用正常数据的统计信息归一化
            normal_min = np.min(self.normal_scores[score_type])
            normal_max = np.max(self.normal_scores[score_type])
            
            if normal_max - normal_min > 0:
                normalized = (scores - normal_min) / (normal_max - normal_min)
                # 确保在[0, 1]范围内
                normalized = np.clip(normalized, 0, 1)
                return normalized
            else:
                return np.zeros_like(scores)

# ============================================================================
# 6. 完整的MSFE-AD模型
# ============================================================================
class MSFE_AD:
    """MSFE-AD模型 - 完全按照论文实现"""
    
    def __init__(self, input_dim, seq_len=1, device=None):
        self.input_dim = input_dim
        self.seq_len = seq_len
        
        if device is None:
            self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        else:
            self.device = device
        
        # 特征工程
        self.feature_extractor = FeatureExtractor()
        self.feature_engineering = FeatureEngineering(self.feature_extractor)
        
        # 重构模型（三个独立的子模型）
        self.vae_original = VAE_LSTM(input_dim=input_dim).to(self.device)
        self.vae_global = VAE_LSTM(input_dim=input_dim).to(self.device)
        self.vae_local = VAE_LSTM(input_dim=input_dim).to(self.device)
        
        # 检测策略
        self.detection_strategy = DetectionStrategy()
        
        # 边界样本
        self.boundary_samples = None
        
        # 训练历史
        self.train_history = {
            'original': {'loss': [], 'recon_loss': [], 'kl_loss': []},
            'global': {'loss': [], 'recon_loss': [], 'kl_loss': []},
            'local': {'loss': [], 'recon_loss': [], 'kl_loss': []}
        }
        
        # 时间记录
        self.training_time = 0
        self.inference_time = 0
    
    def fit(self, X_train, y_train, boundary_samples=None, 
            epochs=100, batch_size=32, lr=1e-3, val_data=None):
        """
        训练模型 - 完全按照论文实现
        """
        print("开始训练MSFE-AD模型...")
        start_time = time.time()
        
        # 1. 准备正常数据
        normal_idx = np.where(y_train == 0)[0]
        X_normal = X_train[normal_idx]
        
        # 确保数据有正确的维度 [batch, seq_len, features]
        if len(X_normal.shape) == 2:
            X_normal = X_normal.reshape(-1, 1, X_normal.shape[1])
        
        # 2. 准备边界样本
        if boundary_samples is None:
            print("警告：未提供边界样本，从训练数据中随机选择")
            # 如果没有边界样本，从异常数据中随机选择
            anomaly_idx = np.where(y_train == 1)[0]
            if len(anomaly_idx) >= 2:
                boundary_idx = np.random.choice(anomaly_idx, min(2, len(anomaly_idx)), replace=False)
                self.boundary_samples = X_train[boundary_idx]
            else:
                # 如果没有异常样本，从正常数据中随机选择
                boundary_idx = np.random.choice(normal_idx, min(2, len(normal_idx)), replace=False)
                self.boundary_samples = X_train[boundary_idx]
        else:
            self.boundary_samples = boundary_samples
        
        # 确保边界样本有正确的维度
        if len(self.boundary_samples.shape) == 2:
            self.boundary_samples = self.boundary_samples.reshape(-1, 1, self.boundary_samples.shape[1])
        
        # 3. 特征工程训练
        print("训练特征工程模块...")
        # 提取2D特征用于特征工程
        X_normal_2d = X_normal.reshape(-1, self.input_dim)
        boundary_samples_2d = self.boundary_samples.reshape(-1, self.input_dim)
        self.feature_engineering.fit(X_normal_2d, boundary_samples_2d)
        
        # 4. 特征增强
        print("进行特征增强...")
        X_global_2d = self.feature_engineering.enhance_global(X_normal_2d)
        X_local_2d = self.feature_engineering.enhance_local(X_normal_2d)
        
        # 重新塑形为3D
        X_normal_3d = X_normal
        X_global_3d = X_global_2d.reshape(X_normal.shape)
        X_local_3d = X_local_2d.reshape(X_normal.shape)
        
        # 5. 转换为张量
        X_original = torch.FloatTensor(X_normal_3d).to(self.device)
        X_global = torch.FloatTensor(X_global_3d).to(self.device)
        X_local = torch.FloatTensor(X_local_3d).to(self.device)
        
        # 6. 创建数据加载器
        train_dataset = TensorDataset(X_original, X_global, X_local)
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        
        # 7. 优化器
        optimizer_original = torch.optim.Adam(self.vae_original.parameters(), lr=lr)
        optimizer_global = torch.optim.Adam(self.vae_global.parameters(), lr=lr)
        optimizer_local = torch.optim.Adam(self.vae_local.parameters(), lr=lr)
        
        # 8. 训练循环
        print("开始训练VAE-LSTM模型...")
        for epoch in range(epochs):
            self.vae_original.train()
            self.vae_global.train()
            self.vae_local.train()
            
            epoch_loss_original = 0
            epoch_loss_global = 0
            epoch_loss_local = 0
            
            for batch_idx, (data_orig, data_glob, data_loc) in enumerate(train_loader):
                # 训练原始数据VAE
                recon_orig, mu_orig, logvar_orig = self.vae_original(data_orig)
                loss_orig, recon_loss_orig, kl_loss_orig = self.vae_original.loss_function(
                    recon_orig, data_orig, mu_orig, logvar_orig
                )
                
                optimizer_original.zero_grad()
                loss_orig.backward()
                optimizer_original.step()
                
                # 训练全局增强数据VAE
                recon_glob, mu_glob, logvar_glob = self.vae_global(data_glob)
                loss_glob, recon_loss_glob, kl_loss_glob = self.vae_global.loss_function(
                    recon_glob, data_glob, mu_glob, logvar_glob
                )
                
                optimizer_global.zero_grad()
                loss_glob.backward()
                optimizer_global.step()
                
                # 训练局部增强数据VAE
                recon_loc, mu_loc, logvar_loc = self.vae_local(data_loc)
                loss_loc, recon_loss_loc, kl_loss_loc = self.vae_local.loss_function(
                    recon_loc, data_loc, mu_loc, logvar_loc
                )
                
                optimizer_local.zero_grad()
                loss_loc.backward()
                optimizer_local.step()
                
                epoch_loss_original += loss_orig.item()
                epoch_loss_global += loss_glob.item()
                epoch_loss_local += loss_loc.item()
            
            # 记录训练历史
            self.train_history['original']['loss'].append(epoch_loss_original / len(train_loader))
            self.train_history['global']['loss'].append(epoch_loss_global / len(train_loader))
            self.train_history['local']['loss'].append(epoch_loss_local / len(train_loader))
            
            if (epoch + 1) % 10 == 0:
                print(f"Epoch {epoch+1}/{epochs}: "
                      f"Loss - Original: {epoch_loss_original/len(train_loader):.4f}, "
                      f"Global: {epoch_loss_global/len(train_loader):.4f}, "
                      f"Local: {epoch_loss_local/len(train_loader):.4f}")
        
        # 9. 训练检测策略
        print("训练检测策略...")
        self._train_detection_strategy(X_normal_3d)
        
        self.training_time = time.time() - start_time
        print(f"训练完成! 总训练时间: {self.training_time:.2f}秒")
        
        return self
    
    def _train_detection_strategy(self, X_normal):
        """训练检测策略"""
        # 准备数据
        X_normal_2d = X_normal.reshape(-1, self.input_dim)
        
        # 特征增强
        X_global_2d = self.feature_engineering.enhance_global(X_normal_2d)
        X_local_2d = self.feature_engineering.enhance_local(X_normal_2d)
        
        # 重新塑形
        X_normal_3d = X_normal
        X_global_3d = X_global_2d.reshape(X_normal.shape)
        X_local_3d = X_local_2d.reshape(X_normal.shape)
        
        # 转换为张量
        X_orig_tensor = torch.FloatTensor(X_normal_3d).to(self.device)
        X_glob_tensor = torch.FloatTensor(X_global_3d).to(self.device)
        X_loc_tensor = torch.FloatTensor(X_local_3d).to(self.device)
        
        # 计算重构误差
        self.vae_original.eval()
        self.vae_global.eval()
        self.vae_local.eval()
        
        with torch.no_grad():
            # 原始数据重构误差
            recon_orig, _, _ = self.vae_original(X_orig_tensor)
            residuals_orig = (X_orig_tensor - recon_orig).cpu().numpy()
            
            # 全局增强数据重构误差
            recon_glob, _, _ = self.vae_global(X_glob_tensor)
            residuals_glob = (X_glob_tensor - recon_glob).cpu().numpy()
            
            # 局部增强数据重构误差
            recon_loc, _, _ = self.vae_local(X_loc_tensor)
            residuals_loc = (X_loc_tensor - recon_loc).cpu().numpy()
        
        # 训练SVDD（使用局部增强数据的残差）
        residuals_loc_2d = residuals_loc.reshape(-1, self.input_dim)
        self.detection_strategy.fit_svdd(residuals_loc_2d)
        
        # 保存正常数据的重构误差用于归一化
        residuals_orig_2d = residuals_orig.reshape(-1, self.input_dim)
        residuals_glob_2d = residuals_glob.reshape(-1, self.input_dim)
        
        self.detection_strategy.normal_scores = {
            'global': self.detection_strategy.global_scale_detection(residuals_glob_2d),
            'local': self.detection_strategy.local_scale_detection(residuals_loc_2d),
            'original': self.detection_strategy.global_scale_detection(residuals_orig_2d)
        }
    
    def decision_function(self, X):
        """
        计算异常分数 - 按照论文公式(14)
        返回：异常分数L
        """
        inference_start = time.time()
        
        # 确保数据有正确的维度
        if len(X.shape) == 2:
            X = X.reshape(-1, 1, X.shape[1])
        
        X_2d = X.reshape(-1, self.input_dim)
        
        # 特征增强
        X_global_2d = self.feature_engineering.enhance_global(X_2d)
        X_local_2d = self.feature_engineering.enhance_local(X_2d)
        
        # 重新塑形
        X_3d = X
        X_global_3d = X_global_2d.reshape(X.shape)
        X_local_3d = X_local_2d.reshape(X.shape)
        
        # 转换为张量
        X_tensor = torch.FloatTensor(X_3d).to(self.device)
        X_global_tensor = torch.FloatTensor(X_global_3d).to(self.device)
        X_local_tensor = torch.FloatTensor(X_local_3d).to(self.device)
        
        # 计算重构误差
        self.vae_original.eval()
        self.vae_global.eval()
        self.vae_local.eval()
        
        with torch.no_grad():
            # 原始数据重构
            recon_orig, _, _ = self.vae_original(X_tensor)
            residuals_orig = (X_tensor - recon_orig).cpu().numpy()
            
            # 全局增强数据重构
            recon_glob, _, _ = self.vae_global(X_global_tensor)
            residuals_glob = (X_global_tensor - recon_glob).cpu().numpy()
            
            # 局部增强数据重构
            recon_loc, _, _ = self.vae_local(X_local_tensor)
            residuals_loc = (X_local_tensor - recon_loc).cpu().numpy()
        
        # 转换到2D
        residuals_orig_2d = residuals_orig.reshape(-1, self.input_dim)
        residuals_glob_2d = residuals_glob.reshape(-1, self.input_dim)
        residuals_loc_2d = residuals_loc.reshape(-1, self.input_dim)
        
        # 计算异常分数
        l1 = self.detection_strategy.global_scale_detection(residuals_glob_2d)
        l2 = self.detection_strategy.local_scale_detection(residuals_loc_2d)
        l3 = self.detection_strategy.global_scale_detection(residuals_orig_2d)
        
        # 计算灰色关联度θ
        theta_values = []
        boundary_samples_2d = self.boundary_samples.reshape(-1, self.input_dim)
        
        for i in range(len(X_2d)):
            test_sample = X_2d[i]
            theta = self.detection_strategy.compute_gray_correlation(test_sample, boundary_samples_2d)
            theta_values.append(theta)
        
        theta_values = np.array(theta_values)
        
        # 计算最终异常分数L
        L = self.detection_strategy.compute_anomaly_scores(l1, l2, l3, theta_values)
        
        # 记录推理时间
        self.inference_time += time.time() - inference_start
        
        return L
    
    def predict(self, X):
        """
        预测异常 - 按照论文：当L>1时为异常
        """
        anomaly_scores = self.decision_function(X)
        
        # 按照论文：L>1为异常
        predictions = (anomaly_scores > 1.0).astype(int)
        
        return predictions, anomaly_scores
    
    def save_model(self, path):
        """保存模型"""
        model_state = {
            'vae_original_state_dict': self.vae_original.state_dict(),
            'vae_global_state_dict': self.vae_global.state_dict(),
            'vae_local_state_dict': self.vae_local.state_dict(),
            'feature_engineering': {
                'best_global_feature_idx': self.feature_engineering.best_global_feature_idx,
                'best_local_feature_idx': self.feature_engineering.best_local_feature_idx,
                'fG_normal': self.feature_engineering.fG_normal,
                'fL_normal': self.feature_engineering.fL_normal,
                'fG_boundary': self.feature_engineering.fG_boundary,
                'fL_boundary': self.feature_engineering.fL_boundary
            },
            'detection_strategy': {
                'R': self.detection_strategy.R,
                'center': self.detection_strategy.center,
                'normal_scores': self.detection_strategy.normal_scores
            },
            'boundary_samples': self.boundary_samples,
            'input_dim': self.input_dim,
            'seq_len': self.seq_len
        }
        
        torch.save(model_state, path)
        print(f"模型已保存到 {path}")
    
    def load_model(self, path):
        """加载模型"""
        model_state = torch.load(path, map_location=self.device)
        
        self.vae_original.load_state_dict(model_state['vae_original_state_dict'])
        self.vae_global.load_state_dict(model_state['vae_global_state_dict'])
        self.vae_local.load_state_dict(model_state['vae_local_state_dict'])
        
        self.feature_engineering.best_global_feature_idx = model_state['feature_engineering']['best_global_feature_idx']
        self.feature_engineering.best_local_feature_idx = model_state['feature_engineering']['best_local_feature_idx']
        self.feature_engineering.fG_normal = model_state['feature_engineering']['fG_normal']
        self.feature_engineering.fL_normal = model_state['feature_engineering']['fL_normal']
        self.feature_engineering.fG_boundary = model_state['feature_engineering']['fG_boundary']
        self.feature_engineering.fL_boundary = model_state['feature_engineering']['fL_boundary']
        
        self.detection_strategy.R = model_state['detection_strategy']['R']
        self.detection_strategy.center = model_state['detection_strategy']['center']
        self.detection_strategy.normal_scores = model_state['detection_strategy']['normal_scores']
        
        self.boundary_samples = model_state['boundary_samples']
        
        print(f"模型已从 {path} 加载")

# ============================================================================
# 7. 评估指标计算
# ============================================================================
def calculate_metrics(y_true, y_pred, y_scores):
    """计算所有评估指标"""
    from sklearn.metrics import (
        roc_auc_score, average_precision_score, accuracy_score,
        precision_score, recall_score, f1_score, confusion_matrix
    )
    
    metrics = {}
    
    # AUC
    try:
        metrics['auc'] = roc_auc_score(y_true, y_scores)
    except:
        metrics['auc'] = 0.0
    
    # PR AUC
    try:
        metrics['pr_auc'] = average_precision_score(y_true, y_scores)
    except:
        metrics['pr_auc'] = 0.0
    
    # 其他指标
    metrics['accuracy'] = accuracy_score(y_true, y_pred)
    metrics['precision'] = precision_score(y_true, y_pred, zero_division=0)
    metrics['recall'] = recall_score(y_true, y_pred, zero_division=0)
    metrics['f1_score'] = f1_score(y_true, y_pred, zero_division=0)
    
    # G-Mean
    try:
        tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
        specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
        sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0
        metrics['g_mean'] = np.sqrt(sensitivity * specificity)
    except:
        metrics['g_mean'] = 0.0
    
    return metrics

# ============================================================================
# 8. 主训练和评估函数
# ============================================================================
def main():
    """主函数"""
    print("=" * 60)
    print("MSFE-AD异常检测模型 - 完全按照论文实现")
    print("=" * 60)
    
    # 创建结果目录
    results_dir = Path("16MSFE-AD")
    results_dir.mkdir(exist_ok=True)
    
    # 1. 加载数据
    print("\n1. 加载数据...")
    processor = DataProcessor()
    X_train, y_train, X_val, y_val, X_test, y_test = processor.load_and_preprocess_data()
    
    print(f"训练集: {X_train.shape}, 异常比例: {np.mean(y_train):.4f}")
    print(f"验证集: {X_val.shape}, 异常比例: {np.mean(y_val):.4f}")
    print(f"测试集: {X_test.shape}, 异常比例: {np.mean(y_test):.4f}")
    
    # 2. 创建模型
    print("\n2. 创建MSFE-AD模型...")
    input_dim = X_train.shape[1]
    model = MSFE_AD(input_dim=input_dim, seq_len=1)
    
    # 3. 准备边界样本
    print("\n3. 准备边界样本...")
    # 从训练集的异常样本中选择边界样本
    anomaly_idx = np.where(y_train == 1)[0]
    if len(anomaly_idx) >= 2:
        boundary_idx = np.random.choice(anomaly_idx, min(2, len(anomaly_idx)), replace=False)
        boundary_samples = X_train[boundary_idx]
    else:
        # 如果没有异常样本，从正常数据中选择
        normal_idx = np.where(y_train == 0)[0]
        boundary_idx = np.random.choice(normal_idx, 2, replace=False)
        boundary_samples = X_train[boundary_idx]
    
    # 4. 训练模型
    print("\n4. 训练模型...")
    model.fit(
        X_train, y_train,
        boundary_samples=boundary_samples,
        epochs=50,
        batch_size=64,
        lr=1e-3
    )
    
    # 5. 保存模型
    print("\n5. 保存模型...")
    model.save_model("16MSFE-AD/MSFE-AD.pth")
    
    # 6. 在训练集上评估
    print("\n6. 在训练集上评估...")
    train_start_time = time.time()
    train_pred, train_scores = model.predict(X_train)
    train_inference_time = time.time() - train_start_time
    
    train_metrics = calculate_metrics(y_train, train_pred, train_scores)
    print(f"训练集结果 - AUC: {train_metrics['auc']:.4f}, F1: {train_metrics['f1_score']:.4f}")
    
    # 7. 在验证集上评估
    print("\n7. 在验证集上评估...")
    val_start_time = time.time()
    val_pred, val_scores = model.predict(X_val)
    val_inference_time = time.time() - val_start_time
    
    val_metrics = calculate_metrics(y_val, val_pred, val_scores)
    print(f"验证集结果 - AUC: {val_metrics['auc']:.4f}, F1: {val_metrics['f1_score']:.4f}")
    
    # 8. 在测试集上评估
    print("\n8. 在测试集上评估...")
    test_start_time = time.time()
    test_pred, test_scores = model.predict(X_test)
    test_inference_time = time.time() - test_start_time
    
    test_metrics = calculate_metrics(y_test, test_pred, test_scores)
    print(f"测试集结果 - AUC: {test_metrics['auc']:.4f}, F1: {test_metrics['f1_score']:.4f}")
    
    # 9. 保存结果到CSV文件
    print("\n9. 保存结果到CSV文件...")
    
    # 保存性能结果
    results_df = pd.DataFrame({
        'dataset': ['train', 'val', 'test'],
        'auc': [
            round(train_metrics['auc'], 4),
            round(val_metrics['auc'], 4),
            round(test_metrics['auc'], 4)
        ],
        'pr_auc': [
            round(train_metrics['pr_auc'], 4),
            round(val_metrics['pr_auc'], 4),
            round(test_metrics['pr_auc'], 4)
        ],
        'accuracy': [
            round(train_metrics['accuracy'], 4),
            round(val_metrics['accuracy'], 4),
            round(test_metrics['accuracy'], 4)
        ],
        'precision': [
            round(train_metrics['precision'], 4),
            round(val_metrics['precision'], 4),
            round(test_metrics['precision'], 4)
        ],
        'recall': [
            round(train_metrics['recall'], 4),
            round(val_metrics['recall'], 4),
            round(test_metrics['recall'], 4)
        ],
        'f1_score': [
            round(train_metrics['f1_score'], 4),
            round(val_metrics['f1_score'], 4),
            round(test_metrics['f1_score'], 4)
        ],
        'g_mean': [
            round(train_metrics['g_mean'], 4),
            round(val_metrics['g_mean'], 4),
            round(test_metrics['g_mean'], 4)
        ]
    })
    
    results_df.to_csv("16MSFE-AD/results.csv", index=False)
    print("性能结果已保存到: 16MSFE-AD/results.csv")
    
    # 保存时间结果
    total_inference_time = train_inference_time + val_inference_time + test_inference_time
    total_samples = len(X_train) + len(X_val) + len(X_test)
    inference_speed = total_samples / total_inference_time if total_inference_time > 0 else 0
    
    time_df = pd.DataFrame({
        'metric': ['Training_Time_Seconds', 'Inference_Time_Seconds', 'Inference_Speed_SamplesPerSecond'],
        'value': [
            round(model.training_time, 4),
            round(total_inference_time, 4),
            round(inference_speed, 4)
        ]
    })
    
    time_df.to_csv("16MSFE-AD/time.csv", index=False)
    print("时间结果已保存到: 16MSFE-AD/time.csv")
    
    # 10. 打印最终结果
    print("\n" + "=" * 60)
    print("最终结果汇总")
    print("=" * 60)
    
    print("\n性能指标:")
    print(results_df.to_string(index=False))
    
    print("\n时间指标:")
    print(time_df.to_string(index=False))
    
    print("\n模型已保存到: 16MSFE-AD/MSFE-AD.pth")
    print("所有结果已保存到 16MSFE-AD/ 目录")
    print("=" * 60)

# ============================================================================
# 主程序入口
# ============================================================================
if __name__ == "__main__":
    main()