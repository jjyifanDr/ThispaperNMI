import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_curve, auc, average_precision_score, confusion_matrix
import time
import os
import pandas as pd
import warnings
warnings.filterwarnings('ignore')

# 从提供的数据处理器导入数据
'''======================================================================================================='''
'''                                           Read dataset                       '''
#from ReadFinanceDataSet import DataProcessor 

'''################################## Credit Card #####################'''
from ReadCreditcardDataset import DataProcessor


'''################################## Network Attack #####################'''
#from ReadCoAtSetDataset import DataProcessor

# TCN模块实现
class CausalConv1d(nn.Module):
    """因果卷积层"""
    def __init__(self, in_channels, out_channels, kernel_size=3, dilation=1):
        super(CausalConv1d, self).__init__()
        self.padding = (kernel_size - 1) * dilation
        self.conv = nn.Conv1d(in_channels, out_channels, kernel_size, 
                              padding=self.padding, dilation=dilation)
        
    def forward(self, x):
        x = self.conv(x)
        # 移除右侧的填充部分以保持因果性
        return x[:, :, :-self.padding] if self.padding > 0 else x

class TCNResidualBlock(nn.Module):
    """TCN残差块"""
    def __init__(self, in_channels, out_channels, kernel_size=3, dilation=1, dropout=0.2):
        super(TCNResidualBlock, self).__init__()
        
        # 第一层因果卷积
        self.conv1 = CausalConv1d(in_channels, out_channels, kernel_size, dilation)
        self.bn1 = nn.BatchNorm1d(out_channels)
        
        # 第二层因果卷积
        self.conv2 = CausalConv1d(out_channels, out_channels, kernel_size, 1)
        self.bn2 = nn.BatchNorm1d(out_channels)
        
        # 如果输入输出通道数不同，使用1x1卷积调整维度
        self.downsample = nn.Conv1d(in_channels, out_channels, 1) if in_channels != out_channels else None
        
        self.dropout = nn.Dropout(dropout)
        
    def forward(self, x):
        identity = x
        
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.dropout(out)
        out = self.bn2(self.conv2(out))
        
        if self.downsample is not None:
            identity = self.downsample(identity)
            
        out += identity
        out = F.relu(out)
        
        return out

class TCNEncoder(nn.Module):
    """TCN编码器"""
    def __init__(self, input_size, hidden_size=64, num_layers=3, kernel_size=3, dropout=0.2):
        super(TCNEncoder, self).__init__()
        
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        
        # 输入投影层
        self.input_proj = nn.Conv1d(input_size, hidden_size, 1)
        
        # TCN残差块
        self.tcn_layers = nn.ModuleList()
        for i in range(num_layers):
            dilation = 2 ** i  # 膨胀率按指数增长
            self.tcn_layers.append(
                TCNResidualBlock(hidden_size, hidden_size, kernel_size, dilation, dropout)
            )
        
    def forward(self, x):
        # x shape: (batch_size, seq_len, input_size)
        # 转换为 (batch_size, input_size, seq_len) 用于Conv1d
        x = x.transpose(1, 2)
        
        # 输入投影
        x = self.input_proj(x)
        
        # 通过TCN层
        for layer in self.tcn_layers:
            x = layer(x)
        
        # 转回 (batch_size, seq_len, hidden_size)
        x = x.transpose(1, 2)
        
        return x

# 改进的注意力机制 - 更接近论文公式(9)-(12)
class ImprovedAttention(nn.Module):
    """改进的注意力机制，更接近论文描述"""
    def __init__(self, hidden_size, num_heads=4):
        super(ImprovedAttention, self).__init__()
        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.head_dim = hidden_size // num_heads
        
        # 确保head_dim是整数
        assert self.head_dim * num_heads == hidden_size, "hidden_size必须能被num_heads整除"
        
        # 为每个头创建独立的线性变换
        self.q_proj = nn.ModuleList([nn.Linear(self.head_dim, self.head_dim, bias=False) for _ in range(num_heads)])
        self.k_proj = nn.ModuleList([nn.Linear(self.head_dim, self.head_dim, bias=False) for _ in range(num_heads)])
        self.v_proj = nn.ModuleList([nn.Linear(self.head_dim, self.head_dim, bias=False) for _ in range(num_heads)])
        
        # 注意力参数，对应论文中的α_att
        self.alpha_att = nn.ParameterList([nn.Parameter(torch.randn(self.head_dim)) for _ in range(num_heads)])
        
        # 输出投影
        self.out_proj = nn.Linear(hidden_size, hidden_size)
        
        # MLP参数，对应论文中的W_MLP2和b_MLP2
        self.W_MLP2 = nn.Linear(hidden_size, hidden_size)
        self.b_MLP2 = nn.Parameter(torch.zeros(hidden_size))
        
    def forward(self, z):
        # z: (batch_size, seq_len, hidden_size)
        batch_size, seq_len, _ = z.shape
        
        # 分割为多个头
        z_split = z.view(batch_size, seq_len, self.num_heads, self.head_dim)
        z_split = z_split.transpose(1, 2)  # (batch_size, num_heads, seq_len, head_dim)
        
        head_outputs = []
        
        for i in range(self.num_heads):
            head_z = z_split[:, i, :, :]  # (batch_size, seq_len, head_dim)
            
            # 线性变换得到Q, K, V
            Q = self.q_proj[i](head_z)
            K = self.k_proj[i](head_z)
            V = self.v_proj[i](head_z)
            
            # 计算注意力分数 - 使用加法注意力（Bahdanau attention）
            # 对应论文公式(9): α = σ(α_att^T * (wz))
            # 这里简化为Q和K的点积加上α_att的投影
            scores = torch.matmul(Q, K.transpose(-2, -1)) / (self.head_dim ** 0.5)
            
            # 添加α_att的影响（简化处理）
            alpha_att_effect = torch.matmul(Q + K, self.alpha_att[i]) / self.head_dim
            alpha_att_effect = alpha_att_effect.unsqueeze(-1).expand(-1, -1, seq_len)
            scores = scores + alpha_att_effect
            
            # 应用softmax
            attention_weights = F.softmax(scores, dim=-1)
            
            # 应用注意力权重
            head_output = torch.matmul(attention_weights, V)
            head_outputs.append(head_output)
        
        # 合并多头输出
        head_outputs = torch.stack(head_outputs, dim=1)  # (batch_size, num_heads, seq_len, head_dim)
        head_outputs = head_outputs.transpose(1, 2).contiguous()  # (batch_size, seq_len, num_heads, head_dim)
        combined_output = head_outputs.view(batch_size, seq_len, self.hidden_size)
        
        # 输出投影
        output = self.out_proj(combined_output)
        
        # 激活函数和MLP变换 - 对应论文公式(12)
        output = torch.relu(output)
        output = self.W_MLP2(output) + self.b_MLP2
        
        return output, None

# HSC模型 - 完全按照论文描述实现
class HSC(nn.Module):
    """Hypersphere Constraint Network for Multivariate Time Series Anomaly Detection"""
    def __init__(self, input_size, window_size, hidden_size=64, num_tcn_layers=3, 
                 num_heads=4, latent_size=128, beta=0.5, R=1.0):
        super(HSC, self).__init__()
        
        self.input_size = input_size
        self.window_size = window_size
        self.hidden_size = hidden_size
        self.latent_size = latent_size
        self.beta = beta
        self.R = nn.Parameter(torch.tensor(R, dtype=torch.float32))  # 可学习的半径
        
        # 编码器部分 - 按照论文描述
        self.tcn_encoder = TCNEncoder(input_size, hidden_size, num_tcn_layers)
        
        # MLP将TCN输出映射到潜空间 - 对应论文中的MLP1
        self.W_MLP1 = nn.Linear(hidden_size * window_size, latent_size)
        self.b_MLP1 = nn.Parameter(torch.zeros(latent_size))
        
        # 潜空间中心（按照COUTA方法，初始化为第一个批次输出的均值）
        self.c = nn.Parameter(torch.zeros(latent_size))
        
        # 解码器部分
        # MLP从潜空间恢复 - 对应论文中的MLP2的前半部分
        self.mlp_decoder = nn.Sequential(
            nn.Linear(latent_size, hidden_size * window_size),
            nn.ReLU()
        )
        
        # 自注意力机制（结合GAT和Transformer）
        self.attention = ImprovedAttention(hidden_size, num_heads)
        
        # 最终输出层，重构输入
        self.output_layer = nn.Linear(hidden_size, input_size)
        
    def forward(self, x):
        # x: (batch_size, window_size, input_size)
        batch_size = x.shape[0]
        
        # ========== 编码器部分 ==========
        # TCN编码
        tcn_output = self.tcn_encoder(x)  # (batch_size, window_size, hidden_size)
        
        # 展平TCN输出
        tcn_flat = tcn_output.reshape(batch_size, -1)  # (batch_size, window_size * hidden_size)
        
        # MLP映射到潜空间 - 对应论文公式(6)
        z = torch.relu(self.W_MLP1(tcn_flat) + self.b_MLP1)  # (batch_size, latent_size)
        
        # ========== 解码器部分 ==========
        # MLP从潜空间恢复
        decoder_input = self.mlp_decoder(z)  # (batch_size, window_size * hidden_size)
        decoder_input = decoder_input.reshape(batch_size, self.window_size, self.hidden_size)
        
        # 自注意力机制
        attn_output, _ = self.attention(decoder_input)  # (batch_size, window_size, hidden_size)
        
        # 输出投影，重构输入
        reconstructed = self.output_layer(attn_output)  # (batch_size, window_size, input_size)
        
        return reconstructed, z
    
    def compute_loss(self, x, reconstructed, z):
        # 重构损失 - 对应论文公式(13)
        recon_loss = torch.mean((reconstructed - x) ** 2)
        
        # One-class分类损失 - 对应论文公式(8)
        dist = torch.norm(z - self.c, dim=1)  # 到中心的距离
        one_class_loss = torch.mean((dist - self.R) ** 2)
        
        # 总损失 - 对应论文公式(14)
        total_loss = recon_loss + self.beta * one_class_loss
        
        return total_loss, recon_loss, one_class_loss
    
    def compute_anomaly_score(self, x):
        with torch.no_grad():
            reconstructed, z = self.forward(x)
            
            # 重构误差 - 对应论文公式(13)
            recon_error = torch.mean((reconstructed - x) ** 2, dim=(1, 2))
            
            # One-class误差 - 对应论文公式(8)
            dist = torch.norm(z - self.c, dim=1)
            one_class_error = (dist - self.R) ** 2
            
            # 综合异常分数 - 对应论文公式(14)
            anomaly_score = recon_error + self.beta * one_class_error
            
        return anomaly_score.cpu().numpy()

# 早停机制
class EarlyStopping:
    def __init__(self, patience=10, verbose=True, delta=0):
        self.patience = patience
        self.verbose = verbose
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.val_loss_min = np.Inf
        self.delta = delta

    def __call__(self, val_loss, model, model_path):
        score = -val_loss

        if self.best_score is None:
            self.best_score = score
            self.save_checkpoint(val_loss, model, model_path)
        elif score < self.best_score + self.delta:
            self.counter += 1
            if self.verbose:
                print(f'EarlyStopping counter: {self.counter} out of {self.patience}')
            if self.counter >= self.patience:
                self.early_stop = True
        else:
            self.best_score = score
            self.save_checkpoint(val_loss, model, model_path)
            self.counter = 0

    def save_checkpoint(self, val_loss, model, model_path):
        if self.verbose:
            print(f'Validation loss decreased ({self.val_loss_min:.6f} --> {val_loss:.6f}). Saving model...')
        torch.save(model.state_dict(), model_path)
        self.val_loss_min = val_loss

# 训练函数
def train_hsc_model(model, train_loader, val_loader, num_epochs=100, learning_rate=0.001, patience=10):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model.to(device)
    
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=5, verbose=True)
    
    # 删除旧的模型文件，避免加载错误
    model_path = 'HSC.pth'
    if os.path.exists(model_path):
        print(f"删除旧的模型文件: {model_path}")
        os.remove(model_path)
    
    # 初始化中心c为第一个批次输出的均值（按照COUTA方法）
    with torch.no_grad():
        for batch_idx, (data, _) in enumerate(train_loader):
            data = data.to(device)
            _, z = model(data)
            model.c.data = z.mean(dim=0)
            break
    
    early_stopping = EarlyStopping(patience=patience, verbose=True)
    
    train_losses = []
    val_losses = []
    
    print("开始训练HSC模型...")
    start_time = time.time()
    
    for epoch in range(num_epochs):
        # 训练阶段
        model.train()
        train_loss = 0
        
        for batch_idx, (data, _) in enumerate(train_loader):
            data = data.to(device)
            
            optimizer.zero_grad()
            reconstructed, z = model(data)
            total_loss, _, _ = model.compute_loss(data, reconstructed, z)
            
            total_loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()
            
            train_loss += total_loss.item()
        
        avg_train_loss = train_loss / len(train_loader)
        train_losses.append(avg_train_loss)
        
        # 验证阶段
        model.eval()
        val_loss = 0
        
        with torch.no_grad():
            for data, _ in val_loader:
                data = data.to(device)
                reconstructed, z = model(data)
                total_loss, _, _ = model.compute_loss(data, reconstructed, z)
                val_loss += total_loss.item()
        
        avg_val_loss = val_loss / len(val_loader)
        val_losses.append(avg_val_loss)
        
        # 更新学习率
        scheduler.step(avg_val_loss)
        
        # 打印训练信息
        if (epoch + 1) % 10 == 0:
            print(f'Epoch [{epoch+1}/{num_epochs}], '
                  f'Train Loss: {avg_train_loss:.6f}, '
                  f'Val Loss: {avg_val_loss:.6f}, '
                  f'R: {model.R.item():.4f}')
        
        # 早停检查
        early_stopping(avg_val_loss, model, model_path)
        if early_stopping.early_stop:
            print("早停触发")
            break
    
    training_time = time.time() - start_time
    print(f"训练完成，总时间: {training_time:.2f}秒")
    
    # 加载最佳模型
    if os.path.exists(model_path):
        model.load_state_dict(torch.load(model_path))
    else:
        print("警告: 未找到保存的模型文件，使用最后训练的模型")
    
    return train_losses, val_losses, training_time, model_path

# 评估函数 - 按照论文方法使用网格搜索寻找最佳阈值
def evaluate_with_threshold(model, data_loader, y_true, set_name="", beta=0.5):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model.to(device)
    model.eval()
    
    # 计算异常分数
    all_scores = []
    
    with torch.no_grad():
        for data, _ in data_loader:
            data = data.to(device)
            scores = model.compute_anomaly_score(data)
            all_scores.extend(scores)
    
    all_scores = np.array(all_scores)
    y_true = y_true[:len(all_scores)]
    
    # 按照论文方法：网格搜索寻找最佳阈值（基于F1分数）
    # 在异常分数的范围内搜索100个阈值点
    score_min, score_max = all_scores.min(), all_scores.max()
    thresholds = np.linspace(score_min, score_max, 100)
    
    best_f1 = 0
    best_threshold = score_min
    best_predictions = None
    
    for threshold in thresholds:
        predictions = (all_scores > threshold).astype(int)
        # 确保至少有一些预测为异常，避免除零错误
        if np.sum(predictions) > 0:
            precision = precision_score(y_true, predictions, zero_division=0)
            recall = recall_score(y_true, predictions, zero_division=0)
            if precision + recall > 0:
                f1 = 2 * precision * recall / (precision + recall)
                if f1 > best_f1:
                    best_f1 = f1
                    best_threshold = threshold
                    best_predictions = predictions
    
    # 如果未找到合适的阈值，使用中位数
    if best_predictions is None:
        best_threshold = np.median(all_scores)
        best_predictions = (all_scores > best_threshold).astype(int)
    
    # 使用最佳阈值计算所有指标
    y_pred = best_predictions
    
    # 计算评估指标
    accuracy = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred, zero_division=0)
    recall = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    
    # 计算G-mean
    tn = np.sum((y_true == 0) & (y_pred == 0))
    fp = np.sum((y_true == 0) & (y_pred == 1))
    fn = np.sum((y_true == 1) & (y_pred == 0))
    tp = np.sum((y_true == 1) & (y_pred == 1))
    
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
    sensitivity = recall
    gmean = np.sqrt(specificity * sensitivity) if specificity > 0 and sensitivity > 0 else 0
    
    # 计算AUC
    fpr, tpr, _ = roc_curve(y_true, all_scores)
    roc_auc = auc(fpr, tpr)
    
    # 计算PR-AUC
    pr_auc = average_precision_score(y_true, all_scores)
    
    return {
        'auc': roc_auc,
        'pr_auc': pr_auc,
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1_score': f1,
        'g_mean': gmean,
        'threshold': best_threshold,
        'scores': all_scores,
        'y_pred': y_pred,
        'y_true': y_true
    }

# 主函数
def main():
    # 创建结果目录
    os.makedirs('18HSC', exist_ok=True)
    
    # 加载数据
    print("加载数据...")
    processor = DataProcessor()
    processed_data = processor.load_and_preprocess_data()
    
    X_train, y_train, X_val, y_val, X_test, y_test = processed_data
    
    # ---------- 添加此处：转换为 numpy 数组 ----------
    X_train = np.asarray(X_train)
    y_train = np.asarray(y_train)
    X_val   = np.asarray(X_val)
    y_val   = np.asarray(y_val)
    X_test  = np.asarray(X_test)
    y_test  = np.asarray(y_test)
    
    # 检查数据形状
    print(f"\n数据形状检查:")
    print(f"训练集: X_train={X_train.shape}, y_train={y_train.shape}")
    print(f"验证集: X_val={X_val.shape}, y_val={y_val.shape}")
    print(f"测试集: X_test={X_test.shape}, y_test={y_test.shape}")
    
    # 检查数据分布
    print(f"\n数据分布检查:")
    print(f"训练集异常比例: {np.sum(y_train == 1) / len(y_train):.4f}")
    print(f"验证集异常比例: {np.sum(y_val == 1) / len(y_val):.4f}")
    print(f"测试集异常比例: {np.sum(y_test == 1) / len(y_test):.4f}")
    
    # 关键修改：不重塑数据形状，保持原始形状
    # 假设DataProcessor已经返回了正确的窗口化数据
    # 如果X_train是3D的(batch, window, features)，直接使用
    # 如果X_train是2D的，需要添加滑动窗口
    
    if len(X_train.shape) == 2:
        print("\n警告: 数据是2D的，需要添加滑动窗口...")
        print("论文中使用滑动窗口方法，需要将1D时间序列转换为3D窗口数据")
        print("由于不知道原始时间序列结构，我们将使用简单的窗口化方法")
        
        # 简单的窗口化方法：将连续的时间点分组
        window_size = 10  # 设置一个合理的窗口大小
        stride = 1
        
        def create_windows(data, window_size, stride):
            windows = []
            for i in range(0, len(data) - window_size + 1, stride):
                windows.append(data[i:i+window_size])
            return np.array(windows)
        
        # 创建窗口
        X_train_windows = create_windows(X_train, window_size, stride)
        X_val_windows = create_windows(X_val, window_size, stride)
        X_test_windows = create_windows(X_test, window_size, stride)
        
        # 调整标签（使用窗口最后一个时间点的标签）
        y_train_windows = y_train[window_size-1::stride][:len(X_train_windows)]
        y_val_windows = y_val[window_size-1::stride][:len(X_val_windows)]
        y_test_windows = y_test[window_size-1::stride][:len(X_test_windows)]
        
        X_train, y_train = X_train_windows, y_train_windows
        X_val, y_val = X_val_windows, y_val_windows
        X_test, y_test = X_test_windows, y_test_windows
        
        print(f"窗口化后形状: X_train={X_train.shape}, y_train={y_train.shape}")
        print(f"窗口大小: {window_size}")
    
    # 确保数据是3D的
    if len(X_train.shape) != 3:
        print(f"错误: 期望3D数据，但得到形状: {X_train.shape}")
        print("请确保DataProcessor返回窗口化的3D数据")
        return
    
    # 数据预处理：转换为torch张量
    X_train_tensor = torch.FloatTensor(X_train)
    y_train_tensor = torch.FloatTensor(y_train)
    X_val_tensor = torch.FloatTensor(X_val)
    y_val_tensor = torch.FloatTensor(y_val)
    X_test_tensor = torch.FloatTensor(X_test)
    y_test_tensor = torch.FloatTensor(y_test)
    
    # 创建数据加载器
    batch_size = min(32, len(X_train_tensor))
    train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
    val_dataset = TensorDataset(X_val_tensor, y_val_tensor)
    test_dataset = TensorDataset(X_test_tensor, y_test_tensor)
    
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
    
    # 获取模型参数
    input_size = X_train.shape[2]  # 特征维度
    window_size = X_train.shape[1]  # 窗口大小
    
    print(f"\n初始化HSC模型:")
    print(f"  输入维度: {input_size}")
    print(f"  窗口大小: {window_size}")
    print(f"  隐藏层维度: 64")
    print(f"  注意力头数: 4")
    print(f"  TCN层数: 3")
    print(f"  潜空间维度: 128")
    print(f"  β参数: 0.5")
    print(f"  初始半径R: 1.0")
    
    # 确保hidden_size能被num_heads整除
    hidden_size = 64
    num_heads = 4
    if hidden_size % num_heads != 0:
        hidden_size = num_heads * (hidden_size // num_heads)
        print(f"  调整hidden_size为: {hidden_size}")
    
    model = HSC(
        input_size=input_size,
        window_size=window_size,
        hidden_size=hidden_size,
        num_tcn_layers=3,
        num_heads=num_heads,
        latent_size=128,
        beta=0.5,
        R=1.0
    )
    
    # 训练模型
    print("\n" + "="*50)
    train_losses, val_losses, training_time, model_path = train_hsc_model(
        model, train_loader, val_loader, num_epochs=100, learning_rate=0.001, patience=10
    )
    
    print(f"训练完成，训练时间: {training_time:.2f}秒")
    
    # 开始推理和评估
    print("\n" + "="*50)
    print("开始评估模型...")
    inference_start = time.time()
    
    # 训练集评估
    print("\n训练集评估中...")
    train_results = evaluate_with_threshold(model, train_loader, y_train, set_name="训练集", beta=0.5)
    
    # 验证集评估
    print("验证集评估中...")
    val_results = evaluate_with_threshold(model, val_loader, y_val, set_name="验证集", beta=0.5)
    
    # 测试集评估
    print("测试集评估中...")
    test_results = evaluate_with_threshold(model, test_loader, y_test, set_name="测试集", beta=0.5)
    
    inference_time = time.time() - inference_start
    
    # 计算推理速度
    total_samples = len(y_train) + len(y_val) + len(y_test)
    inference_speed = total_samples / inference_time if inference_time > 0 else 0
    
    # 保存结果到CSV文件
    print("\n" + "="*50)
    print("保存结果...")
    
    # 保存评估结果
    results_data = {
        '数据集': ['训练集', '验证集', '测试集'],
        'auc': [
            round(train_results['auc'], 4),
            round(val_results['auc'], 4),
            round(test_results['auc'], 4)
        ],
        'pr_auc': [
            round(train_results['pr_auc'], 4),
            round(val_results['pr_auc'], 4),
            round(test_results['pr_auc'], 4)
        ],
        'accuracy': [
            round(train_results['accuracy'], 4),
            round(val_results['accuracy'], 4),
            round(test_results['accuracy'], 4)
        ],
        'precision': [
            round(train_results['precision'], 4),
            round(val_results['precision'], 4),
            round(test_results['precision'], 4)
        ],
        'recall': [
            round(train_results['recall'], 4),
            round(val_results['recall'], 4),
            round(test_results['recall'], 4)
        ],
        'f1_score': [
            round(train_results['f1_score'], 4),
            round(val_results['f1_score'], 4),
            round(test_results['f1_score'], 4)
        ],
        'g_mean': [
            round(train_results['g_mean'], 4),
            round(val_results['g_mean'], 4),
            round(test_results['g_mean'], 4)
        ]
    }
    
    results_df = pd.DataFrame(results_data)
    results_df.to_csv('18HSC/results.csv', index=False)
    print("评估结果已保存到 18HSC/results.csv")
    
    # 保存时间信息
    time_data = {
        '指标': ['Training_Time_Seconds', 'Inference_Time_Seconds', 'Inference_Speed_SamplesPerSecond'],
        '值': [
            round(training_time, 4),
            round(inference_time, 4),
            round(inference_speed, 4)
        ]
    }
    
    time_df = pd.DataFrame(time_data)
    time_df.to_csv('18HSC/time.csv', index=False)
    print("时间信息已保存到 18HSC/time.csv")
    
    # 打印摘要结果
    print("\n" + "="*50)
    print("HSC模型评估结果摘要")
    print("="*50)
    
    print(f"\n窗口大小: {window_size}")
    
    print("\n训练集结果:")
    print(f"  AUC: {train_results['auc']:.4f}")
    print(f"  PR-AUC: {train_results['pr_auc']:.4f}")
    print(f"  Accuracy: {train_results['accuracy']:.4f}")
    print(f"  Precision: {train_results['precision']:.4f}")
    print(f"  Recall: {train_results['recall']:.4f}")
    print(f"  F1-Score: {train_results['f1_score']:.4f}")
    print(f"  G-Mean: {train_results['g_mean']:.4f}")
    
    print("\n验证集结果:")
    print(f"  AUC: {val_results['auc']:.4f}")
    print(f"  PR-AUC: {val_results['pr_auc']:.4f}")
    print(f"  Accuracy: {val_results['accuracy']:.4f}")
    print(f"  Precision: {val_results['precision']:.4f}")
    print(f"  Recall: {val_results['recall']:.4f}")
    print(f"  F1-Score: {val_results['f1_score']:.4f}")
    print(f"  G-Mean: {val_results['g_mean']:.4f}")
    
    print("\n测试集结果:")
    print(f"  AUC: {test_results['auc']:.4f}")
    print(f"  PR-AUC: {test_results['pr_auc']:.4f}")
    print(f"  Accuracy: {test_results['accuracy']:.4f}")
    print(f"  Precision: {test_results['precision']:.4f}")
    print(f"  Recall: {test_results['recall']:.4f}")
    print(f"  F1-Score: {test_results['f1_score']:.4f}")
    print(f"  G-Mean: {test_results['g_mean']:.4f}")
    
    print("\n时间性能:")
    print(f"  训练时间: {training_time:.4f}秒")
    print(f"  推理总时间: {inference_time:.4f}秒")
    print(f"  推理速度: {inference_speed:.4f}样本/秒")
    
    print("\n" + "="*50)
    print("所有结果已保存到18HSC目录")
    print(f"模型已保存为: {model_path}")

if __name__ == "__main__":
    main()