import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import os
import time
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, 
    f1_score, roc_auc_score, average_precision_score
)
from sklearn.preprocessing import StandardScaler
import pandas as pd
import warnings
warnings.filterwarnings('ignore')

# 设备设置
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"使用设备: {device}")


# 从提供的模块导入数据处理器
#======================read different dataset===================================#
'''======================================================================================================='''
'''                                           Read dataset                       '''
from ReadFinanceDataSet import DataProcessor 

'''################################## Credit Card #####################'''
#from ReadCreditcardDataset import DataProcessor


'''################################## Network Attack #####################'''
#from ReadCoAtSetDataset import DataProcessor

# ====================== 与论文一致的COUTA实现 ======================

class TemporalModelingNetwork(nn.Module):
    """时间建模网络 - 严格按论文描述: 1层TCN, kernel_size=2"""
    def __init__(self, input_channels, hidden_channels=16):
        super(TemporalModelingNetwork, self).__init__()
        # 论文: 1层隐藏层，kernel_size=2
        self.conv1 = nn.Conv1d(input_channels, hidden_channels, kernel_size=2, padding=1)
        self.leaky_relu = nn.LeakyReLU(0.01)
        
    def forward(self, x):
        # x: (batch, seq_len, features) -> (batch, features, seq_len)
        x = x.transpose(1, 2)
        x = self.leaky_relu(self.conv1(x))
        # 全局平均池化得到特征向量
        x = torch.mean(x, dim=2)
        return x

class ProjectionHead(nn.Module):
    """投影头 - 严格按论文: 2层MLP, LeakyReLU"""
    def __init__(self, input_dim, output_dim=16):
        super(ProjectionHead, self).__init__()
        self.fc1 = nn.Linear(input_dim, output_dim)
        self.leaky_relu = nn.LeakyReLU(0.01)
        self.fc2 = nn.Linear(output_dim, output_dim)
        
    def forward(self, x):
        x = self.leaky_relu(self.fc1(x))
        x = self.fc2(x)
        return x

class ClassificationHead(nn.Module):
    """分类头 - 用于NAC, 严格按论文"""
    def __init__(self, input_dim, output_dim=1):
        super(ClassificationHead, self).__init__()
        self.fc1 = nn.Linear(input_dim, 16)
        self.leaky_relu = nn.LeakyReLU(0.01)
        self.fc2 = nn.Linear(16, output_dim)
        
    def forward(self, x):
        x = self.leaky_relu(self.fc1(x))
        x = self.fc2(x)
        return x

class COUTA(nn.Module):
    """COUTA模型 - 与论文完全一致"""
    def __init__(self, input_channels, seq_len, hidden_dim=16):
        super(COUTA, self).__init__()
        
        self.hidden_dim = hidden_dim
        self.seq_len = seq_len
        
        # 时间建模网络φ
        self.temporal_model = TemporalModelingNetwork(input_channels, hidden_dim)
        
        # 投影头ψ（主输出）和ψ'（旁路输出）
        self.projection_head = ProjectionHead(hidden_dim, hidden_dim)
        self.bypass_projection_head = ProjectionHead(hidden_dim, hidden_dim)
        
        # 分类头ψ_c（用于NAC）
        self.classification_head = ClassificationHead(hidden_dim, 1)
        
        # 超球中心c
        self.center = None
        
        # 初始化权重
        self._initialize_weights()
        
    def _initialize_weights(self):
        """初始化权重 - 使用Kaiming初始化"""
        for m in self.modules():
            if isinstance(m, nn.Conv1d) or isinstance(m, nn.Linear):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='leaky_relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
        
    def forward(self, x, return_bypass=False):
        # 时间建模: φ(s)
        temporal_features = self.temporal_model(x)
        
        # 主投影: ψ(φ(s))
        main_features = self.projection_head(temporal_features)
        
        if return_bypass:
            # 旁路投影: ψ'(φ(s))
            bypass_features = self.bypass_projection_head(temporal_features)
            return main_features, bypass_features, temporal_features
        else:
            return main_features, temporal_features
    
    def calculate_distance(self, x):
        """计算到超球中心的距离: d_s和d̃_s - 公式(6)"""
        if self.center is None:
            raise ValueError("超球中心未初始化")
        
        main_features, bypass_features, _ = self.forward(x, return_bypass=True)
        
        # 计算欧氏距离
        d_main = torch.norm(main_features - self.center, dim=1)
        d_bypass = torch.norm(bypass_features - self.center, dim=1)
        
        # 数值稳定性
        d_main = torch.clamp(d_main, min=1e-8, max=1e8)
        d_bypass = torch.clamp(d_bypass, min=1e-8, max=1e8)
        
        return d_main, d_bypass
    
    def initialize_center(self, dataloader):
        """初始化超球中心 - 使用训练数据的平均值，与论文一致"""
        self.eval()
        all_features = []
        
        with torch.no_grad():
            for batch_x, _ in dataloader:
                batch_x = batch_x.to(device)
                main_features, _, _ = self.forward(batch_x, return_bypass=True)
                all_features.append(main_features.cpu())
        
        all_features = torch.cat(all_features, dim=0)
        self.center = torch.mean(all_features, dim=0).to(device)
        
        # 固定中心，不参与训练
        self.center = self.center.detach()
        self.train()
    
    def generate_native_anomalies(self, x, beta=0.2):
        """生成原生异常示例 - 严格按论文的6种扰动操作"""
        batch_size = x.shape[0]
        n_anomalies = int(batch_size * beta)
        
        if n_anomalies == 0:
            return None
        
        # 随机选择样本
        indices = torch.randperm(batch_size)[:n_anomalies]
        selected_x = x[indices].clone()
        
        # 扰动操作池Ω - 公式(8)
        perturbed_x = []
        
        for i in range(n_anomalies):
            op_idx = np.random.randint(0, 6)
            seq_len = x.shape[1]
            n_features = x.shape[2]
            
            if op_idx == 0:
                # δ(I,+2): 点异常 - 用全局极值2替换
                x_copy = selected_x[i].clone()
                dims = np.random.choice(n_features, size=max(1, n_features//4), replace=False)
                x_copy[-1, dims] = 2.0
                perturbed_x.append(x_copy)
                
            elif op_idx == 1:
                # δ(I,-2): 点异常 - 用全局极值-2替换
                x_copy = selected_x[i].clone()
                dims = np.random.choice(n_features, size=max(1, n_features//4), replace=False)
                x_copy[-1, dims] = -2.0
                perturbed_x.append(x_copy)
                
            elif op_idx == 2:
                # δ(II,+0.5): 上下文异常 - 用均值+0.5替换
                x_copy = selected_x[i].clone()
                dims = np.random.choice(n_features, size=min(10, n_features), replace=False)
                for d in dims:
                    mean_val = torch.mean(x_copy[:-1, d])
                    x_copy[-1, d] = mean_val + 0.5
                perturbed_x.append(x_copy)
                
            elif op_idx == 3:
                # δ(II,-0.5): 上下文异常 - 用均值-0.5替换
                x_copy = selected_x[i].clone()
                dims = np.random.choice(n_features, size=min(10, n_features), replace=False)
                for d in dims:
                    mean_val = torch.mean(x_copy[:-1, d])
                    x_copy[-1, d] = mean_val - 0.5
                perturbed_x.append(x_copy)
                
            elif op_idx == 4:
                # δ(III,0): 集体异常 - 用0替换子序列段
                x_copy = selected_x[i].clone()
                dims = np.random.choice(n_features, size=max(1, n_features//3), replace=False)
                segment_length = np.random.randint(1, max(2, int(seq_len * 0.5)))
                start_idx = seq_len - segment_length
                x_copy[start_idx:, dims] = 0.0
                perturbed_x.append(x_copy)
                
            elif op_idx == 5:
                # δ(III,1): 集体异常 - 用1替换子序列段
                x_copy = selected_x[i].clone()
                dims = np.random.choice(n_features, size=max(1, n_features//3), replace=False)
                segment_length = np.random.randint(1, max(2, int(seq_len * 0.5)))
                start_idx = seq_len - segment_length
                x_copy[start_idx:, dims] = 1.0
                perturbed_x.append(x_copy)
        
        if perturbed_x:
            return torch.stack(perturbed_x, dim=0)
        return None

def calculate_umc_loss(d_main, d_bypass):
    """UMC损失 - 公式(7)"""
    # d_sum = d_s + d̃_s
    d_sum = d_main + d_bypass
    
    # d_diff_sq = (d_s - d̃_s)^2
    d_diff = d_main - d_bypass
    d_diff_sq = d_diff ** 2
    
    # exp(-d_diff_sq)
    exp_term = torch.exp(-torch.clamp(d_diff_sq, max=10.0))
    
    # 损失函数: 0.5 * exp(-d_diff_sq) * d_sum + 0.5 * d_diff_sq
    loss = 0.5 * exp_term * d_sum + 0.5 * d_diff_sq
    
    if torch.any(torch.isnan(loss)):
        loss = torch.nan_to_num(loss, nan=0.0)
    
    return torch.mean(loss)

def calculate_nac_loss(model, x_normal, x_anomaly):
    """NAC损失 - 公式(10)"""
    if x_anomaly is None:
        return torch.tensor(0.0, device=x_normal.device)
    
    # 正常样本的输出
    _, normal_features = model(x_normal, return_bypass=False)
    normal_scores = model.classification_head(normal_features)
    
    # 异常样本的输出
    _, anomaly_features = model(x_anomaly, return_bypass=False)
    anomaly_scores = model.classification_head(anomaly_features)
    
    # 均方误差损失: 正常样本目标为-1，异常样本目标为1
    normal_target = torch.ones_like(normal_scores) * -1
    anomaly_target = torch.ones_like(anomaly_scores) * 1
    
    # MSE损失
    loss_normal = F.mse_loss(normal_scores, normal_target)
    loss_anomaly = F.mse_loss(anomaly_scores, anomaly_target)
    
    return loss_normal + loss_anomaly

# ====================== 数据预处理 ======================

def create_sliding_windows(data, labels, seq_length=100):
    """创建滑动窗口 - 与论文一致"""
    n_samples = data.shape[0]
    n_features = data.shape[1]
    
    if hasattr(labels, 'values'):
        labels = labels.values
    
    if len(labels) != n_samples:
        min_length = min(n_samples, len(labels))
        data = data[:min_length]
        labels = labels[:min_length]
        n_samples = min_length
    
    if n_samples < seq_length:
        padding = np.zeros((seq_length - n_samples, n_features))
        data = np.vstack([data, padding])
        labels = np.concatenate([labels, np.zeros(seq_length - n_samples, dtype=labels.dtype)])
        n_samples = seq_length
    
    n_windows = n_samples - seq_length + 1
    
    windows = np.zeros((n_windows, seq_length, n_features), dtype=np.float32)
    window_labels = np.zeros(n_windows, dtype=np.int32)
    
    for i in range(n_windows):
        windows[i] = data[i:i+seq_length]
        idx = min(i+seq_length-1, len(labels)-1)
        window_labels[i] = labels[idx]
    
    return windows, window_labels

# ====================== 训练函数 ======================

def train_couta(model, train_loader, val_loader, epochs=50, lr=1e-4, alpha=0.1, beta=0.2):
    """训练COUTA - 与论文完全一致"""
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', patience=5, factor=0.5)
    
    patience = 10
    best_val_loss = float('inf')
    patience_counter = 0
    
    train_losses = []
    val_losses = []
    
    print("开始训练COUTA模型...")
    
    for epoch in range(epochs):
        model.train()
        epoch_train_loss = 0
        n_batches = 0
        
        for batch_idx, (batch_x, _) in enumerate(train_loader):
            if batch_x.shape[0] == 1:
                continue
                
            batch_x = batch_x.to(device)
            
            if torch.any(torch.isnan(batch_x)):
                batch_x = torch.nan_to_num(batch_x, nan=0.0)
            
            # 生成原生异常示例
            x_anomaly = model.generate_native_anomalies(batch_x, beta)
            
            # 计算UMC损失
            d_main, d_bypass = model.calculate_distance(batch_x)
            
            if torch.any(torch.isnan(d_main)) or torch.any(torch.isnan(d_bypass)):
                d_main = torch.nan_to_num(d_main, nan=1.0)
                d_bypass = torch.nan_to_num(d_bypass, nan=1.0)
            
            umc_loss = calculate_umc_loss(d_main, d_bypass)
            
            # 计算NAC损失
            nac_loss = calculate_nac_loss(model, batch_x, x_anomaly)
            
            # 总损失: L = L_UMC + αL_NAC
            total_loss = umc_loss + alpha * nac_loss
            
            if torch.isnan(total_loss):
                continue
            
            # 反向传播
            optimizer.zero_grad()
            total_loss.backward()
            
            # 梯度裁剪
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            
            optimizer.step()
            
            epoch_train_loss += total_loss.item()
            n_batches += 1
            
            if batch_idx % 50 == 0:
                print(f"  Epoch {epoch+1}, Batch {batch_idx}, Loss: {total_loss.item():.6f}")
        
        if n_batches == 0:
            avg_train_loss = 0
        else:
            avg_train_loss = epoch_train_loss / n_batches
        train_losses.append(avg_train_loss)
        
        # 验证
        model.eval()
        epoch_val_loss = 0
        n_val_batches = 0
        
        with torch.no_grad():
            for batch_x, _ in val_loader:
                if batch_x.shape[0] == 1:
                    continue
                    
                batch_x = batch_x.to(device)
                
                if torch.any(torch.isnan(batch_x)):
                    batch_x = torch.nan_to_num(batch_x, nan=0.0)
                
                d_main, d_bypass = model.calculate_distance(batch_x)
                
                if torch.any(torch.isnan(d_main)) or torch.any(torch.isnan(d_bypass)):
                    d_main = torch.nan_to_num(d_main, nan=1.0)
                    d_bypass = torch.nan_to_num(d_bypass, nan=1.0)
                
                umc_loss = calculate_umc_loss(d_main, d_bypass)
                
                x_anomaly = model.generate_native_anomalies(batch_x, beta)
                nac_loss = calculate_nac_loss(model, batch_x, x_anomaly)
                
                total_loss = umc_loss + alpha * nac_loss
                
                if not torch.isnan(total_loss):
                    epoch_val_loss += total_loss.item()
                    n_val_batches += 1
        
        if n_val_batches == 0:
            avg_val_loss = float('inf')
        else:
            avg_val_loss = epoch_val_loss / n_val_batches
        val_losses.append(avg_val_loss)
        
        # 更新学习率
        scheduler.step(avg_val_loss)
        
        print(f"Epoch {epoch+1}/{epochs}: Train Loss = {avg_train_loss:.6f}, "
              f"Val Loss = {avg_val_loss:.6f}")
        
        # 早停检查
        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            patience_counter = 0
            torch.save(model, '5COUTA/COUTA.pth')
            print(f"  保存最佳模型")
        else:
            patience_counter += 1
            if patience_counter >= patience:
                print(f"早停触发")
                break
    
    # 加载最佳模型
    if os.path.exists('5COUTA/COUTA.pth'):
        model = torch.load('5COUTA/COUTA.pth', weights_only=False)
    
    return model, train_losses, val_losses

# ====================== 评估函数 ======================

def calculate_metrics(scores, labels):
    """计算所有指标 - 与论文评估方式一致"""
    # 计算AUC-ROC
    if len(np.unique(labels)) > 1:
        try:
            auc_roc = roc_auc_score(labels, scores)
        except:
            auc_roc = 0.5
    else:
        auc_roc = 0.5
    
    # 计算AUC-PR
    try:
        auc_pr = average_precision_score(labels, scores)
    except:
        auc_pr = 0.0
    
    # 计算最佳F1分数对应的阈值
    best_threshold = 0
    best_f1 = 0
    
    # 搜索阈值
    min_score, max_score = np.min(scores), np.max(scores)
    for threshold in np.linspace(min_score, max_score, 100):
        predictions = (scores > threshold).astype(int)
        
        # 检查预测是否只有一种类别
        if len(np.unique(predictions)) < 2:
            continue
            
        f1 = f1_score(labels, predictions, zero_division=0)
        if f1 > best_f1:
            best_f1 = f1
            best_threshold = threshold
    
    # 使用最佳阈值计算所有指标
    predictions = (scores > best_threshold).astype(int)
    
    # 检查预测是否只有一种类别
    if len(np.unique(predictions)) < 2:
        accuracy = 0.0
        precision = 0.0
        recall = 0.0
        f1 = 0.0
    else:
        accuracy = accuracy_score(labels, predictions)
        precision = precision_score(labels, predictions, zero_division=0)
        recall = recall_score(labels, predictions, zero_division=0)
        f1 = f1_score(labels, predictions, zero_division=0)
    
    # 计算G-Mean
    tp = np.sum((labels == 1) & (predictions == 1))
    tn = np.sum((labels == 0) & (predictions == 0))
    fp = np.sum((labels == 0) & (predictions == 1))
    fn = np.sum((labels == 1) & (predictions == 0))
    
    sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
    
    g_mean = np.sqrt(sensitivity * specificity) if (sensitivity > 0 and specificity > 0) else 0
    
    return {
        'auc': float(auc_roc),
        'pr_auc': float(auc_pr),
        'accuracy': float(accuracy),
        'precision': float(precision),
        'recall': float(recall),
        'f1_score': float(f1),
        'g_mean': float(g_mean)
    }

def evaluate_model(model, data_loader):
    """评估模型 - 计算异常分数和指标"""
    model.eval()
    all_scores = []
    all_labels = []
    
    inference_start = time.time()
    
    with torch.no_grad():
        for batch_x, batch_y in data_loader:
            if batch_x.shape[0] == 1:
                continue
                
            batch_x = batch_x.to(device)
            
            if torch.any(torch.isnan(batch_x)):
                batch_x = torch.nan_to_num(batch_x, nan=0.0)
            
            # 计算异常分数: f(s) = d_s + d̃_s - 公式(11)
            d_main, d_bypass = model.calculate_distance(batch_x)
            
            if torch.any(torch.isnan(d_main)) or torch.any(torch.isnan(d_bypass)):
                d_main = torch.nan_to_num(d_main, nan=0.0)
                d_bypass = torch.nan_to_num(d_bypass, nan=0.0)
            
            scores = d_main.cpu().numpy() + d_bypass.cpu().numpy()
            scores = np.nan_to_num(scores, nan=0.0)
            
            all_scores.extend(scores)
            all_labels.extend(batch_y.numpy())
    
    inference_time = time.time() - inference_start
    
    # 计算指标
    metrics = calculate_metrics(np.array(all_scores), np.array(all_labels))
    
    return metrics, inference_time, len(all_scores)

# ====================== 主函数 ======================

def main():
    # 设置随机种子
    torch.manual_seed(42)
    np.random.seed(42)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(42)
    
    # 创建结果目录
    os.makedirs('5COUTA', exist_ok=True)
    
    # 加载数据 - 这里使用模拟数据，您需要替换为实际数据
    print("加载数据...")
    
    # 模拟数据 - 请替换为实际数据
    #n_samples = 5000
    #n_features = 50
    seq_length = 100
    
    # 1. 加载和预处理数据
    print("\n1. 加载和预处理数据...")
    processor = DataProcessor()
    processed_data = processor.load_and_preprocess_data()
    
    if len(processed_data) == 6:
        X_train, y_train, X_val, y_val, X_test, y_test = processed_data
    else:
        print("数据格式不正确，预期6个返回值")
        return
    
    print(f"训练数据形状: {X_train.shape}, 训练标签形状: {y_train.shape}")
    print(f"验证数据形状: {X_val.shape}, 验证标签形状: {y_val.shape}")
    print(f"测试数据形状: {X_test.shape}, 测试标签形状: {y_test.shape}")
    
    # 数据标准化
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_val = scaler.transform(X_val)
    X_test = scaler.transform(X_test)
    
    print(f"训练数据形状: {X_train.shape}")
    print(f"验证数据形状: {X_val.shape}")
    print(f"测试数据形状: {X_test.shape}")
    
    # 创建滑动窗口
    print("创建滑动窗口...")
    X_train_windows, y_train_windows = create_sliding_windows(X_train, y_train, seq_length)
    X_val_windows, y_val_windows = create_sliding_windows(X_val, y_val, seq_length)
    X_test_windows, y_test_windows = create_sliding_windows(X_test, y_test, seq_length)
    
    print(f"训练窗口: {X_train_windows.shape}")
    print(f"验证窗口: {X_val_windows.shape}")
    print(f"测试窗口: {X_test_windows.shape}")
    
    # 转换为PyTorch张量
    X_train_tensor = torch.FloatTensor(X_train_windows)
    y_train_tensor = torch.LongTensor(y_train_windows)
    X_val_tensor = torch.FloatTensor(X_val_windows)
    y_val_tensor = torch.LongTensor(y_val_windows)
    X_test_tensor = torch.FloatTensor(X_test_windows)
    y_test_tensor = torch.LongTensor(y_test_windows)
    
    # 创建数据加载器
    batch_size = 32
    train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
    val_dataset = TensorDataset(X_val_tensor, y_val_tensor)
    test_dataset = TensorDataset(X_test_tensor, y_test_tensor)
    
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, drop_last=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
    center_loader = DataLoader(train_dataset, batch_size=min(32, len(train_dataset)), shuffle=False, drop_last=True)
    
    # 创建模型 - 严格按论文参数
    n_features = X_train_tensor.shape[2]
    hidden_dim = 16  # 论文默认
    
    print("\n模型参数:")
    print(f"输入特征数: {n_features}")
    print(f"序列长度: {seq_length}")
    print(f"隐藏维度: {hidden_dim}")
    print(f"批量大小: {batch_size}")
    
    model = COUTA(input_channels=n_features, seq_len=seq_length, hidden_dim=hidden_dim).to(device)
    
    # 初始化超球中心
    print("\n初始化超球中心...")
    model.initialize_center(center_loader)
    
    # 训练模型
    print("\n开始训练...")
    train_start_time = time.time()
    
    model, train_losses, val_losses = train_couta(
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        epochs=50,
        lr=1e-4,
        alpha=0.1,
        beta=0.2
    )
    
    train_time = time.time() - train_start_time
    
    # 评估模型
    print("\n评估模型...")
    
    # 评估训练集
    train_metrics, train_inference_time, train_samples = evaluate_model(model, train_loader)
    
    # 评估验证集
    val_metrics, val_inference_time, val_samples = evaluate_model(model, val_loader)
    
    # 评估测试集
    test_metrics, test_inference_time, test_samples = evaluate_model(model, test_loader)
    
    # 计算总推理时间
    total_inference_time = train_inference_time + val_inference_time + test_inference_time
    total_samples = train_samples + val_samples + test_samples
    inference_speed = total_samples / total_inference_time if total_inference_time > 0 else 0
    
    # 保存结果到CSV
    print("\n保存结果...")
    
    # 保存指标结果
    results_df = pd.DataFrame({
        'dataset': ['train', 'val', 'test'],
        'auc': [
            round(train_metrics['auc'], 4),
            round(val_metrics['auc'], 4),
            round(test_metrics['auc'], 4)
        ],
        'pr_auc': [
            round(train_metrics['pr_auc'], 4),
            round(val_metrics['pr_auc'], 4),
            round(test_metrics['pr_auc'], 4)
        ],
        'accuracy': [
            round(train_metrics['accuracy'], 4),
            round(val_metrics['accuracy'], 4),
            round(test_metrics['accuracy'], 4)
        ],
        'precision': [
            round(train_metrics['precision'], 4),
            round(val_metrics['precision'], 4),
            round(test_metrics['precision'], 4)
        ],
        'recall': [
            round(train_metrics['recall'], 4),
            round(val_metrics['recall'], 4),
            round(test_metrics['recall'], 4)
        ],
        'f1_score': [
            round(train_metrics['f1_score'], 4),
            round(val_metrics['f1_score'], 4),
            round(test_metrics['f1_score'], 4)
        ],
        'g_mean': [
            round(train_metrics['g_mean'], 4),
            round(val_metrics['g_mean'], 4),
            round(test_metrics['g_mean'], 4)
        ]
    })
    
    results_df.to_csv('5COUTA/results.csv', index=False)
    
    # 保存时间结果
    time_df = pd.DataFrame({
        'metric': ['Training_Time_Seconds', 'Inference_Time_Seconds', 'Inference_Speed_SamplesPerSecond'],
        'value': [
            round(train_time, 4),
            round(total_inference_time, 4),
            round(inference_speed, 4)
        ]
    })
    
    time_df.to_csv('5COUTA/time.csv', index=False)
    
    # 打印结果
    print("\n" + "="*60)
    print("训练结果:")
    print(f"AUC: {train_metrics['auc']:.4f}")
    print(f"PR-AUC: {train_metrics['pr_auc']:.4f}")
    print(f"准确率: {train_metrics['accuracy']:.4f}")
    print(f"精确率: {train_metrics['precision']:.4f}")
    print(f"召回率: {train_metrics['recall']:.4f}")
    print(f"F1分数: {train_metrics['f1_score']:.4f}")
    print(f"G-Mean: {train_metrics['g_mean']:.4f}")
    
    print("\n验证结果:")
    print(f"AUC: {val_metrics['auc']:.4f}")
    print(f"PR-AUC: {val_metrics['pr_auc']:.4f}")
    print(f"准确率: {val_metrics['accuracy']:.4f}")
    print(f"精确率: {val_metrics['precision']:.4f}")
    print(f"召回率: {val_metrics['recall']:.4f}")
    print(f"F1分数: {val_metrics['f1_score']:.4f}")
    print(f"G-Mean: {val_metrics['g_mean']:.4f}")
    
    print("\n测试结果:")
    print(f"AUC: {test_metrics['auc']:.4f}")
    print(f"PR-AUC: {test_metrics['pr_auc']:.4f}")
    print(f"准确率: {test_metrics['accuracy']:.4f}")
    print(f"精确率: {test_metrics['precision']:.4f}")
    print(f"召回率: {test_metrics['recall']:.4f}")
    print(f"F1分数: {test_metrics['f1_score']:.4f}")
    print(f"G-Mean: {test_metrics['g_mean']:.4f}")
    
    print("\n时间统计:")
    print(f"训练时间: {train_time:.4f}秒")
    print(f"推理总时间: {total_inference_time:.4f}秒")
    print(f"推理速度: {inference_speed:.4f}样本/秒")
    
    print("\n结果已保存到:")
    print("1. 5COUTA/results.csv - 指标结果")
    print("2. 5COUTA/time.csv - 时间统计")
    print("3. 5COUTA/COUTA.pth - 训练好的模型")
    
    print("="*60)

if __name__ == "__main__":
    main()