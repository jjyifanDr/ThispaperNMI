# -*- coding: utf-8 -*-
"""
Created on Thu Feb  5 19:06:55 2026

@author: hp
"""

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_curve, auc, precision_recall_curve, average_precision_score
from torch.utils.data import DataLoader, TensorDataset
import time
import os
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

#@dataclass
class TrainingConfig:
    """训练配置参数 - 与论文完全一致"""
    max_epochs: int = 200
    batch_size: int = 50  #200
    learning_rate: float = 0.001
    c_learning_rate: float = 1.0
    c_decay: float = 0.1
    weight_decay: float = 1e-7
    gamma: float = None  # 按论文公式(6)自动计算
    kappa: float = 0.9
    latent_dim: int = 256
    hidden1_size: int = 1024
    hidden2_size: int = 512
    num_gamma_runs: int = 10  # 论文中T=10


class DASVDD(nn.Module):
    """Deep Autoencoding Support Vector Data Descriptor - 与论文完全一致"""
    
    def __init__(self, input_dim: int, config: TrainingConfig):
        super(DASVDD, self).__init__()
        self.config = config
        
        # 论文III-C节：根据数据集调整架构
        if input_dim <= 8:  # PIMA数据集
            hidden1 = 10
            hidden2 = 10
            latent_dim = 4
        else:
            hidden1 = config.hidden1_size
            hidden2 = config.hidden2_size
            latent_dim = config.latent_dim
        
        # 编码器 - 使用论文中的Leaky ReLU激活函数
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden1),
            nn.LeakyReLU(negative_slope=0.01),
            nn.Linear(hidden1, hidden2),
            nn.LeakyReLU(negative_slope=0.01),
            nn.Linear(hidden2, latent_dim),
        )
        
        # 解码器 - 对称结构
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, hidden2),
            nn.LeakyReLU(negative_slope=0.01),
            nn.Linear(hidden2, hidden1),
            nn.LeakyReLU(negative_slope=0.01),
            nn.Linear(hidden1, input_dim),
        )
        
        # 论文III-A节：超球中心c为可训练参数
        self.c = nn.Parameter(torch.randn(latent_dim))
        self.latent_dim = latent_dim
    
    def forward(self, x):
        # 公式(2)：编码和重构
        z = self.encoder(x)
        x_recon = self.decoder(z)
        return z, x_recon, self.c
    
    def compute_anomaly_score(self, x, gamma):
        """计算异常分数 - 公式(2)"""
        z, x_recon, c = self.forward(x)
        
        # 重构误差
        recon_error = torch.sum((x_recon - x) ** 2, dim=1)
        # 到超球中心的距离
        svdd_distance = torch.sum((z - c) ** 2, dim=1)
        # 总异常分数
        anomaly_score = recon_error + gamma * svdd_distance
        
        return anomaly_score, recon_error, svdd_distance, z, x_recon


class DASVDDTrainer:
    """DASVDD训练器 - 实现论文Algorithm 1"""
    
    def __init__(self, config: TrainingConfig, device='cuda' if torch.cuda.is_available() else 'cpu'):
        self.config = config
        self.device = device
        self.model = None
        self.train_losses = []
        self.val_losses = []
        
    def calculate_gamma(self, X_train, num_runs=10):
        """根据论文公式(6)计算gamma值"""
        print("计算gamma值（论文公式6）...")
        
        input_dim = X_train.shape[1]
        gamma_values = []
        
        for t in range(num_runs):
            # 随机初始化模型参数
            temp_model = DASVDD(input_dim, self.config).to(self.device)
            temp_model.apply(self._init_weights)
            temp_model.c.data.zero_()  # 初始化c为0
            
            # 转换为Tensor
            X_tensor = torch.FloatTensor(X_train).to(self.device)
            
            with torch.no_grad():
                # 前向传播
                z = temp_model.encoder(X_tensor)
                x_recon = temp_model.decoder(z)
                
                # 计算重构误差和距离
                recon_error = torch.sum((x_recon - X_tensor) ** 2, dim=1)
                svdd_distance = torch.sum((z - temp_model.c) ** 2, dim=1)
                
                # 计算gamma_t
                gamma_t = torch.mean(recon_error) / (torch.mean(svdd_distance) + 1e-8)
                gamma_values.append(gamma_t.item())
        
        gamma_final = np.mean(gamma_values)
        print(f"计算完成: gamma = {gamma_final:.4f} (T={num_runs}次平均)")
        return gamma_final
    
    def _init_weights(self, m):
        """初始化网络权重"""
        if isinstance(m, nn.Linear):
            nn.init.normal_(m.weight, mean=0, std=0.01)
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)
    
    def train(self, X_train, y_train, X_val, y_val):
        """训练模型 - 实现论文Algorithm 1"""
        start_time = time.time()
        
        # 准备数据
        train_dataset = TensorDataset(
            torch.FloatTensor(X_train),
            torch.LongTensor(y_train)
        )
        train_loader = DataLoader(
            train_dataset,
            batch_size=self.config.batch_size,
            shuffle=True
        )
        
        # 初始化模型
        input_dim = X_train.shape[1]
        self.model = DASVDD(input_dim, self.config).to(self.device)
        
        # 计算gamma（论文III-C节）
        if self.config.gamma is None:
            self.config.gamma = self.calculate_gamma(X_train, self.config.num_gamma_runs)
        
        # 优化器（论文III-B节）
        network_params = list(self.model.encoder.parameters()) + list(self.model.decoder.parameters())
        network_optimizer = optim.Adam(
            network_params,
            lr=self.config.learning_rate,
            weight_decay=self.config.weight_decay
        )
        c_optimizer = optim.Adagrad([self.model.c], lr=self.config.c_learning_rate)
        
        # 训练循环
        print(f"开始训练，共{self.config.max_epochs}个epoch...")
        for epoch in range(self.config.max_epochs):
            self.model.train()
            total_loss = 0
            total_recon_loss = 0
            total_svdd_loss = 0
            
            for batch_idx, (data, _) in enumerate(train_loader):
                data = data.to(self.device)
                batch_size = data.size(0)
                
                # 计算κ比例（论文Algorithm 1）
                kappa_size = int(self.config.kappa * batch_size)
                
                # 第一步：用κ比例的数据训练网络参数
                if kappa_size > 0:
                    network_data = data[:kappa_size]
                    
                    # 前向传播并计算损失
                    anomaly_score, recon_error, svdd_distance, _, _ = self.model.compute_anomaly_score(network_data, self.config.gamma)
                    recon_loss = torch.mean(recon_error)
                    svdd_loss = torch.mean(svdd_distance)
                    loss = recon_loss + self.config.gamma * svdd_loss  # 公式(3)
                    
                    # 反向传播
                    network_optimizer.zero_grad()
                    loss.backward()
                    network_optimizer.step()
                
                # 第二步：用剩余数据训练超球中心c
                if kappa_size < batch_size:
                    c_data = data[kappa_size:]
                    
                    # 仅计算SVDD损失
                    with torch.no_grad():
                        z = self.model.encoder(c_data)
                    
                    svdd_loss_c = torch.mean(torch.sum((z - self.model.c) ** 2, dim=1))
                    
                    # 反向传播更新c
                    c_optimizer.zero_grad()
                    svdd_loss_c.backward()
                    c_optimizer.step()
                
                # 记录损失
                if kappa_size > 0:
                    total_loss += loss.item()
                    total_recon_loss += recon_loss.item()
                    total_svdd_loss += svdd_loss.item()
            
            # 计算平均损失
            avg_loss = total_loss / len(train_loader) if len(train_loader) > 0 else 0
            self.train_losses.append(avg_loss)
            
            # 每50个epoch打印一次进度
            if (epoch + 1) % 50 == 0:
                print(f"Epoch [{epoch+1}/{self.config.max_epochs}], "
                      f"Loss: {avg_loss:.4f}, "
                      f"Recon Loss: {total_recon_loss/len(train_loader):.4f}, "
                      f"SVDD Loss: {total_svdd_loss/len(train_loader):.4f}")
        
        training_time = time.time() - start_time
        print(f"训练完成，耗时: {training_time:.2f}秒")
        
        return training_time
    
    def compute_anomaly_scores(self, X):
        """计算异常分数"""
        self.model.eval()
        dataset = TensorDataset(torch.FloatTensor(X), torch.zeros(len(X)))
        loader = DataLoader(dataset, batch_size=self.config.batch_size, shuffle=False)
        
        all_scores = []
        all_recon_errors = []
        all_svdd_distances = []
        
        with torch.no_grad():
            for data, _ in loader:
                data = data.to(self.device)
                anomaly_score, recon_error, svdd_distance, _, _ = self.model.compute_anomaly_score(data, self.config.gamma)
                all_scores.append(anomaly_score.cpu().numpy())
                all_recon_errors.append(recon_error.cpu().numpy())
                all_svdd_distances.append(svdd_distance.cpu().numpy())
        
        if all_scores:
            scores = np.concatenate(all_scores)
            recon_errors = np.concatenate(all_recon_errors)
            svdd_distances = np.concatenate(all_svdd_distances)
            return scores, recon_errors, svdd_distances
        else:
            return np.array([]), np.array([]), np.array([])
    
    def evaluate(self, X, y_true, dataset_name=""):

            """评估模型性能 - 优化版"""
            start_time = time.time()
            
            # 计算异常分数
            scores, recon_errors, svdd_distances = self.compute_anomaly_scores(X)
            inference_time = time.time() - start_time
            
            if len(scores) == 0:
                return {
                    'auc': 0.0,
                    'pr_auc': 0.0,
                    'accuracy': 0.0,
                    'precision': 0.0,
                    'recall': 0.0,
                    'f1_score': 0.0,
                    'g_mean': 0.0
                }, inference_time, scores
            
            # 计算 ROC AUC
            fpr, tpr, _ = roc_curve(y_true, scores)
            roc_auc = auc(fpr, tpr)
            
            # 计算 PR AUC
            precision_curve, recall_curve, _ = precision_recall_curve(y_true, scores)
            pr_auc = auc(recall_curve, precision_curve)
            
            # 使用 precision_recall_curve 找到最佳阈值（最大化 F1 分数）
            # 注意：precision_curve 和 recall_curve 比 thresholds 多一个元素（最后一个对应全部预测为正）
            precision_curve, recall_curve, thresholds = precision_recall_curve(y_true, scores)
            # 计算每个阈值对应的 F1（忽略最后一个元素，因为其对应的阈值为无穷大）
            f1_scores = 2 * precision_curve[:-1] * recall_curve[:-1] / (precision_curve[:-1] + recall_curve[:-1] + 1e-10)
            best_idx = np.argmax(f1_scores)
            best_threshold = thresholds[best_idx]
            best_f1 = f1_scores[best_idx]
            
            # 使用最佳阈值进行预测
            y_pred = (scores > best_threshold).astype(int)
            
            # 计算所有指标
            accuracy = accuracy_score(y_true, y_pred)
            precision_val = precision_score(y_true, y_pred, zero_division=0)
            recall_val = recall_score(y_true, y_pred, zero_division=0)
            f1 =f1_score(y_true, y_pred, zero_division=0)  
            
            # 计算 G-mean
            tn = np.sum((y_pred == 0) & (y_true == 0))
            fp = np.sum((y_pred == 1) & (y_true == 0))
            tp = np.sum((y_pred == 1) & (y_true == 1))
            fn = np.sum((y_pred == 0) & (y_true == 1))
            
            specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
            sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0
            g_mean = np.sqrt(sensitivity * specificity) if sensitivity * specificity > 0 else 0
            
            metrics = {
                'auc': round(float(roc_auc), 4),
                'pr_auc': round(float(pr_auc), 4),
                'accuracy': round(float(accuracy), 4),
                'precision': round(float(precision_val), 4),
                'recall': round(float(recall_val), 4),
                'f1_score': round(float(f1), 4),
                'g_mean': round(float(g_mean), 4)
            }
            
            if dataset_name:
                print(f"{dataset_name} - AUC: {roc_auc:.4f}, PR-AUC: {pr_auc:.4f}, "
                      f"Accuracy: {accuracy:.4f}, F1: {f1:.4f}")
            
            return metrics, inference_time, scores


def save_results(train_metrics, val_metrics, test_metrics, results_dir):
    """保存结果到CSV文件"""
    results_path = results_dir / "results.csv"
    
    with open(results_path, 'w') as f:
        f.write("dataset,auc,pr_auc,accuracy,precision,recall,f1_score,g_mean\n")
        
        # 训练集结果
        f.write(f"train,{train_metrics['auc']:.4f},{train_metrics['pr_auc']:.4f},"
                f"{train_metrics['accuracy']:.4f},{train_metrics['precision']:.4f},"
                f"{train_metrics['recall']:.4f},{train_metrics['f1_score']:.4f},"
                f"{train_metrics['g_mean']:.4f}\n")
        
        # 验证集结果
        f.write(f"val,{val_metrics['auc']:.4f},{val_metrics['pr_auc']:.4f},"
                f"{val_metrics['accuracy']:.4f},{val_metrics['precision']:.4f},"
                f"{val_metrics['recall']:.4f},{val_metrics['f1_score']:.4f},"
                f"{val_metrics['g_mean']:.4f}\n")
        
        # 测试集结果
        f.write(f"test,{test_metrics['auc']:.4f},{test_metrics['pr_auc']:.4f},"
                f"{test_metrics['accuracy']:.4f},{test_metrics['precision']:.4f},"
                f"{test_metrics['recall']:.4f},{test_metrics['f1_score']:.4f},"
                f"{test_metrics['g_mean']:.4f}\n")
    
    print(f"结果已保存到: {results_path}")


def save_time_info(training_time, total_inference_time, total_samples, results_dir):
    """保存时间信息到CSV文件"""
    time_path = results_dir / "time.csv"
    
    inference_speed = total_samples / total_inference_time if total_inference_time > 0 else 0
    
    with open(time_path, 'w') as f:
        f.write("metric,value\n")
        f.write(f"Training_Time_Seconds,{training_time:.4f}\n")
        f.write(f"Inference_Time_Seconds,{total_inference_time:.4f}\n")
        f.write(f"Inference_Speed_SamplesPerSecond,{inference_speed:.4f}\n")
    
    print(f"时间信息已保存到: {time_path}")


def plot_training_curves(train_losses, save_path):
    """绘制训练损失曲线"""
    plt.figure(figsize=(10, 6))
    plt.plot(train_losses, linewidth=2)
    plt.xlabel('Epoch', fontsize=12)
    plt.ylabel('Loss', fontsize=12)
    plt.title('DASVDD Training Loss', fontsize=14)
    plt.grid(True, alpha=0.3)
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.close()


def main():
    """主函数"""
    import random
    
    # 设置随机种子
    def set_seed(seed=42):
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
    
    set_seed(42)
    
    # 创建结果目录
    results_dir = Path("17DASVDD")
    results_dir.mkdir(exist_ok=True)
    
    print("=" * 60)
    print("DASVDD: Deep Autoencoding Support Vector Data Descriptor")
    print("与论文核心思想完全一致")
    print("=" * 60)
    
    # 加载数据
    print("正在加载数据...")
    '''======================================================================================================='''
    '''                                           Read dataset                       '''
    #from ReadFinanceDataSet import DataProcessor 

    '''################################## Credit Card #####################'''
    #from ReadCreditcardDataset import DataProcessor


    '''################################## Network Attack #####################'''
    from ReadCoAtSetDataset import DataProcessor
    
    
    
    processor = DataProcessor()
    processed_data = processor.load_and_preprocess_data()
    X_train, y_train, X_val, y_val, X_test, y_test = processed_data
    
    print(f"训练集形状: {X_train.shape}, 正常样本: {np.sum(y_train==0)}, 异常样本: {np.sum(y_train==1)}")
    print(f"验证集形状: {X_val.shape}, 正常样本: {np.sum(y_val==0)}, 异常样本: {np.sum(y_val==1)}")
    print(f"测试集形状: {X_test.shape}, 正常样本: {np.sum(y_test==0)}, 异常样本: {np.sum(y_test==1)}")
    
    # 创建配置
    config = TrainingConfig()
    
    # 训练模型
    print("\n开始训练DASVDD模型...")
    trainer = DASVDDTrainer(config)
    training_time = trainer.train(X_train, y_train, X_val, y_val)
    
    # 保存模型
    model_path = results_dir / "DASVDD.pth"
    torch.save(trainer.model.state_dict(), model_path)
    print(f"模型已保存到: {model_path}")
    
    # 评估模型
    print("\n评估模型性能...")
    
    # 训练集评估
    train_metrics, train_inference_time, train_scores = trainer.evaluate(X_train, y_train, "训练集")
    
    # 验证集评估
    val_metrics, val_inference_time, val_scores = trainer.evaluate(X_val, y_val, "验证集")
    
    # 测试集评估
    test_metrics, test_inference_time, test_scores = trainer.evaluate(X_test, y_test, "测试集")
    
    # 计算总推理时间
    total_inference_time = train_inference_time + val_inference_time + test_inference_time
    total_samples = len(X_train) + len(X_val) + len(X_test)
    
    # 保存结果
    save_results(train_metrics, val_metrics, test_metrics, results_dir)
    save_time_info(training_time, total_inference_time, total_samples, results_dir)
    
    # 绘制训练损失曲线
    loss_curve_path = results_dir / "training_loss.png"
    plot_training_curves(trainer.train_losses, loss_curve_path)
    
    # 打印汇总结果
    print("\n" + "=" * 60)
    print("结果汇总:")
    print("=" * 60)
    print(f"训练时间: {training_time:.2f}秒")
    print(f"总推理时间: {total_inference_time:.4f}秒")
    print(f"推理速度: {total_samples/total_inference_time:.2f} 样本/秒")
    print("\n详细指标:")
    
    metrics_names = ['auc', 'pr_auc', 'accuracy', 'precision', 'recall', 'f1_score', 'g_mean']
    print(f"{'数据集':<8} {'AUC':<8} {'PR-AUC':<8} {'Acc':<8} {'Prec':<8} {'Rec':<8} {'F1':<8} {'G-Mean':<8}")
    print("-" * 65)
    
    # 训练集
    train_vals = [f"{train_metrics[m]:.4f}" for m in metrics_names]
    print(f"{'训练集':<8} {train_vals[0]:<8} {train_vals[1]:<8} {train_vals[2]:<8} "
          f"{train_vals[3]:<8} {train_vals[4]:<8} {train_vals[5]:<8} {train_vals[6]:<8}")
    
    # 验证集
    val_vals = [f"{val_metrics[m]:.4f}" for m in metrics_names]
    print(f"{'验证集':<8} {val_vals[0]:<8} {val_vals[1]:<8} {val_vals[2]:<8} "
          f"{val_vals[3]:<8} {val_vals[4]:<8} {val_vals[5]:<8} {val_vals[6]:<8}")
    
    # 测试集
    test_vals = [f"{test_metrics[m]:.4f}" for m in metrics_names]
    print(f"{'测试集':<8} {test_vals[0]:<8} {test_vals[1]:<8} {test_vals[2]:<8} "
          f"{test_vals[3]:<8} {test_vals[4]:<8} {test_vals[5]:<8} {test_vals[6]:<8}")
    
    print("=" * 60)
    print(f"所有结果已保存到: {results_dir}")
    print("=" * 60)


if __name__ == "__main__":
    main()