# DBLS-AE_strict.py
import numpy as np
import pandas as pd
from scipy import fft
import time
import os
import joblib
import warnings
warnings.filterwarnings('ignore')

from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, 
    f1_score, roc_auc_score, average_precision_score,
    confusion_matrix
)
from scipy.stats import gmean

# ==================== 数据读取 ====================
'''======================================================================================================='''
'''                                           Read dataset                       '''
#from ReadFinanceDataSet import DataProcessor 

'''################################## Credit Card #####################'''
from ReadCreditcardDataset import DataProcessor


'''################################## Network Attack #####################'''
#from ReadCoAtSetDataset import DataProcessor

# ==================== 辅助函数 ====================
def create_sliding_windows(time_series, window_size=5, stride=1):
    """创建滑动窗口（与论文完全一致）"""
    if time_series.ndim == 1:
        time_series = time_series.reshape(-1, 1)
    
    n_samples, n_features = time_series.shape
    windows = []
    
    for i in range(0, n_samples - window_size + 1, stride):
        window = time_series[i:i+window_size, :]
        windows.append(window.flatten())
    
    if len(windows) == 0:
        return np.array([]).reshape(0, n_features * window_size)
    return np.array(windows)

def point_adjustment(predictions, labels):
    """点调整策略（与论文完全一致）"""
    adjusted_pred = predictions.copy()
    
    # 找到所有异常段
    anomaly_segments = []
    i = 0
    while i < len(labels):
        if labels[i] == 1:
            start = i
            while i < len(labels) and labels[i] == 1:
                i += 1
            end = i - 1
            anomaly_segments.append((start, end))
        else:
            i += 1
    
    # 对每个异常段，如果有一个点被检测到，则整个段都算检测到
    for start, end in anomaly_segments:
        if np.any(predictions[start:end+1] == 1):
            adjusted_pred[start:end+1] = 1
    
    return adjusted_pred

def calculate_best_f1_threshold(scores, labels):
    """计算最佳F1阈值（与论文完全一致）"""
    # 枚举所有可能的阈值
    unique_scores = np.unique(scores)
    thresholds = np.sort(unique_scores)[::-1]  # 从高到低
    
    best_f1 = 0
    best_threshold = 0
    best_precision = 0
    best_recall = 0
    
    for threshold in thresholds:
        pred = (scores >= threshold).astype(int)
        pred_adjusted = point_adjustment(pred, labels)
        
        # 计算precision和recall
        tp = np.sum((pred_adjusted == 1) & (labels == 1))
        fp = np.sum((pred_adjusted == 1) & (labels == 0))
        fn = np.sum((pred_adjusted == 0) & (labels == 1))
        
        precision = tp / (tp + fp + 1e-10)
        recall = tp / (tp + fn + 1e-10)
        
        # 计算F1分数
        if precision + recall > 0:
            f1 = 2 * precision * recall / (precision + recall)
        else:
            f1 = 0
        
        if f1 > best_f1:
            best_f1 = f1
            best_threshold = threshold
            best_precision = precision
            best_recall = recall
    
    return best_threshold, best_f1, best_precision, best_recall

def calculate_metrics(y_true, y_scores):
    """计算所有评估指标（使用点调整策略）"""
    # 计算最佳阈值和F1
    threshold, f1, precision, recall = calculate_best_f1_threshold(y_scores, y_true)
    
    # 使用最佳阈值进行预测
    y_pred = (y_scores >= threshold).astype(int)
    y_pred_adjusted = point_adjustment(y_pred, y_true)
    
    # 计算其他指标
    accuracy = accuracy_score(y_true, y_pred_adjusted)
    
    # G-mean
    try:
        tn, fp, fn, tp = confusion_matrix(y_true, y_pred_adjusted).ravel()
        sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0
        specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
        g_mean = np.sqrt(sensitivity * specificity) if sensitivity > 0 and specificity > 0 else 0
    except:
        g_mean = 0
    
    # AUC-ROC
    try:
        auc_roc = roc_auc_score(y_true, y_scores)
    except:
        auc_roc = 0.5
    
    # AUC-PR
    try:
        auc_pr = average_precision_score(y_true, y_scores)
    except:
        auc_pr = 0.5
    
    return {
        'threshold': threshold,
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1_score': f1,
        'g_mean': g_mean,
        'auc_roc': auc_roc,
        'auc_pr': auc_pr
    }

# ==================== 序列图像策略 ====================
class SequenceImageStrategy:
    """序列图像策略（与论文完全一致）"""
    
    @staticmethod
    def fft_period(time_series):
        """FFT周期检测（公式6）"""
        if time_series.ndim == 1:
            time_series = time_series.reshape(-1, 1)
        
        n_channels = time_series.shape[1]
        periods = []
        
        for i in range(n_channels):
            channel_data = time_series[:, i]
            
            # 应用FFT
            fft_result = fft.fft(channel_data)
            freqs = fft.fftfreq(len(channel_data))
            
            # 找到主频率（排除零频率）
            magnitude = np.abs(fft_result)
            magnitude[0] = 0  # 排除零频率
            
            if np.max(magnitude) > 0:
                main_freq_idx = np.argmax(magnitude)
                if abs(freqs[main_freq_idx]) > 0:
                    period = int(1 / abs(freqs[main_freq_idx]))
                else:
                    period = 0
            else:
                period = 0
            
            periods.append(period)
        
        return periods
    
    @staticmethod
    def fft_transform(time_series, periods):
        """FFT图像变换（公式7）"""
        if time_series.ndim == 1:
            time_series = time_series.reshape(-1, 1)
        
        n_channels = time_series.shape[1]
        images = []
        
        for i in range(n_channels):
            channel_data = time_series[:, i]
            period = periods[i]
            
            # 如果周期有效（>=20）且数据足够
            if period >= 20 and len(channel_data) >= period:
                # 转换为2D图像
                n_rows = len(channel_data) // period
                if n_rows > 0:
                    # M1图像
                    m1 = channel_data[:n_rows * period].reshape(n_rows, period)
                    
                    # 平均池化得到M2
                    m2 = np.mean(m1, axis=0, keepdims=True)
                    m2 = np.repeat(m2, n_rows, axis=0)
                    
                    # 计算扰动M = M1 - M2
                    m = m1 - m2
                    
                    # M_FFT = M1 + sqrt(|M|)
                    m_fft = m1 + np.sqrt(np.abs(m))
                    
                    # 逆变换回时间序列
                    reconstructed = m_fft.flatten()
                    
                    # 填充到原始长度
                    if len(reconstructed) < len(channel_data):
                        pad_length = len(channel_data) - len(reconstructed)
                        reconstructed = np.pad(reconstructed, (0, pad_length), mode='edge')
                    
                    images.append(reconstructed)
                else:
                    images.append(channel_data)
            else:
                # 周期无效，使用公式10
                avg_pool = np.convolve(channel_data, np.ones(5)/5, mode='same')
                m = channel_data - avg_pool
                reconstructed = channel_data + np.sqrt(np.abs(m))
                images.append(reconstructed)
        
        if len(images) > 1:
            return np.column_stack(images)
        else:
            return images[0].reshape(-1, 1)
    
    @staticmethod
    def apply_spontaneous_perturbation(time_series):
        """数据驱动的自发扰动"""
        periods = SequenceImageStrategy.fft_period(time_series)
        perturbed = SequenceImageStrategy.fft_transform(time_series, periods)
        return perturbed

# ==================== 人工异常生成器 ====================
class ArtificialAnomalyGenerator:
    """人工异常生成器（与论文完全一致）"""
    
    @staticmethod
    def generate_point_anomaly(sequence, dimensions=None):
        """点异常（类型I）"""
        if sequence.ndim == 1:
            sequence = sequence.reshape(-1, 1)
        
        n_dims = sequence.shape[1]
        perturbed = sequence.copy()
        
        if dimensions is None:
            n_perturb = np.random.randint(1, n_dims + 1)
            dimensions = np.random.choice(range(n_dims), n_perturb, replace=False)
        
        for dim in dimensions:
            # 随机选择扰动方向
            direction = np.random.choice([-1, 1])
            # 在±[1.5, 2]范围内随机采样
            xi = np.random.uniform(1.5, 2.0)
            xi = direction * xi
            
            # 用全局极值扰动最后一个时间点
            perturbed[-1, dim] = xi
        
        return perturbed
    
    @staticmethod
    def generate_contextual_anomaly(sequence, dimensions=None, k=5):
        """上下文异常（类型II）"""
        if sequence.ndim == 1:
            sequence = sequence.reshape(-1, 1)
        
        n_dims = sequence.shape[1]
        perturbed = sequence.copy()
        
        if dimensions is None:
            n_perturb = np.random.randint(1, n_dims + 1)
            dimensions = np.random.choice(range(n_dims), n_perturb, replace=False)
        
        for dim in dimensions:
            if len(sequence) > k:
                # 计算前k个时间点的平均值
                context_mean = np.mean(sequence[-k-1:-1, dim])
                # 在[0,1]范围内随机采样偏移
                xi = np.random.uniform(0, 1)
                direction = np.random.choice([-1, 1])
                
                # 应用扰动
                perturbed[-1, dim] = context_mean + direction * xi
        
        return perturbed
    
    @staticmethod
    def generate_collective_anomaly(sequence, dimensions=None, window_len=5):
        """集体异常（类型III）"""
        if sequence.ndim == 1:
            sequence = sequence.reshape(-1, 1)
        
        n_dims = sequence.shape[1]
        perturbed = sequence.copy()
        
        if dimensions is None:
            n_perturb = np.random.randint(1, n_dims + 1)
            dimensions = np.random.choice(range(n_dims), n_perturb, replace=False)
        
        for dim in dimensions:
            # 随机采样段长度（在[1, l/2]范围内）
            segment_len = np.random.randint(1, window_len // 2 + 1)
            
            # 右端是最后一个时间戳
            start_idx = len(sequence) - segment_len
            
            # 用异常值（0或1）替换
            xi = np.random.choice([0, 1])
            perturbed[start_idx:, dim] = xi
        
        return perturbed
    
    @staticmethod
    def generate_reverse_perturbation(sequence, anomaly_type, perturbed_seq, dimensions):
        """反向扰动策略（类型IV-VI）"""
        reversed_seq = sequence.copy()
        
        if anomaly_type == 'point':
            # 类型IV：点异常的反向扰动
            for dim in dimensions:
                perturbation = np.random.uniform(0, 0.2)
                reversed_seq[-1, dim] = sequence[-1, dim] + perturbation
        
        elif anomaly_type == 'contextual':
            # 类型V：上下文异常的反向扰动
            for dim in dimensions:
                # 计算原始值与扰动值的差
                diff = perturbed_seq[-1, dim] - sequence[-1, dim]
                # 应用反向扰动（大小减半）
                reversed_seq[-1, dim] = sequence[-1, dim] - diff / 2
        
        elif anomaly_type == 'collective':
            # 类型VI：集体异常的反向扰动
            for dim in dimensions:
                # 找到扰动的位置
                diff_mask = perturbed_seq[:, dim] != sequence[:, dim]
                if np.any(diff_mask):
                    anomaly_value = perturbed_seq[diff_mask, dim][0]
                    reversed_seq[diff_mask, dim] = 1 - anomaly_value
        
        return reversed_seq

# ==================== DBLS-AE 模型 ====================
class DBLS_AE:
    """Denoising Autoencoder Based on Broad Learning System（与论文完全一致）"""
    
    def __init__(self, n_feature_windows=3, n_feature_nodes=150, 
                 n_enhancement_nodes=800, lambda_reg=0.001, 
                 window_size=5, neg_proportion=0.15):
        """
        初始化DBLS-AE
        
        参数完全按照论文设置：
        - n_feature_windows: 特征窗口数（论文搜索范围1-5）
        - n_feature_nodes: 特征节点数（论文搜索范围50-250）
        - n_enhancement_nodes: 增强节点数（论文搜索范围150-1100）
        - lambda_reg: 岭回归正则化参数
        - window_size: 滑动窗口大小（论文固定为5）
        - neg_proportion: 人工异常比例（论文范围0.1-0.25）
        """
        self.n_feature_windows = n_feature_windows
        self.n_feature_nodes = n_feature_nodes
        self.n_enhancement_nodes = n_enhancement_nodes
        self.lambda_reg = lambda_reg
        self.window_size = window_size
        self.neg_proportion = neg_proportion
        
        # 模型参数
        self.W_map_list = []      # 特征映射权重
        self.β_map_list = []      # 特征映射偏置
        self.W_en = None          # 增强层权重
        self.β_en = None          # 增强层偏置
        self.W = None             # 输出权重
        self.input_dim = None     # 输入维度
    
    def leaky_relu(self, x, alpha=0.01):
        """Leaky ReLU激活函数（论文使用）"""
        return np.where(x > 0, x, alpha * x)
    
    def prepare_training_data(self, T):
        """准备训练数据（与算法1完全一致）"""
        # 1. 数据驱动的自发扰动
        T_FFT = SequenceImageStrategy.apply_spontaneous_perturbation(T)
        
        # 2. 人工异常生成
        n_samples = len(T)
        n_anomalies = int(n_samples * self.neg_proportion)
        
        # 创建人工异常和反向扰动
        T_art = T.copy()
        T_rev = T.copy()
        
        if n_anomalies > 0:
            anomaly_indices = np.random.choice(n_samples, n_anomalies, replace=False)
            
            for idx in anomaly_indices:
                # 选择异常类型
                anomaly_type = np.random.choice(['point', 'contextual', 'collective'])
                
                # 创建序列段
                start_idx = max(0, idx - self.window_size + 1)
                end_idx = min(n_samples, idx + 1)
                segment = T[start_idx:end_idx, :]
                
                if len(segment) < 2:
                    continue
                
                # 随机选择要扰动的维度
                n_dims = segment.shape[1]
                n_perturb = np.random.randint(1, n_dims + 1)
                dimensions = np.random.choice(range(n_dims), n_perturb, replace=False)
                
                # 生成异常
                if anomaly_type == 'point':
                    perturbed = ArtificialAnomalyGenerator.generate_point_anomaly(segment, dimensions)
                    reversed_seg = ArtificialAnomalyGenerator.generate_reverse_perturbation(
                        segment, 'point', perturbed, dimensions)
                
                elif anomaly_type == 'contextual':
                    perturbed = ArtificialAnomalyGenerator.generate_contextual_anomaly(segment, dimensions)
                    reversed_seg = ArtificialAnomalyGenerator.generate_reverse_perturbation(
                        segment, 'contextual', perturbed, dimensions)
                
                else:  # collective
                    perturbed = ArtificialAnomalyGenerator.generate_collective_anomaly(
                        segment, dimensions, self.window_size)
                    reversed_seg = ArtificialAnomalyGenerator.generate_reverse_perturbation(
                        segment, 'collective', perturbed, dimensions)
                
                # 更新数据
                T_art[start_idx:end_idx, :] = perturbed
                T_rev[start_idx:end_idx, :] = reversed_seg
        
        # 3. 拼接并转换为矩阵格式
        # X_noise = F-M(Concatenate(T_FFT, T_art))
        X_noise = np.concatenate([T_FFT, T_art], axis=1)
        X_noise = create_sliding_windows(X_noise, self.window_size, 1)
        
        # X_target = F-M(Concatenate(T, T_rev))
        X_target = np.concatenate([T, T_rev], axis=1)
        X_target = create_sliding_windows(X_target, self.window_size, 1)
        
        return X_noise, X_target
    
    def prepare_test_data(self, T):
        """准备测试数据（与论文完全一致）"""
        # 测试时只使用自发扰动
        T_FFT = SequenceImageStrategy.apply_spontaneous_perturbation(T)
        
        # 为了保持与训练时相同的输入维度，使用自发扰动数据和原始数据拼接
        # 这保持了输入维度的一致性
        X_test = np.concatenate([T_FFT, T], axis=1)
        X_test = create_sliding_windows(X_test, self.window_size, 1)
        
        return X_test
    
    def fit(self, time_series):
        """训练DBLS-AE（与论文完全一致）"""
        # 确保时间序列是2D的
        if time_series.ndim == 1:
            time_series = time_series.reshape(-1, 1)
        
        # 准备训练数据
        X_noise, X_target = self.prepare_training_data(time_series)
        
        if len(X_noise) == 0:
            raise ValueError("没有足够的数据创建滑动窗口。请增加时间序列长度或减小窗口大小。")
        
        n_samples, input_dim = X_noise.shape
        self.input_dim = input_dim
        
        # 1. 特征映射（公式1）
        self.W_map_list = []
        self.β_map_list = []
        feature_nodes = []
        
        for i in range(self.n_feature_windows):
            # 随机生成权重
            W_map = np.random.randn(input_dim, self.n_feature_nodes) * 0.1
            β_map = np.random.randn(self.n_feature_nodes) * 0.1
            
            # 计算特征节点
            Z_i = np.dot(X_noise, W_map) + β_map
            feature_nodes.append(Z_i)
            
            self.W_map_list.append(W_map)
            self.β_map_list.append(β_map)
        
        # 连接所有特征节点
        Z = np.concatenate(feature_nodes, axis=1)  # 形状: (N, n*e)
        
        # 2. 增强层（公式2）
        total_feature_nodes = self.n_feature_windows * self.n_feature_nodes
        self.W_en = np.random.randn(total_feature_nodes, self.n_enhancement_nodes) * 0.1
        self.β_en = np.random.randn(self.n_enhancement_nodes) * 0.1
        
        H = np.dot(Z, self.W_en) + self.β_en
        H = self.leaky_relu(H)  # 使用Leaky ReLU
        
        # 3. 中间隐藏层（公式3）
        A = np.concatenate([Z, H], axis=1)  # 形状: (N, n*e + r)
        
        # 4. 权重计算（公式5）
        I = np.eye(A.shape[1])
        ATA = np.dot(A.T, A)
        
        try:
            # 尝试直接求逆
            inverse_term = np.linalg.inv(ATA + self.lambda_reg * I)
            self.W = np.dot(np.dot(inverse_term, A.T), X_target)
        except np.linalg.LinAlgError:
            # 如果不可逆，使用SVD
            U, S, Vt = np.linalg.svd(A, full_matrices=False)
            S_inv = np.diag(S / (S**2 + self.lambda_reg))
            self.W = np.dot(np.dot(Vt.T, np.dot(S_inv, U.T)), X_target)
        
        # 计算训练损失
        predictions = np.dot(A, self.W)
        reconstruction_error = np.mean((predictions - X_target) ** 2)
        regularization = self.lambda_reg * np.sum(self.W ** 2)
        self.training_loss = reconstruction_error + regularization
        
        return self
    
    def predict_anomaly_scores(self, time_series):
        """预测异常分数（与论文完全一致）"""
        # 确保时间序列是2D的
        if time_series.ndim == 1:
            time_series = time_series.reshape(-1, 1)
        
        # 准备测试数据
        X_test = self.prepare_test_data(time_series)
        
        if len(X_test) == 0:
            return np.zeros(len(time_series))
        
        # 检查维度是否匹配
        if X_test.shape[1] != self.input_dim:
            raise ValueError(f"输入维度不匹配！训练时维度: {self.input_dim}, 预测时维度: {X_test.shape[1]}")
        
        # 前向传播
        feature_nodes = []
        for i in range(self.n_feature_windows):
            Z_i = np.dot(X_test, self.W_map_list[i]) + self.β_map_list[i]
            feature_nodes.append(Z_i)
        
        Z = np.concatenate(feature_nodes, axis=1)
        H = np.dot(Z, self.W_en) + self.β_en
        H = self.leaky_relu(H)
        A = np.concatenate([Z, H], axis=1)
        
        # 重构
        X_reconstructed = np.dot(A, self.W)
        
        # 计算重构误差（公式19）
        reconstruction_error = np.mean((X_test - X_reconstructed) ** 2, axis=1)
        
        # 转换为每个时间点的异常分数
        anomaly_scores = np.zeros(len(time_series))
        
        # 将窗口的异常分数分配给最后一个时间点
        for i, score in enumerate(reconstruction_error):
            idx = min(i + self.window_size - 1, len(anomaly_scores) - 1)
            anomaly_scores[idx] = score
        
        # 填充前几个时间点
        if len(anomaly_scores) > self.window_size:
            for i in range(self.window_size - 1):
                anomaly_scores[i] = anomaly_scores[self.window_size - 1]
        
        return anomaly_scores
    
    def save_model(self, filepath):
        """保存模型"""
        model_data = {
            'n_feature_windows': self.n_feature_windows,
            'n_feature_nodes': self.n_feature_nodes,
            'n_enhancement_nodes': self.n_enhancement_nodes,
            'lambda_reg': self.lambda_reg,
            'window_size': self.window_size,
            'neg_proportion': self.neg_proportion,
            'W_map_list': self.W_map_list,
            'β_map_list': self.β_map_list,
            'W_en': self.W_en,
            'β_en': self.β_en,
            'W': self.W,
            'input_dim': self.input_dim,
            'training_loss': self.training_loss
        }
        joblib.dump(model_data, filepath)
    
    def load_model(self, filepath):
        """加载模型"""
        model_data = joblib.load(filepath)
        
        self.n_feature_windows = model_data['n_feature_windows']
        self.n_feature_nodes = model_data['n_feature_nodes']
        self.n_enhancement_nodes = model_data['n_enhancement_nodes']
        self.lambda_reg = model_data['lambda_reg']
        self.window_size = model_data['window_size']
        self.neg_proportion = model_data['neg_proportion']
        self.W_map_list = model_data['W_map_list']
        self.β_map_list = model_data['β_map_list']
        self.W_en = model_data['W_en']
        self.β_en = model_data['β_en']
        self.W = model_data['W']
        self.input_dim = model_data['input_dim']
        self.training_loss = model_data.get('training_loss', 0)

# ==================== 主程序 ====================
def main():
    """主函数 - 严格按照论文思想实现"""
    
    # 设置随机种子
    np.random.seed(42)
    
    # 创建保存目录
    save_dir = '14DBLS-AE'
    os.makedirs(save_dir, exist_ok=True)
    
    print("DBLS-AE模型训练和评估（严格按照论文思想实现）")
    print("=" * 60)
    
    # 1. 使用真实金融数据集
    print("\n1. 读取真实金融数据...")
    try:
        processor = DataProcessor()
        processed_data = processor.load_and_preprocess_data()
        
        # 解包数据
        X_train, y_train, X_val, y_val, X_test, y_test = processed_data
        
        # 强制转换为 numpy 数组（关键！）
        X_train = np.asarray(X_train)
        y_train = np.asarray(y_train)
        X_val   = np.asarray(X_val)
        y_val   = np.asarray(y_val)
        X_test  = np.asarray(X_test)
        y_test  = np.asarray(y_test)
        
        print(f"训练数据: X_train={X_train.shape}, y_train={y_train.shape}")
        print(f"验证数据: X_val={X_val.shape}, y_val={y_val.shape}")
        print(f"测试数据: X_test={X_test.shape}, y_test={y_test.shape}")
        
        # 检查数据形状并调整
        # 假设X_train是三维的 (样本数, 时间步长, 特征数) 或二维的 (时间步长, 特征数)
        if len(X_train.shape) == 3:
            # 三维数据：需要转换为二维（时间步长, 特征数）
            # 假设每个样本是独立的，我们将所有样本拼接成一个长序列
           # original_train_shape = X_train.shape
            
            X_train = X_train.reshape(-1, X_train.shape[-1])
            y_train = y_train.flatten()
            
            X_val = X_val.reshape(-1, X_val.shape[-1])
            y_val = y_val.flatten()
            
            X_test = X_test.reshape(-1, X_test.shape[-1])
            y_test = y_test.flatten()
            
            print(f"重塑后训练数据: X_train={X_train.shape}, y_train={y_train.shape}")
            print(f"重塑后验证数据: X_val={X_val.shape}, y_val={y_val.shape}")
            print(f"重塑后测试数据: X_test={X_test.shape}, y_test={y_test.shape}")
            
    except Exception as e:
        print(f"数据读取错误: {e}")
        print("程序终止。")
        return None, None, None, None
    
    # 2. 训练模型
    print("\n2. 训练DBLS-AE模型...")
    
    # 按照论文参数设置
    model = DBLS_AE(
        n_feature_windows=3,          # 论文默认
        n_feature_nodes=150,          # 论文范围50-250
        n_enhancement_nodes=800,      # 论文范围150-1100
        lambda_reg=0.001,             # 岭回归正则化参数
        window_size=5,                # 论文固定为5
        neg_proportion=0.15           # 论文范围0.1-0.25
    )
    
    # 训练模型并计时
    train_start_time = time.time()
    model.fit(X_train)
    training_time = time.time() - train_start_time
    
    print(f"训练完成，训练时间: {training_time:.4f}秒")
    
    # 3. 预测和评估
    print("\n3. 预测和评估...")
    
    # 训练集预测和评估
    print("训练集评估...")
    train_pred_start_time = time.time()
    train_scores = model.predict_anomaly_scores(X_train)
    train_inference_time = time.time() - train_pred_start_time
    
    train_metrics = calculate_metrics(y_train, train_scores)
    
    # 验证集预测和评估
    print("验证集评估...")
    val_pred_start_time = time.time()
    val_scores = model.predict_anomaly_scores(X_val)
    val_inference_time = time.time() - val_pred_start_time
    
    val_metrics = calculate_metrics(y_val, val_scores)
    
    # 测试集预测和评估
    print("测试集评估...")
    test_pred_start_time = time.time()
    test_scores = model.predict_anomaly_scores(X_test)
    test_inference_time = time.time() - test_pred_start_time
    
    test_metrics = calculate_metrics(y_test, test_scores)
    
    # 计算总推理时间
    total_inference_time = train_inference_time + val_inference_time + test_inference_time
    
    # 计算推理速度（样本/秒）
    total_samples = len(X_train) + len(X_val) + len(X_test)
    inference_speed = total_samples / total_inference_time if total_inference_time > 0 else 0
    
    # 4. 保存结果
    print("\n4. 保存结果...")
    
    # 保存模型
    model_path = os.path.join(save_dir, 'DBLS-AE.pth')
    model.save_model(model_path)
    print(f"模型已保存到: {model_path}")
    
    # 保存评估结果到CSV
    results_data = {
        'Dataset': ['Training', 'Validation', 'Testing'],
        'auc': [
            f"{train_metrics['auc_roc']:.4f}",
            f"{val_metrics['auc_roc']:.4f}",
            f"{test_metrics['auc_roc']:.4f}"
        ],
        'pr_auc': [
            f"{train_metrics['auc_pr']:.4f}",
            f"{val_metrics['auc_pr']:.4f}",
            f"{test_metrics['auc_pr']:.4f}"
        ],
        'accuracy': [
            f"{train_metrics['accuracy']:.4f}",
            f"{val_metrics['accuracy']:.4f}",
            f"{test_metrics['accuracy']:.4f}"
        ],
        'precision': [
            f"{train_metrics['precision']:.4f}",
            f"{val_metrics['precision']:.4f}",
            f"{test_metrics['precision']:.4f}"
        ],
        'recall': [
            f"{train_metrics['recall']:.4f}",
            f"{val_metrics['recall']:.4f}",
            f"{test_metrics['recall']:.4f}"
        ],
        'f1_score': [
            f"{train_metrics['f1_score']:.4f}",
            f"{val_metrics['f1_score']:.4f}",
            f"{test_metrics['f1_score']:.4f}"
        ],
        'g_mean': [
            f"{train_metrics['g_mean']:.4f}",
            f"{val_metrics['g_mean']:.4f}",
            f"{test_metrics['g_mean']:.4f}"
        ]
    }
    
    results_df = pd.DataFrame(results_data)
    results_path = os.path.join(save_dir, 'results.csv')
    results_df.to_csv(results_path, index=False)
    print(f"评估结果已保存到: {results_path}")
    
    # 保存时间性能到CSV
    time_data = {
        'Metric': ['Training_Time_Seconds', 'Inference_Time_Seconds', 'Inference_Speed_SamplesPerSecond'],
        'Value': [
            f"{training_time:.4f}",
            f"{total_inference_time:.4f}",
            f"{inference_speed:.4f}"
        ]
    }
    
    time_df = pd.DataFrame(time_data)
    time_path = os.path.join(save_dir, 'time.csv')
    time_df.to_csv(time_path, index=False)
    print(f"时间性能已保存到: {time_path}")
    
    # 5. 打印结果摘要
    print("\n5. 结果摘要:")
    print("=" * 60)
    print("训练集指标:")
    print(f"  AUC-ROC:   {train_metrics['auc_roc']:.4f}")
    print(f"  AUC-PR:    {train_metrics['auc_pr']:.4f}")
    print(f"  Accuracy:  {train_metrics['accuracy']:.4f}")
    print(f"  Precision: {train_metrics['precision']:.4f}")
    print(f"  Recall:    {train_metrics['recall']:.4f}")
    print(f"  F1-Score:  {train_metrics['f1_score']:.4f}")
    print(f"  G-Mean:    {train_metrics['g_mean']:.4f}")
    print(f"  阈值:      {train_metrics['threshold']:.4f}")
    
    print("\n验证集指标:")
    print(f"  AUC-ROC:   {val_metrics['auc_roc']:.4f}")
    print(f"  AUC-PR:    {val_metrics['auc_pr']:.4f}")
    print(f"  Accuracy:  {val_metrics['accuracy']:.4f}")
    print(f"  Precision: {val_metrics['precision']:.4f}")
    print(f"  Recall:    {val_metrics['recall']:.4f}")
    print(f"  F1-Score:  {val_metrics['f1_score']:.4f}")
    print(f"  G-Mean:    {val_metrics['g_mean']:.4f}")
    print(f"  阈值:      {val_metrics['threshold']:.4f}")
    
    print("\n测试集指标:")
    print(f"  AUC-ROC:   {test_metrics['auc_roc']:.4f}")
    print(f"  AUC-PR:    {test_metrics['auc_pr']:.4f}")
    print(f"  Accuracy:  {test_metrics['accuracy']:.4f}")
    print(f"  Precision: {test_metrics['precision']:.4f}")
    print(f"  Recall:    {test_metrics['recall']:.4f}")
    print(f"  F1-Score:  {test_metrics['f1_score']:.4f}")
    print(f"  G-Mean:    {test_metrics['g_mean']:.4f}")
    print(f"  阈值:      {test_metrics['threshold']:.4f}")
    
    print("\n时间性能:")
    print(f"  训练时间: {training_time:.4f}秒")
    print(f"  总推理时间: {total_inference_time:.4f}秒")
    print(f"  推理速度: {inference_speed:.4f}样本/秒")
    print("=" * 60)
    
    return model, train_metrics, val_metrics, test_metrics

if __name__ == "__main__":
    # 运行主程序
    model, train_metrics, val_metrics, test_metrics = main()