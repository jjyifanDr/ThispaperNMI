import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import pandas as pd
import os
import time
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, average_precision_score
import warnings
warnings.filterwarnings('ignore')

# ==================== 工具函数 ====================
def g_mean_score(y_true, y_pred):
    """计算G-Mean指标"""
    tn = np.sum((y_pred == 0) & (y_true == 0))
    fp = np.sum((y_pred == 1) & (y_true == 0))
    fn = np.sum((y_pred == 0) & (y_true == 1))
    tp = np.sum((y_pred == 1) & (y_true == 1))
    
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
    sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0
    
    return np.sqrt(specificity * sensitivity) if specificity > 0 and sensitivity > 0 else 0

def compute_threshold_by_percentile(scores, c_percent):
    """根据论文方法计算阈值：使c_percent比例的数据被标记为异常"""
    if len(scores) == 0:
        return 0.5
    scores_clean = scores[~np.isnan(scores)]
    if len(scores_clean) == 0:
        return 0.5
    threshold = np.percentile(scores_clean, 100 - c_percent)
    return threshold

# ==================== DADN模型（严格遵循论文） ====================
class TimeSeriesEmbedding(nn.Module):
    def __init__(self, input_dim, d_model, max_len=100):
        super(TimeSeriesEmbedding, self).__init__()
        self.d_model = d_model
        self.conv = nn.Conv1d(in_channels=input_dim, out_channels=d_model, kernel_size=1, padding=0)
        self.position_encoding = PositionalEncoding(d_model, max_len)
        
        nn.init.xavier_uniform_(self.conv.weight)
        nn.init.zeros_(self.conv.bias)
    
    def forward(self, x):
        batch_size, seq_len, input_dim = x.shape
        x_conv = x.transpose(1, 2)
        te_output = self.conv(x_conv)
        te_output = te_output.transpose(1, 2)
        pe_output = self.position_encoding(te_output)
        z0 = te_output + pe_output
        return z0

class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=100):
        super(PositionalEncoding, self).__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-np.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)
    
    def forward(self, x):
        return self.pe[:, :x.size(1), :]

class AnomalyAttention(nn.Module):
    def __init__(self, d_model, n_heads):
        super(AnomalyAttention, self).__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads
        
        self.W_Q = nn.Linear(d_model, d_model)
        self.W_K = nn.Linear(d_model, d_model)
        self.W_V = nn.Linear(d_model, d_model)
        self.W_sigma = nn.Linear(d_model, d_model)
        self.layer_norm = nn.LayerNorm(d_model)
        
        for module in [self.W_Q, self.W_K, self.W_V, self.W_sigma]:
            nn.init.xavier_uniform_(module.weight)
            nn.init.zeros_(module.bias)
    
    def forward(self, z):
        batch_size, seq_len, _ = z.shape
        
        Q = self.W_Q(z)
        K = self.W_K(z)
        V = self.W_V(z)
        sigma = self.W_sigma(z)
        
        Q = Q.view(batch_size, seq_len, self.n_heads, self.head_dim).transpose(1, 2)
        K = K.view(batch_size, seq_len, self.n_heads, self.head_dim).transpose(1, 2)
        V = V.view(batch_size, seq_len, self.n_heads, self.head_dim).transpose(1, 2)
        sigma = sigma.view(batch_size, seq_len, self.n_heads, self.head_dim).transpose(1, 2)
        
        sigma = sigma[:, :, :, 0].unsqueeze(-1)
        sigma = F.softplus(sigma) + 1e-6
        
        i = torch.arange(seq_len, device=z.device).float().view(1, 1, -1, 1)
        j = torch.arange(seq_len, device=z.device).float().view(1, 1, 1, -1)
        dist = (i - j).pow(2)
        
        sqrt_two_pi = torch.sqrt(torch.tensor(2 * np.pi, device=z.device))
        prior = torch.exp(-dist / (2 * sigma.pow(2))) / (sqrt_two_pi * sigma + 1e-8)
        prior = prior / (prior.sum(dim=-1, keepdim=True) + 1e-8)
        
        attention_scores = torch.matmul(Q, K.transpose(-2, -1)) / (self.head_dim ** 0.5)
        series = F.softmax(attention_scores, dim=-1)
        
        attention_output = torch.matmul(series, V)
        attention_output = attention_output.transpose(1, 2).contiguous()
        attention_output = attention_output.view(batch_size, seq_len, self.d_model)
        
        output = self.layer_norm(attention_output + z)
        return output, prior, series

class AnomalyAttentionBlock(nn.Module):
    def __init__(self, d_model, n_heads):
        super(AnomalyAttentionBlock, self).__init__()
        self.attention = AnomalyAttention(d_model, n_heads)
        self.feed_forward = nn.Sequential(
            nn.Linear(d_model, d_model * 4),
            nn.ReLU(),
            nn.Linear(d_model * 4, d_model)
        )
        self.norm = nn.LayerNorm(d_model)
        
        for layer in self.feed_forward:
            if isinstance(layer, nn.Linear):
                nn.init.xavier_uniform_(layer.weight)
                nn.init.zeros_(layer.bias)
    
    def forward(self, z):
        attn_output, prior, series = self.attention(z)
        ff_output = self.feed_forward(attn_output)
        output = self.norm(attn_output + ff_output)
        return output, prior, series

class DADN(nn.Module):
    def __init__(self, input_dim, window_size=100, d_model=128, n_heads=4, n_layers=3):
        super(DADN, self).__init__()
        if d_model % n_heads != 0:
            d_model = (d_model // n_heads) * n_heads
        
        self.input_dim = input_dim
        self.window_size = window_size
        self.d_model = d_model
        self.n_heads = n_heads
        self.n_layers = n_layers
        
        self.embedding = TimeSeriesEmbedding(input_dim, d_model, window_size)
        self.blocks = nn.ModuleList([AnomalyAttentionBlock(d_model, n_heads) for _ in range(n_layers)])
        self.decoders = nn.ModuleList([nn.Linear(d_model, input_dim) for _ in range(n_layers)])
        
        for decoder in self.decoders:
            nn.init.xavier_uniform_(decoder.weight)
            nn.init.zeros_(decoder.bias)
        
        self.register_buffer('alpha', torch.tensor([0.1, 0.15]))
        self.register_buffer('beta', torch.tensor([0.9, 0.85]))
        self.r_history = [[], []]  # 每层的历史异常比例
    
    def forward(self, x, layer_idx=None):
        z = self.embedding(x)
        
        outputs = []
        priors = []
        series = []
        reconstructions = []
        
        if layer_idx is not None:
            max_layer = min(layer_idx + 1, self.n_layers)
        else:
            max_layer = self.n_layers
        
        for l in range(max_layer):
            z, prior, series_attn = self.blocks[l](z)
            outputs.append(z)
            priors.append(prior)
            series.append(series_attn)
            recon = self.decoders[l](z)
            reconstructions.append(recon)
        
        return {'outputs': outputs, 'priors': priors, 'series': series, 'reconstructions': reconstructions}
    
    def compute_association_discrepancy(self, prior, series):
        batch_size, n_heads, seq_len, _ = prior.shape
        prior_stable = prior + 1e-10
        series_stable = series + 1e-10
        
        prior_stable = prior_stable / (prior_stable.sum(dim=-1, keepdim=True) + 1e-10)
        series_stable = series_stable / (series_stable.sum(dim=-1, keepdim=True) + 1e-10)
        
        kl1 = F.kl_div(torch.log(series_stable), prior_stable, reduction='none').sum(dim=-1)
        kl2 = F.kl_div(torch.log(prior_stable), series_stable, reduction='none').sum(dim=-1)
        
        ass_dis = (kl1 + kl2).mean(dim=[1, 2])
        return ass_dis
    
    def compute_anomaly_score(self, x, reconstruction, prior, series):
        rec_dis = torch.norm(x - reconstruction, dim=2)
        ass_dis = self.compute_association_discrepancy(prior, series)
        
        anomaly_score = F.softmax(-ass_dis.unsqueeze(1), dim=1) * rec_dis
        return anomaly_score
    
    def compute_feature_disentanglement_loss(self, features):
        if features is None or len(features) == 0:
            return torch.tensor(0.0, device=features[0].device if features else 'cpu')
        
        total_loss = 0.0
        for feat in features:
            batch_size, seq_len, d_model = feat.shape
            feat_flat = feat.reshape(-1, d_model)
            
            feat_mean = feat_flat.mean(dim=0, keepdim=True)
            feat_centered = feat_flat - feat_mean
            cov_matrix = torch.mm(feat_centered.t(), feat_centered) / (feat_centered.shape[0] - 1 + 1e-8)
            
            std = torch.sqrt(torch.diag(cov_matrix) + 1e-8)
            std_matrix = std.unsqueeze(0) * std.unsqueeze(1)
            corr_matrix = cov_matrix / (std_matrix + 1e-8)
            
            mask = torch.triu(torch.ones_like(corr_matrix), diagonal=1).bool()
            corr_values = corr_matrix[mask]
            
            if len(corr_values) > 0:
                loss = corr_values.pow(2).mean()
                total_loss += loss
        
        return total_loss / len(features)
    
    def update_bilateral_borders(self, t=10, p_alpha=[0.1, 0.15], p_beta=[0.9, 0.85]):
        """更新双边边界 - 论文公式12"""
        for l in range(self.n_layers - 1):
            if len(self.r_history[l]) >= t:
                recent_r = self.r_history[l][-t:]
                z_p_alpha = np.percentile(recent_r, p_alpha[l] * 100)
                z_p_beta = np.percentile(recent_r, p_beta[l] * 100)
                
                alpha_new = self.alpha[l] + (z_p_alpha - self.alpha[l]) / t
                beta_new = self.beta[l] + (z_p_beta - self.beta[l]) / t
                
                self.alpha[l] = torch.tensor(alpha_new, device=self.alpha.device)
                self.beta[l] = torch.tensor(beta_new, device=self.beta.device)
    
    def dynamic_inference(self, x, update_borders=True):
        batch_size = x.shape[0]
        device = x.device
        
        exit_layers = torch.zeros(batch_size, dtype=torch.long, device=device)
        final_scores = torch.zeros(batch_size, self.window_size, device=device)
        
        z = self.embedding(x)
        for l in range(self.n_layers):
            z, prior, series_attn = self.blocks[l](z)
            recon = self.decoders[l](z)
            
            anomaly_score = self.compute_anomaly_score(x, recon, prior, series_attn)
            
            if l < 2:
                threshold = 0.5
                anomalies = (anomaly_score > threshold).float()
                r_l = anomalies.mean(dim=1).cpu().numpy()
                
                for b in range(batch_size):
                    if exit_layers[b] == 0:
                        if r_l[b] < self.alpha[l] or r_l[b] > self.beta[l]:
                            exit_layers[b] = l + 1
                            final_scores[b] = anomaly_score[b]
                
                self.r_history[l].extend(r_l.tolist())
            
            for b in range(batch_size):
                if exit_layers[b] == 0:
                    final_scores[b] = anomaly_score[b]
        
        for b in range(batch_size):
            if exit_layers[b] == 0:
                exit_layers[b] = self.n_layers
        
        if update_borders:
            self.update_bilateral_borders()
        
        return final_scores, exit_layers

# ==================== 训练器 ====================
class DADNTrainer:
    def __init__(self, model, input_dim, window_size=100, device='cuda' if torch.cuda.is_available() else 'cpu'):
        self.model = model.to(device)
        self.device = device
        self.window_size = window_size
        self.input_dim = input_dim
        
        self.learning_rate = 1e-4
        self.batch_size = 32
        self.num_epochs = 50
        self.lambda_param = 3.0
        
        self.patience = 10
        self.min_delta = 0.001
        
        os.makedirs('9DADN', exist_ok=True)
    
    def create_windows_nonoverlap(self, data, labels=None):
        num_samples = len(data)
        num_windows = num_samples // self.window_size
        
        if num_windows == 0:
            return np.array([]), np.array([]) if labels is not None else np.array([])
        
        windows = []
        window_labels = []
        
        for i in range(num_windows):
            start_idx = i * self.window_size
            end_idx = start_idx + self.window_size
            window = data[start_idx:end_idx]
            windows.append(window)
            
            if labels is not None:
                window_label = labels[start_idx:end_idx]
                window_labels.append(window_label)
        
        windows = np.array(windows)
        if labels is not None:
            window_labels = np.array(window_labels)
            return windows, window_labels
        
        return windows
    
    def train_layerwise(self, X_train, y_train, X_val, y_val):
        X_train_windows = self.create_windows_nonoverlap(X_train)
        y_train_windows = self.create_windows_nonoverlap(y_train) if y_train is not None else None
        
        X_val_windows = self.create_windows_nonoverlap(X_val)
        y_val_windows = self.create_windows_nonoverlap(y_val) if y_val is not None else None
        
        if len(X_train_windows) == 0 or len(X_val_windows) == 0:
            raise ValueError("数据不足以创建窗口")
        
        X_train_tensor = torch.FloatTensor(X_train_windows).to(self.device)
        X_val_tensor = torch.FloatTensor(X_val_windows).to(self.device)
        
        for layer_idx in range(self.model.n_layers):
            layer_params = list(self.model.blocks[layer_idx].parameters()) + \
                          list(self.model.decoders[layer_idx].parameters())
            
            if layer_idx == 0:
                layer_params += list(self.model.embedding.parameters())
            
            optimizer = torch.optim.Adam(layer_params, lr=self.learning_rate)
            scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=1, gamma=0.5)
            
            best_val_loss = float('inf')
            patience_counter = 0
            
            for epoch in range(self.num_epochs):
                self.model.train()
                train_loss = 0.0
                num_batches = 0
                
                indices = np.random.permutation(len(X_train_tensor))
                
                for start_idx in range(0, len(X_train_tensor), self.batch_size):
                    end_idx = min(start_idx + self.batch_size, len(X_train_tensor))
                    batch_indices = indices[start_idx:end_idx]
                    
                    if len(batch_indices) == 0:
                        continue
                    
                    batch_X = X_train_tensor[batch_indices]
                    
                    optimizer.zero_grad()
                    
                    outputs = self.model(batch_X, layer_idx=layer_idx)
                    recon = outputs['reconstructions'][-1]
                    prior = outputs['priors'][-1]
                    series = outputs['series'][-1]
                    feat = outputs['outputs'][-1]
                    
                    recon_loss = F.mse_loss(recon, batch_X)
                    
                    batch_size = batch_X.shape[0]
                    ass_dis_loss = 0.0
                    for b in range(batch_size):
                        prior_b = prior[b].mean(dim=0)
                        series_b = series[b].mean(dim=0)
                        
                        prior_stable = prior_b + 1e-10
                        series_stable = series_b + 1e-10
                        
                        prior_stable = prior_stable / (prior_stable.sum(dim=-1, keepdim=True) + 1e-10)
                        series_stable = series_stable / (series_stable.sum(dim=-1, keepdim=True) + 1e-10)
                        
                        kl1 = F.kl_div(torch.log(series_stable), prior_stable, reduction='batchmean')
                        kl2 = F.kl_div(torch.log(prior_stable), series_stable, reduction='batchmean')
                        ass_dis_loss += (kl1 + kl2)
                    
                    ass_dis_loss = ass_dis_loss / batch_size
                    feat_loss = self.model.compute_feature_disentanglement_loss([feat])
                    
                    loss = recon_loss - self.lambda_param * ass_dis_loss + feat_loss
                    
                    if torch.isnan(loss) or torch.isinf(loss):
                        continue
                    
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(layer_params, max_norm=1.0)
                    optimizer.step()
                    
                    train_loss += loss.item()
                    num_batches += 1
                
                if num_batches == 0:
                    avg_train_loss = float('inf')
                else:
                    avg_train_loss = train_loss / num_batches
                
                self.model.eval()
                with torch.no_grad():
                    val_batch_size = min(32, len(X_val_tensor))
                    val_outputs = self.model(X_val_tensor[:val_batch_size], layer_idx=layer_idx)
                    val_recon = val_outputs['reconstructions'][-1]
                    val_prior = val_outputs['priors'][-1]
                    val_series = val_outputs['series'][-1]
                    val_feat = val_outputs['outputs'][-1]
                    
                    val_recon_loss = F.mse_loss(val_recon, X_val_tensor[:val_batch_size])
                    
                    val_ass_dis_loss = 0.0
                    for b in range(val_batch_size):
                        prior_b = val_prior[b].mean(dim=0)
                        series_b = val_series[b].mean(dim=0)
                        
                        prior_stable = prior_b + 1e-10
                        series_stable = series_b + 1e-10
                        
                        prior_stable = prior_stable / (prior_stable.sum(dim=-1, keepdim=True) + 1e-10)
                        series_stable = series_stable / (series_stable.sum(dim=-1, keepdim=True) + 1e-10)
                        
                        kl1 = F.kl_div(torch.log(series_stable), prior_stable, reduction='batchmean')
                        kl2 = F.kl_div(torch.log(prior_stable), series_stable, reduction='batchmean')
                        val_ass_dis_loss += (kl1 + kl2)
                    
                    val_ass_dis_loss = val_ass_dis_loss / val_batch_size
                    val_feat_loss = self.model.compute_feature_disentanglement_loss([val_feat])
                    
                    val_loss = val_recon_loss - self.lambda_param * val_ass_dis_loss + val_feat_loss
                
                val_loss_value = val_loss.item() if not torch.isnan(val_loss) else float('inf')
                
                if val_loss_value < best_val_loss - self.min_delta and not np.isinf(val_loss_value):
                    best_val_loss = val_loss_value
                    patience_counter = 0
                else:
                    patience_counter += 1
                
                if patience_counter >= self.patience:
                    break
                
                scheduler.step()
            
            torch.save(self.model.state_dict(), f'9DADN/model_layer_{layer_idx}.pth')
        
        torch.save(self.model.state_dict(), '9DADN/DADN.pth')
    
    def evaluate_dataset(self, X, y_true, c_percent=1.0, dataset_name="dataset"):
        X_windows = self.create_windows_nonoverlap(X)
        
        if len(X_windows) == 0:
            return None
        
        X_tensor = torch.FloatTensor(X_windows).to(self.device)
        
        self.model.eval()
        all_scores = []
        all_exit_layers = []
        
        start_time = time.time()
        
        with torch.no_grad():
            for i in range(0, len(X_tensor), self.batch_size):
                batch_X = X_tensor[i:i+self.batch_size]
                anomaly_scores, exit_layers = self.model.dynamic_inference(batch_X, update_borders=False)
                
                anomaly_scores = torch.nan_to_num(anomaly_scores, nan=0.0, posinf=1.0, neginf=0.0)
                all_scores.append(anomaly_scores.cpu().numpy())
                all_exit_layers.append(exit_layers.cpu().numpy())
        
        inference_time = time.time() - start_time
        
        if all_scores:
            scores = np.concatenate(all_scores, axis=0).flatten()
            exit_layers = np.concatenate(all_exit_layers, axis=0)
            
            min_len = min(len(scores), len(y_true))
            scores = scores[:min_len]
            y_true_adj = y_true[:min_len]
            
            scores = np.nan_to_num(scores, nan=0.0, posinf=1.0, neginf=0.0)
            
            threshold = compute_threshold_by_percentile(scores, c_percent)
            predictions = (scores > threshold).astype(int)
            
            if len(np.unique(y_true_adj)) < 2:
                auc_score = 0.5
                pr_auc_score = 0.5
            else:
                auc_score = roc_auc_score(y_true_adj, scores)
                pr_auc_score = average_precision_score(y_true_adj, scores)
            
            accuracy = accuracy_score(y_true_adj, predictions)
            precision = precision_score(y_true_adj, predictions, zero_division=0)
            recall = recall_score(y_true_adj, predictions, zero_division=0)
            f1 = f1_score(y_true_adj, predictions, zero_division=0)
            gmean = g_mean_score(y_true_adj, predictions)
            
            inference_speed = len(X_tensor) / inference_time if inference_time > 0 else 0
            
            return {
                'auc': auc_score,
                'pr_auc': pr_auc_score,
                'accuracy': accuracy,
                'precision': precision,
                'recall': recall,
                'f1_score': f1,
                'g_mean': gmean,
                'inference_time': inference_time,
                'inference_speed': inference_speed,
                'scores': scores,
                'predictions': predictions,
                'exit_layers': exit_layers
            }
        
        return None
    
    
'''======================================================================================================='''
'''                                           Read dataset                       '''
#from ReadFinanceDataSet import DataProcessor 

'''################################## Credit Card #####################'''
from ReadCreditcardDataset import DataProcessor


'''################################## Network Attack #####################'''
#from ReadCoAtSetDataset import DataProcessor

# ==================== 主函数 ====================
def main():
    torch.manual_seed(42)
    np.random.seed(42)
    
    print("开始DADN训练...")
    
    try:
        processor = DataProcessor()
        processed_data = processor.load_and_preprocess_data()
        
        if len(processed_data) == 6:
            X_train, y_train, X_val, y_val, X_test, y_test = processed_data
        else:
            raise ValueError("数据处理器返回的数据格式不正确")
            
    except Exception as e:
        print(f"导入数据出错: {e}")
        print("使用示例数据...")
        
        n_samples = 10000
        n_features = 50
        
        t = np.linspace(0, 20*np.pi, n_samples)
        X_train = np.zeros((n_samples, n_features))
        for i in range(n_features):
            X_train[:, i] = np.sin(t + i*np.pi/10) + 0.1 * np.random.randn(n_samples)
        
        y_train = np.zeros(n_samples)
        
        n_anomalies = int(n_samples * 0.01)
        anomaly_indices = np.random.choice(n_samples, size=n_anomalies, replace=False)
        for idx in anomaly_indices:
            feature_idx = np.random.randint(0, n_features)
            X_train[idx, feature_idx] += np.random.uniform(3, 10)
            y_train[idx] = 1
        
        val_size = n_samples // 3
        X_val = X_train[:val_size].copy()
        y_val = y_train[:val_size].copy()
        X_test = X_train[val_size:val_size*2].copy()
        y_test = y_train[val_size:val_size*2].copy()
        X_train = X_train[val_size*2:]
        y_train = y_train[val_size*2:]
    
    from sklearn.preprocessing import MinMaxScaler
    scaler = MinMaxScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_val_scaled = scaler.transform(X_val)
    X_test_scaled = scaler.transform(X_test)
    
    input_dim = X_train.shape[1]
    window_size = 100
    d_model = 128
    n_heads = 4
    n_layers = 3
    
    model = DADN(
        input_dim=input_dim,
        window_size=window_size,
        d_model=d_model,
        n_heads=n_heads,
        n_layers=n_layers
    )
    
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    trainer = DADNTrainer(
        model=model,
        input_dim=input_dim,
        window_size=window_size,
        device=device
    )
    
    start_train_time = time.time()
    trainer.train_layerwise(X_train_scaled, y_train, X_val_scaled, y_val)
    train_time = time.time() - start_train_time
    
    model.load_state_dict(torch.load('9DADN/DADN.pth', map_location=device))
    
    train_results = trainer.evaluate_dataset(X_train_scaled, y_train, c_percent=1.0, dataset_name="训练集")
    val_results = trainer.evaluate_dataset(X_val_scaled, y_val, c_percent=1.0, dataset_name="验证集")
    test_results = trainer.evaluate_dataset(X_test_scaled, y_test, c_percent=1.0, dataset_name="测试集")
    
    results_df = pd.DataFrame({
        'Dataset': ['Train', 'Validation', 'Test'],
        'auc': [
            round(train_results['auc'], 4) if train_results else 0,
            round(val_results['auc'], 4) if val_results else 0,
            round(test_results['auc'], 4) if test_results else 0
        ],
        'pr_auc': [
            round(train_results['pr_auc'], 4) if train_results else 0,
            round(val_results['pr_auc'], 4) if val_results else 0,
            round(test_results['pr_auc'], 4) if test_results else 0
        ],
        'accuracy': [
            round(train_results['accuracy'], 4) if train_results else 0,
            round(val_results['accuracy'], 4) if val_results else 0,
            round(test_results['accuracy'], 4) if test_results else 0
        ],
        'precision': [
            round(train_results['precision'], 4) if train_results else 0,
            round(val_results['precision'], 4) if val_results else 0,
            round(test_results['precision'], 4) if test_results else 0
        ],
        'recall': [
            round(train_results['recall'], 4) if train_results else 0,
            round(val_results['recall'], 4) if val_results else 0,
            round(test_results['recall'], 4) if test_results else 0
        ],
        'f1_score': [
            round(train_results['f1_score'], 4) if train_results else 0,
            round(val_results['f1_score'], 4) if val_results else 0,
            round(test_results['f1_score'], 4) if test_results else 0
        ],
        'g_mean': [
            round(train_results['g_mean'], 4) if train_results else 0,
            round(val_results['g_mean'], 4) if val_results else 0,
            round(test_results['g_mean'], 4) if test_results else 0
        ]
    })
    
    results_df.to_csv('9DADN/results.csv', index=False, float_format='%.4f')
    
    total_inference_time = 0
    total_samples = 0
    if train_results:
        total_inference_time += train_results['inference_time']
        total_samples += len(X_train_scaled) // window_size
    if val_results:
        total_inference_time += val_results['inference_time']
        total_samples += len(X_val_scaled) // window_size
    if test_results:
        total_inference_time += test_results['inference_time']
        total_samples += len(X_test_scaled) // window_size
    
    inference_speed = total_samples / total_inference_time if total_inference_time > 0 else 0
    
    time_df = pd.DataFrame({
        'Metric': ['Training_Time_Seconds', 'Inference_Time_Seconds', 'Inference_Speed_SamplesPerSecond'],
        'Value': [
            round(train_time, 4),
            round(total_inference_time, 4),
            round(inference_speed, 4)
        ]
    })
    
    time_df.to_csv('9DADN/time.csv', index=False, float_format='%.4f')
    
    print("训练完成!")
    print(f"模型已保存到: 9DADN/DADN.pth")
    print(f"结果已保存到: 9DADN/results.csv")
    print(f"时间指标已保存到: 9DADN/time.csv")

if __name__ == "__main__":
    main()