import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import pandas as pd
import time
import os
from pathlib import Path
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, average_precision_score
import warnings
warnings.filterwarnings('ignore')

#======================read different dataset===================================#
'''======================================================================================================='''
'''                                           Read dataset                       '''
#from ReadFinanceDataSet import DataProcessor 

'''################################## Credit Card #####################'''
from ReadCreditcardDataset import DataProcessor


'''################################## Network Attack #####################'''
#from ReadCoAtSetDataset import DataProcessor

# SG-AE模型实现 - 严格遵循论文
class SG_AE(nn.Module):
    """Score-Guided Autoencoder (SG-AE) - 严格遵循论文实现"""
    
    def __init__(self, input_dim, hidden_dims=[64, 20], scoring_hidden_dims=[20, 1]):
        """
        初始化SG-AE模型 - 严格遵循论文
        Args:
            input_dim: 输入维度
            hidden_dims: 编码器隐藏层维度，论文使用[64, 20]
            scoring_hidden_dims: 评分网络隐藏层维度，论文使用(20, 1)
        """
        super(SG_AE, self).__init__()
        
        # 构建编码器 - 论文使用全连接网络
        encoder_layers = []
        prev_dim = input_dim
        for hidden_dim in hidden_dims:
            encoder_layers.append(nn.Linear(prev_dim, hidden_dim))
            encoder_layers.append(nn.ReLU())
            prev_dim = hidden_dim
        self.encoder = nn.Sequential(*encoder_layers)
        
        # 构建解码器（对称结构）- 论文使用全连接网络
        decoder_layers = []
        hidden_dims_rev = list(reversed(hidden_dims))
        for i, hidden_dim in enumerate(hidden_dims_rev[1:]):
            decoder_layers.append(nn.Linear(hidden_dims_rev[i], hidden_dim))
            decoder_layers.append(nn.ReLU())
        decoder_layers.append(nn.Linear(hidden_dims_rev[-1], input_dim))
        self.decoder = nn.Sequential(*decoder_layers)
        
        # 构建评分网络 - 论文使用全连接网络，输出层无激活函数
        scoring_layers = []
        prev_dim = hidden_dims[-1]  # 潜在表示维度
        for hidden_dim in scoring_hidden_dims:
            scoring_layers.append(nn.Linear(prev_dim, hidden_dim))
            if hidden_dim != 1:  # 输出层不使用ReLU
                scoring_layers.append(nn.ReLU())
            prev_dim = hidden_dim
        # 注意：论文中评分网络输出层没有激活函数，直接输出分数
        self.scoring_network = nn.Sequential(*scoring_layers)
        
        # 保存维度信息
        self.latent_dim = hidden_dims[-1]
        
    def forward(self, x):
        """前向传播 - 严格遵循论文"""
        # 编码
        z = self.encoder(x)
        
        # 解码
        x_recon = self.decoder(z)
        
        # 评分 - 论文中评分网络输出无限制的分数
        s = self.scoring_network(z)
        
        return x_recon, z, s.squeeze()

# SG-AE训练器 - 严格遵循论文
class SG_AETrainer:
    def __init__(self, input_dim, device='cuda' if torch.cuda.is_available() else 'cpu', 
                 hidden_dims=[64, 20], scoring_hidden_dims=[20, 1],
                 lr=1e-4, a=6.0, mu_0=0.01, lambda_se=0.01, lambda_a=18.0):
        """
        初始化SG-AE训练器 - 严格遵循论文
        Args:
            input_dim: 输入维度
            device: 计算设备
            hidden_dims: 隐藏层维度，论文使用[64, 20]
            scoring_hidden_dims: 评分网络隐藏层维度，论文使用(20, 1)
            lr: 学习率，论文使用1e-4
            a: 目标异常分数，论文设置为6
            mu_0: 目标正常样本分数，论文使用接近0的值
            lambda_se: LSE损失权重，论文使用0.01
            lambda_a: 异常样本LSE权重，论文使用18
        """
        self.device = device
        self.a = a
        self.mu_0 = mu_0
        self.lambda_se = lambda_se
        self.lambda_a = lambda_a
        
        # 初始化模型
        self.model = SG_AE(input_dim, hidden_dims, scoring_hidden_dims).to(device)
        
        # 优化器 - 论文使用Adam
        self.optimizer = optim.Adam(self.model.parameters(), lr=lr)
        
        # 训练历史
        self.train_losses = []
        self.train_recon_losses = []
        self.train_lse_losses = []
        self.epsilon_history = []
        
    def compute_epsilon(self, recon_errors):
        """
        计算epsilon - 严格遵循论文公式(14)
        论文中：ε_p = N(f̂ < std(f̂)) / N(f̂)，其中f̂ = (f - mean(f)) / std(f)
        """
        # 计算标准化参考分数
        f = recon_errors.detach().cpu().numpy()
        if len(f) == 0:
            return 0.0
        
        f_mean = np.mean(f)
        f_std = np.std(f) + 1e-8
        f_hat = (f - f_mean) / f_std
        
        # 计算ε_p：f̂ < std(f̂)的样本比例
        # 论文中：ε_p = N(f̂ < std(f̂)) / N(f̂)
        epsilon_p = np.sum(f_hat < np.std(f_hat)) / len(f_hat)
        
        # 根据ε_p找到对应的ε值
        epsilon = np.percentile(f, epsilon_p * 100)
        
        return epsilon, epsilon_p
    
    def lse_loss(self, recon_errors, scores):
        """
        计算LSE损失 - 严格遵循论文公式(3)
        L_SE(f,s) = |s - μ_0| if f < ε
                    λ_a * max(0, a - s) if f ≥ ε
        """
        # 动态计算ε - 遵循论文公式(14)
        epsilon, epsilon_p = self.compute_epsilon(recon_errors)
        self.epsilon_history.append(epsilon_p)
        
        epsilon_tensor = torch.tensor(epsilon, device=self.device)
        
        # 明显正常样本 (f < ε)
        normal_mask = recon_errors < epsilon_tensor
        normal_scores = scores[normal_mask]
        
        # 疑似异常样本 (f ≥ ε)
        abnormal_mask = ~normal_mask
        abnormal_scores = scores[abnormal_mask]
        
        # 计算LSE损失 - 严格遵循论文公式(3)
        lse_loss = torch.zeros(1, device=self.device)
        
        if normal_scores.numel() > 0:
            # 明显正常样本: L_SE = |s - μ_0|
            normal_loss = torch.abs(normal_scores - self.mu_0).mean()
            lse_loss = lse_loss + normal_loss
        
        if abnormal_scores.numel() > 0:
            # 疑似异常样本: L_SE = λ_a * max(0, a - s)
            abnormal_loss = self.lambda_a * torch.clamp(self.a - abnormal_scores, min=0).mean()
            lse_loss = lse_loss + abnormal_loss
        
        return lse_loss
    
    def compute_loss(self, x, x_recon, scores):
        """计算总损失 - 严格遵循论文公式(4)和(7)"""
        # 重构损失 - 论文使用L2损失
        recon_error = torch.norm(x - x_recon, p=2, dim=1)
        recon_loss = torch.mean(recon_error ** 2)  # 论文公式(7)
        
        # LSE损失 - 论文公式(3)
        lse_loss = self.lse_loss(recon_error, scores)
        
        # 总损失 - 论文公式(4): L = L_OE + λ_SE * L_SE
        total_loss = recon_loss + self.lambda_se * lse_loss
        
        return total_loss, recon_loss.item(), lse_loss.item()
    
    def train_epoch(self, train_loader):
        """训练一个epoch"""
        self.model.train()
        total_loss = 0
        total_recon_loss = 0
        total_lse_loss = 0
        batch_count = 0
        
        for batch_idx, (data, _) in enumerate(train_loader):
            data = data.to(self.device)
            
            # 前向传播
            x_recon, _, scores = self.model(data)
            
            # 计算损失
            loss, recon_loss, lse_loss = self.compute_loss(data, x_recon, scores)
            
            # 反向传播
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()
            
            total_loss += loss.item()
            total_recon_loss += recon_loss
            total_lse_loss += lse_loss
            batch_count += 1
        
        if batch_count > 0:
            return total_loss / batch_count, total_recon_loss / batch_count, total_lse_loss / batch_count
        else:
            return 0, 0, 0
    
    def get_scores(self, data_loader):
        """获取数据集的异常分数"""
        self.model.eval()
        all_scores = []
        all_recon_errors = []
        all_labels = []
        
        with torch.no_grad():
            for data, labels in data_loader:
                data = data.to(self.device)
                x_recon, _, scores = self.model(data)
                
                # 计算重构误差
                recon_error = torch.norm(data - x_recon, p=2, dim=1)
                
                all_scores.extend(scores.cpu().numpy())
                all_recon_errors.extend(recon_error.cpu().numpy())
                all_labels.extend(labels.numpy())
        
        return np.array(all_scores), np.array(all_recon_errors), np.array(all_labels)
    
    def compute_threshold(self, scores, method='epsilon_p'):
        """
        计算阈值 - 严格遵循论文方法
        method='epsilon_p': 使用论文公式(14)计算ε_p，然后找到对应的分数阈值
        """
        if method == 'epsilon_p':
            # 使用论文公式(14)计算ε_p
            f = scores
            if len(f) == 0:
                return 0.0
            
            f_mean = np.mean(f)
            f_std = np.std(f) + 1e-8
            f_hat = (f - f_mean) / f_std
            
            # 计算ε_p：f̂ < std(f̂)的样本比例
            epsilon_p = np.sum(f_hat < np.std(f_hat)) / len(f_hat)
            
            # 根据ε_p找到对应的分数阈值
            threshold = np.percentile(f, epsilon_p * 100)
            return threshold
        else:
            # 默认使用95%分位数
            return np.percentile(scores, 95)
    
    def train(self, train_loader, val_loader, n_epochs=100):
        """训练模型"""
        print("开始训练SG-AE模型...")
        print(f"设备: {self.device}")
        start_time = time.time()
        
        for epoch in range(n_epochs):
            # 训练
            train_loss, train_recon_loss, train_lse_loss = self.train_epoch(train_loader)
            
            # 保存历史
            self.train_losses.append(train_loss)
            self.train_recon_losses.append(train_recon_loss)
            self.train_lse_losses.append(train_lse_loss)
            
            # 每10个epoch打印一次进度
            if (epoch + 1) % 10 == 0 or epoch == 0:
                # 验证
                val_scores, val_recon_errors, val_labels = self.get_scores(val_loader)
                if len(val_scores) > 0:
                    # 计算阈值
                    threshold = self.compute_threshold(val_scores, method='epsilon_p')
                    val_predictions = (val_scores > threshold).astype(int)
                    
                    # 计算验证集AUC
                    try:
                        val_auc = roc_auc_score(val_labels, val_scores)
                    except:
                        val_auc = 0.5
                    
                    print(f'Epoch {epoch+1}/{n_epochs}: '
                          f'Train Loss: {train_loss:.4f} (Recon: {train_recon_loss:.4f}, LSE: {train_lse_loss:.4f}), '
                          f'Val AUC: {val_auc:.4f}, Epsilon_p: {self.epsilon_history[-1]:.4f}')
                else:
                    print(f'Epoch {epoch+1}/{n_epochs}: '
                          f'Train Loss: {train_loss:.4f} (Recon: {train_recon_loss:.4f}, LSE: {train_lse_loss:.4f})')
        
        training_time = time.time() - start_time
        print(f"训练完成，耗时: {training_time:.2f}秒")
        
        return training_time
    
    def evaluate(self, data_loader, threshold=None):
        """评估模型性能"""
        # 获取分数和标签
        scores, recon_errors, labels = self.get_scores(data_loader)
        
        if len(scores) == 0:
            return {
                'auc': 0.5,
                'pr_auc': 0.0,
                'accuracy': 0.0,
                'precision': 0.0,
                'recall': 0.0,
                'f1_score': 0.0,
                'g_mean': 0.0
            }
        
        # 计算阈值
        if threshold is None:
            threshold = self.compute_threshold(scores, method='epsilon_p')
        
        # 生成预测
        predictions = (scores > threshold).astype(int)
        
        # 计算指标
        metrics = self.compute_metrics(labels, predictions, scores)
        
        return metrics
    
    def compute_metrics(self, y_true, y_pred, scores):
        """计算各种指标"""
        # 检查数据有效性
        if len(y_true) == 0 or len(np.unique(y_true)) < 2:
            return {
                'auc': 0.5,
                'pr_auc': 0.0,
                'accuracy': 0.0,
                'precision': 0.0,
                'recall': 0.0,
                'f1_score': 0.0,
                'g_mean': 0.0
            }
        
        # 基础指标
        try:
            accuracy = accuracy_score(y_true, y_pred)
        except:
            accuracy = 0.0
        
        try:
            precision = precision_score(y_true, y_pred, zero_division=0)
        except:
            precision = 0.0
        
        try:
            recall = recall_score(y_true, y_pred, zero_division=0)
        except:
            recall = 0.0
        
        try:
            f1 = f1_score(y_true, y_pred, zero_division=0)
        except:
            f1 = 0.0
        
        # 计算G-mean
        try:
            tn = np.sum((y_true == 0) & (y_pred == 0))
            fp = np.sum((y_true == 0) & (y_pred == 1))
            fn = np.sum((y_true == 1) & (y_pred == 0))
            tp = np.sum((y_true == 1) & (y_pred == 1))
            
            sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0
            specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
            g_mean = np.sqrt(sensitivity * specificity) if sensitivity > 0 and specificity > 0 else 0
        except:
            sensitivity = 0.0
            specificity = 0.0
            g_mean = 0.0
        
        # AUC-ROC
        try:
            auc_roc = roc_auc_score(y_true, scores)
        except:
            auc_roc = 0.5
        
        # PR-AUC
        try:
            pr_auc = average_precision_score(y_true, scores)
        except:
            pr_auc = 0.0
        
        return {
            'auc': auc_roc,
            'pr_auc': pr_auc,
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1_score': f1,
            'g_mean': g_mean
        }
    
    def measure_inference_time(self, data_loader, n_runs=100):
        """测量推理时间"""
        self.model.eval()
        total_time = 0
        total_samples = 0
        
        with torch.no_grad():
            for i, (data, _) in enumerate(data_loader):
                if i >= n_runs:
                    break
                data = data.to(self.device)
                
                start_time = time.time()
                _, _, _ = self.model(data)
                torch.cuda.synchronize() if torch.cuda.is_available() else None
                end_time = time.time()
                
                total_time += end_time - start_time
                total_samples += data.shape[0]
        
        if total_samples > 0:
            avg_time_per_batch = total_time / min(n_runs, len(data_loader))
            avg_time_per_sample = total_time / total_samples
            samples_per_second = total_samples / total_time if total_time > 0 else 0
        else:
            avg_time_per_batch = 0
            avg_time_per_sample = 0
            samples_per_second = 0
            
        return avg_time_per_batch, avg_time_per_sample, samples_per_second

# 数据加载器
class DataLoaderWrapper:
    def __init__(self, X, y, batch_size=1024, shuffle=True):
        # 将输入转换为 numpy 数组
        if hasattr(X, 'values'):
            X = X.values
        if hasattr(y, 'values'):
            y = y.values
        
        self.X = torch.FloatTensor(X)
        self.y = torch.FloatTensor(y)
        self.batch_size = batch_size
        self.shuffle = shuffle
        self.n_samples = len(X)
    
    def __len__(self):
        return self.n_samples // self.batch_size + (1 if self.n_samples % self.batch_size != 0 else 0)
    
    def __iter__(self):
        if self.shuffle:
            indices = torch.randperm(self.n_samples)
        else:
            indices = torch.arange(self.n_samples)
        
        for start_idx in range(0, self.n_samples, self.batch_size):
            end_idx = min(start_idx + self.batch_size, self.n_samples)
            batch_indices = indices[start_idx:end_idx]
            
            yield self.X[batch_indices], self.y[batch_indices]

def save_results(results_dict, filepath):
    """保存结果到CSV文件"""
    # 确保目录存在
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    
    # 创建DataFrame
    df = pd.DataFrame([results_dict])
    
    # 格式化数值，保留4位小数
    for col in df.columns:
        if df[col].dtype == 'float64':
            df[col] = df[col].round(4)
    
    # 保存到CSV
    df.to_csv(filepath, index=False)
    print(f"结果已保存到: {filepath}")

def main():
    """主函数"""
    # 设置随机种子
    torch.manual_seed(42)
    np.random.seed(42)
    
    # 创建结果目录
    results_dir = Path("3SG-AE")
    results_dir.mkdir(exist_ok=True)
    
    # 加载数据
    print("加载数据...")
    processor = DataProcessor()
    processed_data = processor.load_and_preprocess_data()
    
    if len(processed_data) == 4:
        X_train, y_train, X_val, y_val = processed_data
        X_test, y_test = None, None
    elif len(processed_data) == 6:
        X_train, y_train, X_val, y_val, X_test, y_test = processed_data
    else:
        raise ValueError("数据格式不正确")
    
    # 确保数据是 numpy 数组
    X_train = np.array(X_train) if not isinstance(X_train, np.ndarray) else X_train
    y_train = np.array(y_train) if not isinstance(y_train, np.ndarray) else y_train
    X_val = np.array(X_val) if not isinstance(X_val, np.ndarray) else X_val
    y_val = np.array(y_val) if not isinstance(y_val, np.ndarray) else y_val
    
    print(f"训练集: {X_train.shape}, 异常比例: {y_train.mean():.4f}")
    print(f"验证集: {X_val.shape}, 异常比例: {y_val.mean():.4f}")
    if X_test is not None:
        X_test = np.array(X_test) if not isinstance(X_test, np.ndarray) else X_test
        y_test = np.array(y_test) if not isinstance(y_test, np.ndarray) else y_test
        print(f"测试集: {X_test.shape}, 异常比例: {y_test.mean():.4f}")
    
    # 创建数据加载器
    train_loader = DataLoaderWrapper(X_train, y_train, batch_size=1024, shuffle=True)
    val_loader = DataLoaderWrapper(X_val, y_val, batch_size=1024, shuffle=False)
    
    # 初始化训练器 - 使用论文中的超参数
    input_dim = X_train.shape[1]
    trainer = SG_AETrainer(
        input_dim=input_dim,
        device='cuda' if torch.cuda.is_available() else 'cpu',
        hidden_dims=[64, 20],  # 论文中的维度
        scoring_hidden_dims=[20, 1],  # 论文中的评分网络维度
        lr=1e-4,  # 论文中的学习率
        a=6.0,  # 论文中的目标异常分数
        mu_0=0.01,  # 论文中的μ_0
        lambda_se=0.01,  # 论文中的λ_SE
        lambda_a=18.0  # 论文中的λ_a
    )
    
    # 训练模型
    training_time = trainer.train(train_loader, val_loader, n_epochs=100)
    
    # 保存模型
    model_path = results_dir / "SG-AE.pth"
    torch.save({
        'model_state_dict': trainer.model.state_dict(),
        'optimizer_state_dict': trainer.optimizer.state_dict(),
        'input_dim': input_dim,
        'hidden_dims': [64, 20],
        'scoring_hidden_dims': [20, 1],
        'hyperparams': {
            'a': trainer.a,
            'mu_0': trainer.mu_0,
            'lambda_se': trainer.lambda_se,
            'lambda_a': trainer.lambda_a
        }
    }, model_path)
    print(f"模型已保存到: {model_path}")
    
    # 测量推理时间
    inference_time_per_batch, inference_time_per_sample, inference_speed = trainer.measure_inference_time(val_loader, n_runs=100)
    
    # 使用验证集计算最佳阈值
    val_scores, val_recon_errors, val_labels = trainer.get_scores(val_loader)
    optimal_threshold = trainer.compute_threshold(val_scores, method='epsilon_p')
    print(f"使用验证集计算的最优阈值: {optimal_threshold:.4f}")
    
    # 评估训练集
    print("\n评估训练集...")
    train_metrics = trainer.evaluate(train_loader, threshold=optimal_threshold)
    
    # 评估验证集
    print("评估验证集...")
    val_metrics = trainer.evaluate(val_loader, threshold=optimal_threshold)
    
    # 评估测试集（如果存在）
    if X_test is not None and y_test is not None:
        test_loader = DataLoaderWrapper(X_test, y_test, batch_size=1024, shuffle=False)
        print("评估测试集...")
        test_metrics = trainer.evaluate(test_loader, threshold=optimal_threshold)
    else:
        # 如果没有测试集，使用验证集作为测试集结果
        test_metrics = val_metrics.copy()
    
    # 保存结果到CSV文件
    # 训练结果
    train_results = {
        'auc': train_metrics['auc'],
        'pr_auc': train_metrics['pr_auc'],
        'accuracy': train_metrics['accuracy'],
        'precision': train_metrics['precision'],
        'recall': train_metrics['recall'],
        'f1_score': train_metrics['f1_score'],
        'g_mean': train_metrics['g_mean']
    }
    
    # 验证结果
    val_results = {
        'auc': val_metrics['auc'],
        'pr_auc': val_metrics['pr_auc'],
        'accuracy': val_metrics['accuracy'],
        'precision': val_metrics['precision'],
        'recall': val_metrics['recall'],
        'f1_score': val_metrics['f1_score'],
        'g_mean': val_metrics['g_mean']
    }
    
    # 测试结果
    test_results = {
        'auc': test_metrics['auc'],
        'pr_auc': test_metrics['pr_auc'],
        'accuracy': test_metrics['accuracy'],
        'precision': test_metrics['precision'],
        'recall': test_metrics['recall'],
        'f1_score': test_metrics['f1_score'],
        'g_mean': test_metrics['g_mean']
    }
    
    # 合并所有结果
    all_results = {}
    for key in train_results:
        all_results[f'train_{key}'] = train_results[key]
    for key in val_results:
        all_results[f'val_{key}'] = val_results[key]
    for key in test_results:
        all_results[f'test_{key}'] = test_results[key]
    
    # 保存到results.csv
    results_path = results_dir / "results.csv"
    save_results(all_results, results_path)
    
    # 保存时间信息
    time_results = {
        'Training_Time_Seconds': round(training_time, 4),
        'Inference_Time_Seconds': round(inference_time_per_batch, 4),
        'Inference_Speed_SamplesPerSecond': round(inference_speed, 4)
    }
    
    time_path = results_dir / "time.csv"
    save_results(time_results, time_path)
    
    # 打印总结
    print("\n" + "="*60)
    print("训练结果总结:")
    print("="*60)
    print(f"训练时间: {training_time:.4f}秒")
    print(f"推理时间: {inference_time_per_batch:.4f}秒/批次")
    print(f"推理速度: {inference_speed:.4f}样本/秒")
    print(f"最优阈值: {optimal_threshold:.4f}")
    
    print("\n训练集指标:")
    print(f"  AUC: {train_metrics['auc']:.4f}, PR-AUC: {train_metrics['pr_auc']:.4f}")
    print(f"  准确率: {train_metrics['accuracy']:.4f}, 精确率: {train_metrics['precision']:.4f}")
    print(f"  召回率: {train_metrics['recall']:.4f}, F1分数: {train_metrics['f1_score']:.4f}")
    print(f"  G-Mean: {train_metrics['g_mean']:.4f}")
    
    print("\n验证集指标:")
    print(f"  AUC: {val_metrics['auc']:.4f}, PR-AUC: {val_metrics['pr_auc']:.4f}")
    print(f"  准确率: {val_metrics['accuracy']:.4f}, 精确率: {val_metrics['precision']:.4f}")
    print(f"  召回率: {val_metrics['recall']:.4f}, F1分数: {val_metrics['f1_score']:.4f}")
    print(f"  G-Mean: {val_metrics['g_mean']:.4f}")
    
    print("\n测试集指标:")
    print(f"  AUC: {test_metrics['auc']:.4f}, PR-AUC: {test_metrics['pr_auc']:.4f}")
    print(f"  准确率: {test_metrics['accuracy']:.4f}, 精确率: {test_metrics['precision']:.4f}")
    print(f"  召回率: {test_metrics['recall']:.4f}, F1分数: {test_metrics['f1_score']:.4f}")
    print(f"  G-Mean: {test_metrics['g_mean']:.4f}")
    
    print(f"\n所有结果已保存到 {results_dir} 目录")
    
    return trainer

if __name__ == "__main__":
    # 检查CUDA
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"使用设备: {device}")
    
    if device == 'cuda':
        print(f"GPU: {torch.cuda.get_device_name(0)}")
    
    # 运行主函数
    trainer = main()