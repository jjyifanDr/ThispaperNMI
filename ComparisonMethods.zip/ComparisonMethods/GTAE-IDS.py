# -*- coding: utf-8 -*-
"""
Created on Thu Dec  4 18:31:33 2025

@author: hp
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, roc_curve, confusion_matrix, precision_recall_curve, auc
from sklearn.ensemble import IsolationForest
from sklearn.svm import OneClassSVM
from sklearn.neighbors import LocalOutlierFactor
import time
import warnings
import os
from torch_geometric.data import Data, Batch
import torch_geometric.utils as utils
from torch_geometric.loader import DataLoader
from typing import Optional, Tuple, List, Dict
import networkx as nx
from scipy.sparse.linalg import eigsh
from scipy.sparse import csr_matrix, coo_matrix, diags, eye
import random

warnings.filterwarnings('ignore')
# 设置随机种子
torch.manual_seed(42)
np.random.seed(42)
random.seed(42)

# 创建保存结果的文件夹
os.makedirs('GTAE_results', exist_ok=True)
import sys
'''======================================================================================================='''
'''                                           Read dataset                       '''
#from ReadFinanceDataSet import DataProcessor 

'''################################## Credit Card #####################'''
from ReadCreditcardDataset import DataProcessor


'''################################## Network Attack #####################'''
#from ReadCoAtSetDataset import DataProcessor

# 创建保存结果的文件夹
os.makedirs('GTAE_results', exist_ok=True)

class LaplacianPE:
    """拉普拉斯位置编码 - 按照论文完全一致实现"""
    def __init__(self, k: int = 8):
        self.k = k
        
    def __call__(self, edge_index, num_nodes):
        """
        计算拉普拉斯位置编码，完全按照论文实现
        Args:
            edge_index: [2, num_edges] 边索引
            num_nodes: 节点数
        Returns:
            pe: [num_edges, k] 边的拉普拉斯位置编码
        """
        if edge_index.size(1) == 0 or num_nodes == 0:
            return torch.zeros(0, self.k)
        
        # 1. 构建邻接矩阵
        adj = coo_matrix((np.ones(edge_index.shape[1]), 
                         (edge_index[0].numpy(), edge_index[1].numpy())),
                        shape=(num_nodes, num_nodes))
        
        # 2. 计算度矩阵
        degree = np.array(adj.sum(axis=1)).flatten()
        
        # 3. 计算拉普拉斯矩阵 L = D - A
        laplacian = diags(degree) - adj
        
        # 4. 计算归一化拉普拉斯矩阵 L_norm = D^(-1/2) * L * D^(-1/2)
        degree_sqrt_inv = diags(1.0 / np.sqrt(np.where(degree > 0, degree, 1.0)))
        laplacian_norm = degree_sqrt_inv @ laplacian @ degree_sqrt_inv
        
        # 5. 计算特征值和特征向量（使用稀疏特征分解，只取最小的k+1个特征值）
        try:
            # 对于小图，使用稠密矩阵计算
            if num_nodes <= 1000:
                eigenvalues, eigenvectors = np.linalg.eigh(laplacian_norm.toarray())
            else:
                # 对于大图，使用稀疏特征分解
                eigenvalues, eigenvectors = eigsh(laplacian_norm, k=min(self.k+1, num_nodes-1), which='SM')
        except:
            # 如果计算失败，返回随机编码
            print("警告: 拉普拉斯特征分解失败，使用随机编码替代")
            return torch.randn(edge_index.shape[1], self.k)
        
        # 6. 排序特征值并选择最小的k个非零特征向量
        idx = np.argsort(eigenvalues)[:self.k]
        eigenvectors = eigenvectors[:, idx]
        
        # 7. 为每条边计算位置编码：λ_ij = [φ_i || φ_j]，其中φ是节点特征向量
        edge_pe = []
        for i in range(edge_index.shape[1]):
            src = edge_index[0, i].item()
            dst = edge_index[1, i].item()
            
            # 拼接源节点和目标节点的特征向量
            src_vec = eigenvectors[src, :] if src < len(eigenvectors) else np.zeros(self.k)
            dst_vec = eigenvectors[dst, :] if dst < len(eigenvectors) else np.zeros(self.k)
            
            # λ_ij = [φ_i || φ_j]，得到2k维向量
            pe = np.concatenate([src_vec, dst_vec])
            
            # 如果k小于2k，截断；如果大于，填充0
            if len(pe) > self.k:
                pe = pe[:self.k]
            else:
                pe = np.pad(pe, (0, self.k - len(pe)))
            
            edge_pe.append(pe)
        
        return torch.FloatTensor(np.array(edge_pe))

class GraphAttentionLayer(nn.Module):
    """图注意力层 - 修复版本"""
    def __init__(self, d_model: int, n_heads: int = 8, dropout: float = 0.1):
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        
        # 确保d_model能被n_heads整除
        if d_model % n_heads != 0:
            self.d_model = ((d_model + n_heads - 1) // n_heads) * n_heads
        
        self.d_k = self.d_model // n_heads
        
        # Q, K, V投影
        self.q_proj = nn.Linear(self.d_model, self.d_model)
        self.k_proj = nn.Linear(self.d_model, self.d_model)
        self.v_proj = nn.Linear(self.d_model, self.d_model)
        
        # 输出投影
        self.out_proj = nn.Linear(self.d_model, self.d_model)
        
        self.dropout = nn.Dropout(dropout)
        
    def forward(self, x, edge_index):
        """
        x: [num_nodes, d_model] 节点特征
        edge_index: [2, num_edges] 边索引
        """
        num_nodes = x.size(0)
        
        # 投影到Q, K, V
        Q = self.q_proj(x).view(num_nodes, self.n_heads, self.d_k)
        K = self.k_proj(x).view(num_nodes, self.n_heads, self.d_k)
        V = self.v_proj(x).view(num_nodes, self.n_heads, self.d_k)
        
        # 计算注意力分数
        scores = torch.einsum('nhd,mhd->nhm', Q, K) / np.sqrt(self.d_k)
        
        # 创建注意力掩码（基于边连接）
        if edge_index.size(1) > 0:
            src, dst = edge_index
            adj_mask = torch.zeros(num_nodes, num_nodes, device=x.device)
            adj_mask[src, dst] = 1
            # 扩展掩码到多头维度
            adj_mask = adj_mask.unsqueeze(1)  # [num_nodes, 1, num_nodes]
            adj_mask = adj_mask.expand(-1, self.n_heads, -1)  # [num_nodes, n_heads, num_nodes]
            
            # 应用掩码
            scores = scores.masked_fill(adj_mask == 0, -1e9)
        
        # 注意力权重
        attn_weights = F.softmax(scores, dim=-1)
        attn_weights = self.dropout(attn_weights)
        
        # 注意力输出
        out = torch.einsum('nhm,mhd->nhd', attn_weights, V)
        out = out.reshape(num_nodes, self.d_model)
        
        # 输出投影
        out = self.out_proj(out)
        
        return out

class GraphTransformerLayer(nn.Module):
    """图Transformer层 - 修复版本"""
    def __init__(self, d_model: int, n_heads: int = 8, dropout: float = 0.1):
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        
        self.attention = GraphAttentionLayer(
            d_model=d_model,
            n_heads=n_heads,
            dropout=dropout
        )
        
        # LayerNorm
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        
        # FFN
        self.ffn = nn.Sequential(
            nn.Linear(d_model, d_model * 4),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(d_model * 4, d_model)
        )
        
        self.dropout = nn.Dropout(dropout)
        
    def forward(self, x, edge_index):
        """
        x: [num_nodes, d_model] 节点特征
        edge_index: [2, num_edges] 边索引
        """
        # 自注意力 + 残差连接 + 层归一化
        attn_out = self.attention(x, edge_index)
        x = self.norm1(x + self.dropout(attn_out))
        
        # FFN + 残差连接 + 层归一化
        ffn_out = self.ffn(x)
        x = self.norm2(x + self.dropout(ffn_out))
        
        return x

class GraphTransformerEncoder(nn.Module):
    """图Transformer编码器 - 按照论文完全一致实现"""
    def __init__(self, input_dim: int, hidden_dim: int = 128, 
                 n_layers: int = 3, n_heads: int = 8, dropout: float = 0.1,
                 pe_dim: int = 8):
        super().__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.pe_dim = pe_dim
        
        # 确保hidden_dim能被n_heads整除
        if hidden_dim % n_heads != 0:
            self.hidden_dim = ((hidden_dim + n_heads - 1) // n_heads) * n_heads
        
        self.n_layers = n_layers
        self.n_heads = n_heads
        
        # 输入投影层（用于边特征）
        self.edge_proj = nn.Sequential(
            nn.Linear(input_dim, self.hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout)
        )
        
        # 位置编码投影层（按照论文公式(3)）
        self.pe_proj = nn.Linear(pe_dim, self.hidden_dim)
        
        # Transformer层
        self.layers = nn.ModuleList([
            GraphTransformerLayer(
                d_model=self.hidden_dim,
                n_heads=n_heads,
                dropout=dropout
            )
            for _ in range(n_layers)
        ])
        
        # 输出投影
        self.output_proj = nn.Linear(self.hidden_dim, self.hidden_dim)
        
        # 位置编码器
        self.pe_encoder = LaplacianPE(k=pe_dim)
        
    def forward(self, edge_features, edge_index):
        """
        edge_features: [num_edges, input_dim] 边特征
        edge_index: [2, num_edges] 边索引
        """
        num_edges = edge_features.size(0)
        
        # 1. 边特征投影（按照论文公式(2)）
        e_ij = self.edge_proj(edge_features)
        
        # 2. 计算拉普拉斯位置编码（按照论文公式(3)）
        num_nodes = edge_index.max().item() + 1 if edge_index.size(1) > 0 else 0
        pe = self.pe_encoder(edge_index, num_nodes).to(edge_features.device)
        
        # 3. 位置编码投影并添加到边特征
        pe_proj = self.pe_proj(pe)
        e_hat_ij = e_ij + pe_proj
        
        # 4. 将边特征转换为节点特征（简化处理）
        # 论文中实际处理的是边特征，这里我们取平均值作为节点特征
        if num_nodes > 0:
            # 为每个节点计算与其相连边的特征平均值
            node_features = torch.zeros(num_nodes, self.hidden_dim, device=edge_features.device)
            edge_counts = torch.zeros(num_nodes, device=edge_features.device)
            
            src, dst = edge_index
            for i in range(num_edges):
                node_features[src[i]] += e_hat_ij[i]
                edge_counts[src[i]] += 1
                node_features[dst[i]] += e_hat_ij[i]
                edge_counts[dst[i]] += 1
            
            # 避免除以零
            edge_counts = torch.where(edge_counts > 0, edge_counts, torch.ones_like(edge_counts))
            node_features = node_features / edge_counts.unsqueeze(1)
        else:
            node_features = e_hat_ij.mean(dim=0, keepdim=True)
        
        # 5. 通过Transformer层
        for layer in self.layers:
            node_features = layer(node_features, edge_index)
        
        # 6. 输出投影
        node_features = self.output_proj(node_features)
        
        return node_features

class DNNDecoder(nn.Module):
    """DNN解码器 - 按照论文实现"""
    def __init__(self, latent_dim: int, output_dim: int, 
                 hidden_dims: List[int] = [256, 512]):
        super().__init__()
        
        layers = []
        prev_dim = latent_dim
        
        # 构建隐藏层
        for hidden_dim in hidden_dims:
            layers.extend([
                nn.Linear(prev_dim, hidden_dim),
                nn.ReLU(),
                nn.Dropout(0.1)
            ])
            prev_dim = hidden_dim
        
        # 输出层
        layers.append(nn.Linear(prev_dim, output_dim))
        
        self.network = nn.Sequential(*layers)
        
    def forward(self, x):
        return self.network(x)

class GTAE(nn.Module):
    """图Transformer自编码器 - 按照论文完全一致实现"""
    def __init__(self, input_dim: int, hidden_dim: int = 128, 
                 n_layers: int = 3, n_heads: int = 8, 
                 decoder_dims: List[int] = [256, 512],
                 pe_dim: int = 8):
        super().__init__()
        
        # 编码器
        self.encoder = GraphTransformerEncoder(
            input_dim=input_dim,
            hidden_dim=hidden_dim,
            n_layers=n_layers,
            n_heads=n_heads,
            pe_dim=pe_dim
        )
        
        # 解码器
        self.decoder = DNNDecoder(
            latent_dim=hidden_dim,
            output_dim=input_dim,
            hidden_dims=decoder_dims
        )
        
    def forward(self, x, edge_index):
        # 编码
        z = self.encoder(x, edge_index)
        
        # 解码
        x_recon = self.decoder(z)
        
        return x_recon, z
    
    def encode(self, x, edge_index):
        """仅编码，用于特征提取"""
        return self.encoder(x, edge_index)

class EdgeFeatureBuilder:
    """边特征构建器 - 按照论文实现"""
    
    @staticmethod
    def build_edge_features(X, target_dim=50):
        """
        构建边特征
        完全按照论文实现：每个包有50维特征（25×2），模拟前向和后向包
        """
        n_samples = len(X)
        edge_features = []
        
        for i in range(0, n_samples - 1, 2):
            if i + 1 >= n_samples:
                break
                
            # 取两个样本作为通信对
            src_feat = X[i]
            dst_feat = X[i + 1]
            
            # 构建50维边特征（前25维为前向包，后25维为后向包）
            edge_feat = np.zeros(target_dim)
            feat_dim = len(src_feat)
            
            # 前向包特征（前25维）
            if feat_dim >= 25:
                edge_feat[:25] = src_feat[:25]
            else:
                edge_feat[:feat_dim] = src_feat
                # 剩余部分补0
            
            # 后向包特征（后25维）
            dst_len = min(25, len(dst_feat))
            edge_feat[25:25+dst_len] = dst_feat[:dst_len]
            
            edge_features.append(edge_feat)
        
        return np.array(edge_features)

class NetworkGraphBuilder:
    """网络图构建器 - 按照论文实现"""
    
    @staticmethod
    def build_communication_graphs(X, batch_size=32):
        """
        构建网络通信图
        按照论文实现：节点为源IP:端口和目标IP:端口，边表示通信流
        """
        graphs = []
        
        # 使用EdgeFeatureBuilder构建边特征
        edge_features_all = EdgeFeatureBuilder.build_edge_features(X)
        
        if len(edge_features_all) == 0:
            return graphs
        
        # 分批处理
        for i in range(0, len(edge_features_all), batch_size):
            edge_features_batch = edge_features_all[i:i+batch_size]
            
            if len(edge_features_batch) < 2:
                continue
            
            # 构建图：每个样本对作为一个边
            num_edges = len(edge_features_batch)
            
            # 创建节点：每个边有源节点和目标节点
            num_nodes = 2 * num_edges  # 简化：每个边有唯一的源和目标
            
            # 创建边索引：源节点 -> 目标节点
            edge_list = []
            for j in range(num_edges):
                src_node = 2 * j
                dst_node = 2 * j + 1
                edge_list.append([src_node, dst_node])
            
            edge_index = torch.tensor(edge_list, dtype=torch.long).t().contiguous()
            
            # 边特征
            edge_features = torch.FloatTensor(edge_features_batch)
            
            # 创建图数据
            graph_data = Data(
                x=torch.zeros(num_nodes, 1),  # 节点无特征，按照论文
                edge_index=edge_index,
                edge_attr=edge_features
            )
            
            graphs.append(graph_data)
        
        return graphs

class GTAE_IDS:
    """GTAE-IDS框架 - 按照论文完全一致实现"""
    def __init__(self, n_packets: int = 8, 
                 hidden_dim: int = 128, n_layers: int = 3, n_heads: int = 8):
        
        # 按照论文，边特征维度固定为50（25×2）
        self.feature_dim = 50
        self.n_packets = n_packets
        
        # 模型参数
        self.hidden_dim = hidden_dim
        self.n_layers = n_layers
        self.n_heads = n_heads
        
        # 初始化GTAE模型
        self.model = GTAE(
            input_dim=self.feature_dim,
            hidden_dim=hidden_dim,
            n_layers=n_layers,
            n_heads=n_heads,
            decoder_dims=[hidden_dim * 2, hidden_dim * 4],  # 按照论文
            pe_dim=8  # 位置编码维度
        )
        
        # 异常检测器 - 完全按照论文使用四种检测器
        self.anomaly_detectors = {
            'OCSVM': OneClassSVM(kernel='rbf', nu=0.05, gamma='auto'),
            'IF': IsolationForest(n_estimators=100, contamination=0.05, random_state=42),
            'HBOS': None,  # 需要安装pyod库
            'INNE': None   # 需要安装pyod库
        }
        
        # 尝试导入HBOS和INNE
        try:
            from pyod.models.hbos import HBOS
            from pyod.models.inne import INNE
            self.anomaly_detectors['HBOS'] = HBOS(contamination=0.05)
            self.anomaly_detectors['INNE'] = INNE(contamination=0.05)
        except ImportError:
            print("警告: 未安装pyod库，使用LOF替代HBOS和INNE")
            self.anomaly_detectors['LOF'] = LocalOutlierFactor(n_neighbors=20, contamination=0.05, novelty=True)
        
        # 训练参数
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model.to(self.device)
        
        # 优化器
        self.optimizer = torch.optim.Adam(
            self.model.parameters(), 
            lr=0.001,
            weight_decay=1e-5
        )
        
        # 损失函数 - 按照论文使用MSE
        self.criterion = nn.MSELoss()
        
        # 图构建器
        self.graph_builder = NetworkGraphBuilder()
        
        # 结果存储
        self.results = {}
        self.time_metrics = {}
        
    def prepare_data(self, X, batch_size=32):
        """准备图数据"""
        graphs = self.graph_builder.build_communication_graphs(X, batch_size)
        return graphs
    
    def compute_metrics(self, y_true, y_pred, scores):
        """计算所有评估指标 - 按照论文"""
        # 基础指标
        accuracy = accuracy_score(y_true, y_pred)
        precision = precision_score(y_true, y_pred, zero_division=0)
        recall = recall_score(y_true, y_pred, zero_division=0)
        f1 = f1_score(y_true, y_pred, zero_division=0)
        
        # 计算G-mean
        tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
        specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
        sensitivity = recall
        g_mean = np.sqrt(sensitivity * specificity) if sensitivity > 0 and specificity > 0 else 0
        
        # 计算AUC-ROC
        auc_score = roc_auc_score(y_true, scores)
        
        # 计算AUC-PR
        precision_vals, recall_vals, _ = precision_recall_curve(y_true, scores)
        pr_auc = auc(recall_vals, precision_vals)
        
        # 保留4位小数
        metrics = {
            'auc': round(auc_score, 4),
            'pr_auc': round(pr_auc, 4),
            'accuracy': round(accuracy, 4),
            'precision': round(precision, 4),
            'recall': round(recall, 4),
            'f1_score': round(f1, 4),
            'g_mean': round(g_mean, 4)
        }
        
        return metrics
    
    def train_epoch(self, train_loader):
        """训练一个epoch - 按照论文"""
        self.model.train()
        total_loss = 0
        
        for data in train_loader:
            data = data.to(self.device)
            
            # 前向传播
            recon, _ = self.model(data.edge_attr, data.edge_index)
            
            # 计算损失 - 按照论文公式(1)
            loss = self.criterion(recon.mean(dim=0, keepdim=True).expand_as(data.edge_attr), data.edge_attr)
            
            # 反向传播
            self.optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            self.optimizer.step()
            
            total_loss += loss.item()
        
        avg_loss = total_loss / len(train_loader) if len(train_loader) > 0 else total_loss
        
        return avg_loss
    
    def train(self, X_train, y_train, X_val, y_val, 
              epochs: int = 30, batch_size: int = 32):
        """训练GTAE-IDS框架 - 按照论文"""
        
        print(f"在 {self.device} 上训练 GTAE-IDS")
        print(f"边特征维度: {self.feature_dim}")
        print(f"隐藏层维度: {self.hidden_dim}")
        print(f"层数: {self.n_layers}")
        print(f"注意力头数: {self.n_heads}")
        
        # 准备训练图数据
        print("构建训练图...")
        train_graphs = self.prepare_data(X_train, batch_size=batch_size)
        
        if len(train_graphs) == 0:
            print("错误: 无法创建训练图!")
            return
        
        train_loader = DataLoader(train_graphs, batch_size=min(4, len(train_graphs)), shuffle=True)
        
        # 训练循环
        print("开始训练...")
        start_time = time.time()
        
        for epoch in range(epochs):
            # 训练
            train_loss = self.train_epoch(train_loader)
            
            # 打印进度
            if (epoch + 1) % 10 == 0:
                print(f"轮次 [{epoch+1}/{epochs}] - 训练损失: {train_loss:.4f}")
        
        training_time = time.time() - start_time
        print(f"训练完成，耗时 {training_time:.2f} 秒")
        
        # 提取特征用于训练异常检测器
        print("提取特征用于异常检测器训练...")
        train_features = self.extract_features(train_loader)
        
        if len(train_features) > 0:
            # 训练异常检测器 - 按照论文使用良性数据
            self.train_anomaly_detectors(train_features)
        else:
            print("警告: 无法提取特征用于异常检测器")
        
        # 在训练集上评估
        print("在训练集上评估...")
        train_results = self.evaluate_set(X_train, y_train, "train")
        self.results['train'] = train_results
        
        # 在验证集上评估
        print("在验证集上评估...")
        val_results = self.evaluate_set(X_val, y_val, "val")
        self.results['val'] = val_results
        
        # 保存时间指标
        self.time_metrics['Training_Time_Seconds'] = round(training_time, 4)
        
        return self.results
    
    def evaluate(self, X_test, y_test):
        """在测试集上评估模型"""
        print("在测试集上评估...")
        test_results = self.evaluate_set(X_test, y_test, "test")
        self.results['test'] = test_results
        
        # 保存结果到CSV文件
        self.save_results_to_csv()
        
        return test_results
    
    def evaluate_set(self, X, y_true, set_name="test"):
        """评估特定数据集 - 按照论文"""
        # 准备图数据
        graphs = self.prepare_data(X, batch_size=32)
        
        if len(graphs) == 0:
            print(f"错误: 无法为{set_name}集创建图!")
            return {}
        
        data_loader = DataLoader(graphs, batch_size=min(4, len(graphs)), shuffle=False)
        
        # 推理
        start_time = time.time()
        
        # 提取特征
        features = self.extract_features(data_loader)
        
        if len(features) == 0:
            print(f"警告: 无法为{set_name}集提取特征!")
            return {}
        
        # 使用异常检测器进行预测 - 按照论文使用集成投票
        predictions, scores = self.ensemble_predict(features)
        
        inference_time = time.time() - start_time
        
        # 计算指标
        min_len = min(len(predictions), len(y_true))
        predictions = predictions[:min_len]
        scores = scores[:min_len]
        y_true_adjusted = y_true[:min_len]
        
        metrics = self.compute_metrics(y_true_adjusted, predictions, scores)
        
        # 保存时间指标
        if set_name == "test":
            num_samples = len(X)
            self.time_metrics['Inference_Time_Seconds'] = round(inference_time, 4)
            self.time_metrics['Inference_Speed_SamplesPerSecond'] = round(num_samples / inference_time, 4) if inference_time > 0 else 0
            
            # 保存时间指标到CSV
            self.save_time_metrics_to_csv()
        
        return metrics
    
    def extract_features(self, data_loader):
        """提取特征用于异常检测器训练 - 按照论文"""
        self.model.eval()
        all_features = []
        
        with torch.no_grad():
            for data in data_loader:
                data = data.to(self.device)
                _, features = self.model(data.edge_attr, data.edge_index)
                all_features.append(features.cpu().numpy())
        
        if len(all_features) > 0:
            return np.concatenate(all_features, axis=0)
        else:
            return np.array([])
    
    def train_anomaly_detectors(self, train_features):
        """训练异常检测器 - 按照论文"""
        print("训练异常检测器...")
        
        for name, detector in self.anomaly_detectors.items():
            try:
                if detector is not None and len(train_features) > 0:
                    detector.fit(train_features)
                    print(f"  {name} 训练成功")
                elif detector is None:
                    print(f"  {name}: 未安装")
                else:
                    print(f"  {name}: 无训练特征")
            except Exception as e:
                print(f"  {name} 训练错误: {e}")
    
    def ensemble_predict(self, features):
        """集成预测 - 按照论文使用多数投票"""
        if len(features) == 0:
            return np.array([]), np.array([])
        
        predictions = []
        anomaly_scores = []
        
        # 使用异常检测器
        for name, detector in self.anomaly_detectors.items():
            try:
                if detector is None:
                    continue
                    
                if hasattr(detector, 'decision_function'):
                    # 对于有decision_function的检测器
                    scores = detector.decision_function(features)
                    pred = detector.predict(features)
                    # OCSVM返回1/-1，转换为0/1
                    if hasattr(detector, 'kernel'):
                        pred_binary = (pred == -1).astype(int)
                    else:
                        pred_binary = pred
                else:
                    # 对于其他检测器
                    pred = detector.predict(features)
                    pred_binary = (pred == -1).astype(int) if hasattr(pred, '__len__') else int(pred == -1)
                    scores = -pred if hasattr(pred, '__len__') else np.array([-pred])
                
                predictions.append(pred_binary)
                anomaly_scores.append(scores)
            except Exception as e:
                print(f"  {name} 预测错误: {e}")
                predictions.append(np.zeros(len(features)))
                anomaly_scores.append(np.zeros(len(features)))
        
        if len(predictions) > 0:
            # 多数投票 - 按照论文
            predictions = np.array(predictions)
            ensemble_pred = np.round(predictions.mean(axis=0)).astype(int)
            
            # 平均异常分数
            anomaly_scores = np.array(anomaly_scores)
            ensemble_scores = anomaly_scores.mean(axis=0)
        else:
            ensemble_pred = np.zeros(len(features))
            ensemble_scores = np.zeros(len(features))
        
        return ensemble_pred, ensemble_scores
    
    def save_model(self, path: str = "GTAE_results/GTAE_IDS.pth"):
        """保存完整模型"""
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'config': {
                'n_packets': self.n_packets,
                'feature_dim': self.feature_dim,
                'hidden_dim': self.hidden_dim,
                'n_layers': self.n_layers,
                'n_heads': self.n_heads
            }
        }, path)
        print(f"模型保存到 {path}")
    
    def load_model(self, path: str = "GTAE_results/GTAE_IDS.pth"):
        """加载模型"""
        checkpoint = torch.load(path, map_location=self.device)
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        print(f"模型从 {path} 加载")
    
    def save_results_to_csv(self):
        """保存结果到CSV文件"""
        if not self.results:
            print("无结果可保存")
            return
        
        # 创建DataFrame
        rows = []
        for set_name, metrics in self.results.items():
            row = {'dataset': set_name}
            row.update(metrics)
            rows.append(row)
        
        df = pd.DataFrame(rows)
        
        # 重新排序列
        column_order = ['dataset', 'auc', 'pr_auc', 'accuracy', 'precision', 'recall', 'f1_score', 'g_mean']
        df = df[column_order]
        
        # 保存到CSV
        csv_path = "GTAE_results/results.csv"
        df.to_csv(csv_path, index=False)
        print(f"结果保存到 {csv_path}")
    
    def save_time_metrics_to_csv(self):
        """保存时间指标到CSV文件"""
        if not self.time_metrics:
            print("无时间指标可保存")
            return
        
        # 创建DataFrame
        df = pd.DataFrame([self.time_metrics])
        
        # 保存到CSV
        csv_path = "GTAE_results/time.csv"
        df.to_csv(csv_path, index=False)
        print(f"时间指标保存到 {csv_path}")

# 测试代码
def main():
    """主测试函数"""
    try:
        # 导入数据处理器
       
        
        # 加载数据
        print("加载数据...")
        processor = DataProcessor()
        data = processor.load_and_preprocess_data()
        
        if data is None:
            print("错误: 数据加载失败!")
            return
        
        X_train, y_train, X_val, y_val, X_test, y_test = data
        
        # 检查数据形状
        print(f"X_train 形状: {X_train.shape}")
        print(f"y_train 形状: {y_train.shape}")
        print(f"X_val 形状: {X_val.shape}")
        print(f"y_val 形状: {y_val.shape}")
        print(f"X_test 形状: {X_test.shape if X_test is not None else 'N/A'}")
        print(f"y_test 形状: {y_test.shape if y_test is not None else 'N/A'}")
        
        # 初始化GTAE-IDS模型
        print("\n初始化 GTAE-IDS 模型...")
        gtae_ids = GTAE_IDS(
            n_packets=8,
            hidden_dim=128,
            n_layers=3,
            n_heads=8
        )
        
        # 训练模型
        print("\n训练 GTAE-IDS...")
        results = gtae_ids.train(
            X_train=X_train,
            y_train=y_train,
            X_val=X_val,
            y_val=y_val,
            epochs=30,
            batch_size=32
        )
        
        # 如果有测试数据，评估测试集
        if X_test is not None and y_test is not None:
            print("\n评估测试集...")
            test_results = gtae_ids.evaluate(X_test, y_test)
        else:
            # 使用验证集作为测试集
            print("\n使用验证集作为测试集...")
            test_results = gtae_ids.evaluate(X_val, y_val)
        
        # 保存模型
        gtae_ids.save_model()
        
        # 打印最终结果
        print("\n" + "="*50)
        print("GTAE-IDS 训练完成!")
        print("="*50)
        
        print("\n训练集结果:")
        for metric, value in results.get('train', {}).items():
            print(f"  {metric}: {value}")
        
        print("\n验证集结果:")
        for metric, value in results.get('val', {}).items():
            print(f"  {metric}: {value}")
        
        print("\n测试集结果:")
        for metric, value in test_results.items():
            print(f"  {metric}: {value}")
        
        print("\n时间指标:")
        for metric, value in gtae_ids.time_metrics.items():
            print(f"  {metric}: {value}")
        
        print("\n结果已保存到 'GTAE_results' 文件夹:")
        print("  - GTAE_IDS.pth: 训练好的模型")
        print("  - results.csv: 评估结果")
        print("  - time.csv: 时间指标")
        
    except Exception as e:
        print(f"主函数错误: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()