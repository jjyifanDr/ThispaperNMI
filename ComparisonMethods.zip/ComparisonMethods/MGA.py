# -*- coding: utf-8 -*-
"""
Created on Sat Dec  6 23:03:52 2025

@author: hp
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import time
import os
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_curve, auc, roc_auc_score, precision_recall_curve
import seaborn as sns
from torch.utils.data import DataLoader, TensorDataset
import warnings
warnings.filterwarnings('ignore')

#======================read different dataset===================================#
                         #'''Finance Dataset'''
#from ReadFinanceDataSet import DataProcessor    
#============================================================#

                         #'''Creditcard Dataset'''
from ReadCreditcardDataset import DataProcessor   
#============================================================#

                         #'''CoAtSet Dataset'''
#from ReadCoAtSetDataset import DataProcessor   
#============================================================#

# 设置随机种子
torch.manual_seed(42)
np.random.seed(42)

# 配置设备
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

# 创建结果目录
os.makedirs("2MGA", exist_ok=True)

# 严格按照论文IV-A节的阈值计算方法
class PaperThresholdCalculator:
    """论文阈值计算器 - 严格按照论文方法"""
    
    @staticmethod
    def calculate_threshold_by_anomaly_ratio(scores, anomaly_ratio):
        """
        根据异常比例计算阈值（论文IV-A节方法）
        Args:
            scores: 异常分数数组
            anomaly_ratio: 异常比例（0-1之间，来自表I的Anomalies (%)）
        Returns:
            threshold: 阈值δ
        """
        scores = np.nan_to_num(scores, nan=0.0)
        if len(scores) == 0:
            return 0.5
        
        # 按照论文方法：根据异常分数比例确定阈值
        # 使得超过阈值的点数比例等于异常比例
        sorted_scores = np.sort(scores)
        index = int((1 - anomaly_ratio) * len(sorted_scores))
        index = max(0, min(index, len(sorted_scores) - 1))
        threshold = sorted_scores[index]
        
        return threshold
    
    @staticmethod
    def calculate_metrics(y_true, y_pred):
        """计算所有指标，保留4位小数"""
        metrics = {}
        
        # 基础指标
        metrics['accuracy'] = round(float(accuracy_score(y_true, y_pred)), 4)
        metrics['precision'] = round(float(precision_score(y_true, y_pred, zero_division=0)), 4)
        metrics['recall'] = round(float(recall_score(y_true, y_pred, zero_division=0)), 4)
        metrics['f1_score'] = round(float(f1_score(y_true, y_pred, zero_division=0)), 4)
        
        # 计算g-mean
        tn = np.sum((y_true == 0) & (y_pred == 0))
        fp = np.sum((y_true == 0) & (y_pred == 1))
        fn = np.sum((y_true == 1) & (y_pred == 0))
        tp = np.sum((y_true == 1) & (y_pred == 1))
        
        specificity = tn / (tn + fp + 1e-8)
        sensitivity = tp / (tp + fn + 1e-8)
        metrics['g_mean'] = round(float(np.sqrt(sensitivity * specificity)), 4)
        
        return metrics

# ====================== 时间序列窗口化 ======================
def create_time_series_windows(data, labels, window_size=100, stride=50):
    """
    将数据转换为时间序列窗口
    Args:
        data: 原始数据 [num_samples, num_features]
        labels: 标签 [num_samples]
        window_size: 窗口大小
        stride: 步长
    Returns:
        windowed_data: [num_windows, window_size, num_features]
        windowed_labels: [num_windows]
    """
    if isinstance(data, pd.DataFrame):
        data = data.values
    if isinstance(labels, pd.Series):
        labels = labels.values
    
    num_samples, num_features = data.shape
    
    if window_size > num_samples:
        window_size = num_samples
    
    windows = []
    label_windows = []
    
    for i in range(0, num_samples - window_size + 1, stride):
        window = data[i:i+window_size]
        last_idx = i + window_size - 1
        if last_idx < len(labels):
            window_label = labels[last_idx]
        else:
            window_label = labels[-1] if len(labels) > 0 else 0
        
        windows.append(window)
        label_windows.append(window_label)
    
    if len(windows) == 0:
        if num_samples > 0:
            window = data
            if len(window) < window_size:
                padding = np.zeros((window_size - len(window), num_features))
                window = np.vstack([window, padding])
            window_label = labels[-1] if len(labels) > 0 else 0
        else:
            window = np.zeros((window_size, num_features))
            window_label = 0
        
        windows.append(window)
        label_windows.append(window_label)
    
    return np.array(windows), np.array(label_windows)

# ====================== MGA模块 ======================
class MultigranularityAttention(nn.Module):
    """Multigranularity Attention Module (MGA)"""
    
    def __init__(self, d_model, num_heads, dropout=0.1):
        super().__init__()
        self.d_model = d_model
        self.num_heads = num_heads
        
        if d_model % num_heads != 0:
            for n in range(num_heads, 0, -1):
                if d_model % n == 0:
                    num_heads = n
                    break
            if d_model % num_heads != 0:
                num_heads = 1
        self.num_heads = num_heads
        self.head_dim = d_model // num_heads
        
        self.W_q_global = nn.Linear(d_model, d_model)
        self.W_k_global = nn.Linear(d_model, d_model)
        self.W_v_global = nn.Linear(d_model, d_model)
        self.W_v_local = nn.Linear(d_model, d_model)
        self.W_sigma = nn.Linear(d_model, 1)
        self.dropout = nn.Dropout(dropout)
        self.output_proj = nn.Linear(d_model, d_model)
        
    def forward(self, z_local, z_global):
        batch_size, seq_len, _ = z_local.shape
        
        # ========== Global Attention (GGA) ==========
        Q_global = self.W_q_global(z_global)
        K_global = self.W_k_global(z_global)
        V_global = self.W_v_global(z_global)
        
        Q_global = Q_global.view(batch_size, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        K_global = K_global.view(batch_size, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        V_global = V_global.view(batch_size, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        
        scores_global = torch.matmul(Q_global, K_global.transpose(-2, -1)) / np.sqrt(self.head_dim)
        C_global = F.softmax(scores_global, dim=-1)
        C_global = self.dropout(C_global)
        
        z_tilde_global = torch.matmul(C_global, V_global)
        z_tilde_global = z_tilde_global.transpose(1, 2).contiguous().view(batch_size, seq_len, self.d_model)
        z_tilde_global = self.output_proj(z_tilde_global)
        
        # ========== Local Attention (LGA) ==========
        Q_local = self.W_q_global(z_local)
        K_local = self.W_k_global(z_local)
        V_local = self.W_v_local(z_local)
        
        Q_local = Q_local.view(batch_size, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        K_local = K_local.view(batch_size, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        V_local = V_local.view(batch_size, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        
        scores_local = torch.matmul(Q_local, K_local.transpose(-2, -1)) / np.sqrt(self.head_dim)
        
        sigma = torch.exp(self.W_sigma(z_global)).squeeze(-1)
        
        pos = torch.arange(seq_len, device=z_local.device).float()
        i = pos.view(1, seq_len, 1)
        j = pos.view(1, 1, seq_len)
        
        diff = j - i
        sigma = sigma.unsqueeze(-1)
        sigma_sq = sigma ** 2 + 1e-8
        gaussian_kernel = 1.0 / torch.sqrt(2 * torch.pi * sigma_sq) * torch.exp(-(diff ** 2) / (2 * sigma_sq))
        gaussian_kernel = gaussian_kernel.unsqueeze(1).expand(-1, self.num_heads, -1, -1)
        
        scores_local_with_gaussian = gaussian_kernel + scores_local
        C_local = F.softmax(scores_local_with_gaussian, dim=-1)
        C_local = self.dropout(C_local)
        
        z_tilde_local = torch.matmul(C_local, V_local)
        z_tilde_local = z_tilde_local.transpose(1, 2).contiguous().view(batch_size, seq_len, self.d_model)
        z_tilde_local = self.output_proj(z_tilde_local)
        
        return C_local, C_global, z_tilde_local, z_tilde_global

# ====================== 双路径Transformer层 ======================
class DualPathTransformerLayer(nn.Module):
    """Dual-Path Transformer Layer"""
    
    def __init__(self, d_model, num_heads, dropout=0.1, conv_kernel_size=3):
        super().__init__()
        self.mga = MultigranularityAttention(d_model, num_heads, dropout)
        self.norm1_local = nn.LayerNorm(d_model)
        self.norm1_global = nn.LayerNorm(d_model)
        self.norm2_local = nn.LayerNorm(d_model)
        self.norm2_global = nn.LayerNorm(d_model)
        self.conv_local = nn.Conv1d(d_model, d_model, kernel_size=conv_kernel_size, padding=conv_kernel_size//2)
        self.conv_global = nn.Conv1d(d_model, d_model, kernel_size=conv_kernel_size, padding=conv_kernel_size//2)
        self.dropout = nn.Dropout(dropout)
        
    def forward(self, z_local, z_global):
        C_local, C_global, z_tilde_local, z_tilde_global = self.mga(z_local, z_global)
        z_bar_local = self.norm1_local(z_local + z_tilde_local)
        z_bar_global = self.norm1_global(z_global + z_tilde_global)
        
        z_bar_local_conv = z_bar_local.transpose(1, 2)
        z_bar_global_conv = z_bar_global.transpose(1, 2)
        
        z_conv_local = self.conv_local(z_bar_local_conv).transpose(1, 2)
        z_conv_global = self.conv_global(z_bar_global_conv).transpose(1, 2)
        
        z_out_local = self.norm2_local(z_bar_local + z_conv_local)
        z_out_global = self.norm2_global(z_bar_global + z_conv_global)
        
        return C_local, C_global, z_out_local, z_out_global

# ====================== MGRD模型 ======================
class MGRD(nn.Module):
    """Multigranularity Reconstruction Deviation Model"""
    
    def __init__(self, input_dim, d_model=128, num_layers=3, num_heads=8, 
                 dropout=0.1, window_size=100, conv_kernel_size=3):
        super().__init__()
        self.input_dim = input_dim
        self.d_model = d_model
        self.num_layers = num_layers
        self.window_size = window_size
        
        self.value_embedding = nn.Linear(input_dim, d_model)
        self.positional_encoding = self._create_positional_encoding(window_size, d_model)
        self.dropout_emb = nn.Dropout(dropout)
        
        self.layers = nn.ModuleList([
            DualPathTransformerLayer(d_model, num_heads, dropout, conv_kernel_size)
            for _ in range(num_layers)
        ])
        
        self.output_proj_local = nn.Linear(d_model, input_dim)
        self.output_proj_global = nn.Linear(d_model, input_dim)
        
        self._init_parameters()
    
    def _create_positional_encoding(self, max_len, d_model):
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-np.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)
        return nn.Parameter(pe, requires_grad=False)
    
    def _init_parameters(self):
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)
    
    def forward(self, x):
        batch_size, seq_len, _ = x.shape
        
        value_emb = self.value_embedding(x)
        pos_emb = self.positional_encoding[:, :seq_len, :]
        
        z_local = self.dropout_emb(pos_emb + value_emb)
        z_global = z_local.clone()
        
        attention_matrices = []
        
        for layer in self.layers:
            C_local, C_global, z_local, z_global = layer(z_local, z_global)
            attention_matrices.append((C_local, C_global))
        
        x_hat_local = self.output_proj_local(z_local)
        x_hat_global = self.output_proj_global(z_global)
        
        return x_hat_local, x_hat_global, attention_matrices
    
    def compute_anomaly_score(self, x):
        """计算异常分数 (论文公式8)"""
        x_hat_local, x_hat_global, _ = self.forward(x)
        anomaly_score = F.mse_loss(x_hat_local, x_hat_global, reduction='none')
        anomaly_score = anomaly_score.mean(dim=-1)
        window_anomaly_score = anomaly_score.max(dim=-1)[0]
        return window_anomaly_score

# ====================== 训练和评估函数 ======================
class MGRDTrainer:
    """MGRD模型训练器"""
    
    def __init__(self, model, lr=1e-4, lambda_kl=0.1, device='cuda'):
        self.model = model.to(device)
        self.device = device
        self.lambda_kl = lambda_kl
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=lr)
        self.patience = 20
        self.min_delta = 1e-5
        self.best_loss = float('inf')
        self.best_f1 = 0
        self.counter = 0
        self.early_stop = False
        self.train_losses = []
        self.val_losses = []
    
    def compute_kl_divergence(self, C1, C2):
        eps = 1e-8
        C1_norm = C1 + eps
        C2_norm = C2 + eps
        C1_norm = C1_norm / C1_norm.sum(dim=-1, keepdim=True)
        C2_norm = C2_norm / C2_norm.sum(dim=-1, keepdim=True)
        kl = (C1_norm * (torch.log(C1_norm + eps) - torch.log(C2_norm + eps))).sum(dim=-1).mean()
        return kl
    
    def compute_loss(self, x, x_hat_local, x_hat_global, attention_matrices):
        mse_local = F.mse_loss(x_hat_local, x)
        mse_global = F.mse_loss(x_hat_global, x)
        
        kl_loss = 0
        if attention_matrices and len(attention_matrices) > 0:
            for C_local, C_global in attention_matrices:
                kl_loss += self.compute_kl_divergence(C_local, C_global) + \
                          self.compute_kl_divergence(C_global, C_local)
            kl_loss = kl_loss / (2 * len(attention_matrices))
        
        total_loss = mse_local + mse_global + self.lambda_kl * kl_loss
        
        return total_loss
    
    def train_epoch(self, train_loader, epoch):
        self.model.train()
        total_loss = 0
        
        for batch_idx, (x, _) in enumerate(train_loader):
            x = x.to(self.device)
            
            # 第一阶段: 优化全局重建
            self.optimizer.zero_grad()
            x_hat_local, x_hat_global, attention_matrices = self.model(x)
            x_hat_local_detach = x_hat_local.detach()
            loss1 = self.compute_loss(x, x_hat_local_detach, x_hat_global, attention_matrices)
            loss1.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            self.optimizer.step()
            
            # 第二阶段: 优化局部重建
            self.optimizer.zero_grad()
            x_hat_local, x_hat_global, attention_matrices = self.model(x)
            x_hat_global_detach = x_hat_global.detach()
            loss2 = self.compute_loss(x, x_hat_local, x_hat_global_detach, attention_matrices)
            loss2.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            self.optimizer.step()
            
            total_loss += loss2.item()
            
            if batch_idx % 10 == 0:
                print(f'Epoch {epoch}, Batch {batch_idx}, Loss: {loss2.item():.4f}')
        
        avg_loss = total_loss / len(train_loader)
        return avg_loss
    
    def validate(self, val_loader):
        self.model.eval()
        total_loss = 0
        all_scores = []
        all_labels = []
        
        with torch.no_grad():
            for x, y in val_loader:
                x = x.to(self.device)
                y = y.to(self.device)
                
                x_hat_local, x_hat_global, attention_matrices = self.model(x)
                loss = self.compute_loss(x, x_hat_local, x_hat_global, attention_matrices)
                anomaly_scores = self.model.compute_anomaly_score(x)
                
                total_loss += loss.item()
                all_scores.extend(anomaly_scores.cpu().numpy().flatten())
                all_labels.extend(y.cpu().numpy().flatten())
        
        avg_loss = total_loss / len(val_loader)
        return avg_loss, np.array(all_scores), np.array(all_labels)
    
    def check_early_stop(self, val_loss, val_f1):
        if val_f1 > self.best_f1 + 0.001:
            self.best_f1 = val_f1
            self.best_loss = val_loss
            self.counter = 0
        elif val_loss < self.best_loss - self.min_delta:
            self.best_loss = val_loss
            self.counter = 0
        else:
            self.counter += 1
            if self.counter >= self.patience:
                self.early_stop = True
                
                
                
    
    def train(self, train_loader, val_loader, epochs=100):  #100
        print("开始训练MGRD模型...")
        start_time = time.time()
        
        for epoch in range(1, epochs + 1):
            train_loss = self.train_epoch(train_loader, epoch)
            self.train_losses.append(train_loss)
            
            val_loss, val_scores, val_labels = self.validate(val_loader)
            self.val_losses.append(val_loss)
            
            if len(val_scores) > 0 and len(val_labels) > 0:
                # 使用论文方法计算阈值（根据验证集异常比例）
                val_anomaly_ratio = np.sum(val_labels) / len(val_labels)
                threshold = PaperThresholdCalculator.calculate_threshold_by_anomaly_ratio(
                    val_scores, val_anomaly_ratio
                )
                
                val_pred = (val_scores > threshold).astype(int)
                val_f1 = f1_score(val_labels, val_pred, zero_division=0)
                
                print(f"Epoch {epoch}/{epochs}:")
                print(f"  Train Loss: {train_loss:.4f}, Val Loss: {val_loss:.4f}")
                print(f"  Val F1: {val_f1:.4f}, Threshold: {threshold:.6f}")
            else:
                print(f"Epoch {epoch}/{epochs}:")
                print(f"  Train Loss: {train_loss:.4f}, Val Loss: {val_loss:.4f}")
            
            if 'val_f1' in locals():
                self.check_early_stop(val_loss, val_f1)
            
            if self.early_stop:
                print(f"Early stopping at epoch {epoch}")
                break
        
        training_time = time.time() - start_time
        print(f"训练完成，总时间: {training_time:.2f}秒")
        return training_time

def compute_all_metrics(scores, labels, threshold):
    scores = np.nan_to_num(scores, nan=0.0, posinf=0.0, neginf=0.0)
    """计算所有指标"""
    preds = (scores > threshold).astype(int)
    
    # 基础指标
    metrics = PaperThresholdCalculator.calculate_metrics(labels, preds)
    
    # AUC-ROC
    if len(np.unique(labels)) > 1:
        fpr, tpr, _ = roc_curve(labels, scores)
        metrics['auc'] = round(float(auc(fpr, tpr)), 4)
        
        # PR-AUC
        precision_curve, recall_curve, _ = precision_recall_curve(labels, scores)
        metrics['pr_auc'] = round(float(auc(recall_curve, precision_curve)), 4)
    else:
        metrics['auc'] = 0.0
        metrics['pr_auc'] = 0.0
    
    return metrics

def main():
    # 设置随机种子
    import random
    random.seed(42)
    np.random.seed(42)
    torch.manual_seed(42)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(42)
    
    # 加载数据
    print("加载数据...")
    processor = DataProcessor()
    processed_data = processor.load_and_preprocess_data()
    X_train, y_train, X_val, y_val,X_test,y_test = processed_data
    

    X_train = np.nan_to_num(X_train, nan=0.0, posinf=0.0, neginf=0.0)
    X_val = np.nan_to_num(X_val, nan=0.0, posinf=0.0, neginf=0.0)
    X_test = np.nan_to_num(X_test, nan=0.0, posinf=0.0, neginf=0.0)
    
    
    
    print(f"原始训练数据形状: X_train={X_train.shape}, y_train={y_train.shape}")
    print(f"原始验证数据形状: X_val={X_val.shape}, y_val={y_val.shape}")
    print(f"原始测试数据形状: X_test={X_test.shape}, y_test={y_test.shape}")
    
    # 计算数据集异常比例
    train_anomaly_ratio = np.sum(y_train) / len(y_train) if len(y_train) > 0 else 0
    val_anomaly_ratio = np.sum(y_val) / len(y_val) if len(y_val) > 0 else 0
    test_anomaly_ratio = np.sum(y_test) / len(y_test) if len(y_test) > 0 else 0

    print(f"训练集异常比例: {train_anomaly_ratio:.4f}")
    print(f"验证集异常比例: {val_anomaly_ratio:.4f}")
    print(f"测试集异常比例: {test_anomaly_ratio:.4f}")
    
    # 窗口大小设置（按照论文使用100）
    window_size = 100
    stride = window_size // 2
    
    if X_train.shape[0] < window_size:
        window_size = X_train.shape[0]
        stride = max(1, window_size // 2)
    
    print(f"使用窗口大小: {window_size}, 步长: {stride}")
    
    # 数据窗口化
    X_train_windows, y_train_windows = create_time_series_windows(X_train, y_train, window_size=window_size, stride=stride)
    X_val_windows, y_val_windows = create_time_series_windows(X_val, y_val, window_size=window_size, stride=stride)
    X_test_windows, y_test_windows = create_time_series_windows(X_test, y_test, window_size=window_size, stride=stride)

    
    print(f"窗口化后训练数据形状: X_train_windows={X_train_windows.shape}, y_train_windows={y_train_windows.shape}")
    print(f"窗口化后验证数据形状: X_val_windows={X_val_windows.shape}, y_val_windows={y_val_windows.shape}")
    print(f"窗口化后测试数据形状: X_test_windows={X_test_windows.shape}, y_test_windows={y_test_windows.shape}")
    
    # 检查数据
    if len(X_train_windows) == 0 or len(X_val_windows) == 0:
        print("错误: 窗口化后没有数据!")
        return
    
    # 创建数据加载器
    batch_size = min(32, len(X_train_windows))
    train_dataset = TensorDataset(
        torch.FloatTensor(X_train_windows),
        torch.FloatTensor(y_train_windows)
    )
    val_dataset = TensorDataset(
        torch.FloatTensor(X_val_windows),
        torch.FloatTensor(y_val_windows)
    )
    # 创建测试数据加载器
    test_dataset = TensorDataset(
        torch.FloatTensor(X_test_windows),
        torch.FloatTensor(y_test_windows)
        )
      
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
    
    # 创建模型
    input_dim = X_train.shape[1]
    d_model = 128
    num_heads = 8
    num_layers = 3
    
    if input_dim < 50:
        d_model = max(64, input_dim * 2)
    
    model = MGRD(
        input_dim=input_dim,
        d_model=d_model,
        num_layers=num_layers,
        num_heads=num_heads,
        window_size=window_size
    )
    
    print(f"模型参数:")
    print(f"  输入维度: {input_dim}")
    print(f"  隐藏维度: {d_model}")
    print(f"  层数: {num_layers}")
    print(f"  注意力头数: {num_heads}")
    
    # 训练模型
    trainer = MGRDTrainer(model, lr=1e-4, lambda_kl=1.0, device=device)
    
    
    training_time = trainer.train(train_loader, val_loader, epochs=100)  #100
    
    # 保存模型
    model_save_path = "2MGA/MGA.pth"
    torch.save(model.state_dict(), model_save_path)
    print(f"模型已保存到: {model_save_path}")
    
    # ====================== 评估阶段 ======================
    print("\n开始评估模型...")
    
    # 1. 计算训练集指标
    print("计算训练集指标...")
    train_start_time = time.time()
    train_scores, train_labels = [], []
    model.eval()
    with torch.no_grad():
        for x, y in train_loader:
            x = x.to(device)
            scores = model.compute_anomaly_score(x)
            train_scores.extend(scores.cpu().numpy().flatten())
            train_labels.extend(y.numpy().flatten())
    
    train_scores = np.array(train_scores)
    train_labels = np.array(train_labels)
    train_inference_time = time.time() - train_start_time
    
    # 使用论文方法计算训练集阈值（根据训练集异常比例）
    train_threshold = PaperThresholdCalculator.calculate_threshold_by_anomaly_ratio(
        train_scores, train_anomaly_ratio
    )
    train_metrics = compute_all_metrics(train_scores, train_labels, train_threshold)
    
    # 2. 计算验证集指标
    print("计算验证集指标...")
    val_start_time = time.time()
    val_scores, val_labels = [], []
    with torch.no_grad():
        for x, y in val_loader:
            x = x.to(device)
            scores = model.compute_anomaly_score(x)
            val_scores.extend(scores.cpu().numpy().flatten())
            val_labels.extend(y.numpy().flatten())
    
    val_scores = np.array(val_scores)
    val_labels = np.array(val_labels)
    val_inference_time = time.time() - val_start_time
    
    # 使用论文方法计算验证集阈值（根据验证集异常比例）
    val_threshold = PaperThresholdCalculator.calculate_threshold_by_anomaly_ratio(
        val_scores, val_anomaly_ratio
    )
    val_metrics = compute_all_metrics(val_scores, val_labels, val_threshold)
    
    # 3. 计算测试集指标（使用验证集作为测试集）
    print("计算测试集指标...")
    
    test_scores, test_labels = [], []
    with torch.no_grad():
        for x, y in test_loader:  # 使用test_loader
            x = x.to(device)
            scores = model.compute_anomaly_score(x)
            test_scores.extend(scores.cpu().numpy().flatten())
            test_labels.extend(y.numpy().flatten())

    test_scores = np.array(test_scores)
    test_labels = np.array(test_labels)
    
    # 使用论文方法计算测试集阈值（根据测试集异常比例）
    test_threshold = PaperThresholdCalculator.calculate_threshold_by_anomaly_ratio(
        test_scores, test_anomaly_ratio
        )
    test_metrics = compute_all_metrics(test_scores, test_labels, test_threshold)
    
    
    # 计算总推理时间和推理速度
    total_inference_time = train_inference_time 
    total_samples = len(train_scores) 
    inference_speed = total_samples / total_inference_time if total_inference_time > 0 else 0
    
    # ====================== 保存结果 ======================
    '''
    # 保存评估结果到CSV
    results_df = pd.DataFrame({
        'dataset': ['train', 'val', 'test'],
        'auc': [
            train_metrics.get('auc', 0.0),
            val_metrics.get('auc', 0.0),
            test_metrics.get('auc', 0.0)
        ],
        'pr_auc': [
            train_metrics.get('pr_auc', 0.0),
            val_metrics.get('pr_auc', 0.0),
            test_metrics.get('pr_auc', 0.0)
        ],
        'accuracy': [
            train_metrics.get('accuracy', 0.0),
            val_metrics.get('accuracy', 0.0),
            test_metrics.get('accuracy', 0.0)
        ],
        'precision': [
            train_metrics.get('precision', 0.0),
            val_metrics.get('precision', 0.0),
            test_metrics.get('precision', 0.0)
        ],
        'recall': [
            train_metrics.get('recall', 0.0),
            val_metrics.get('recall', 0.0),
            test_metrics.get('recall', 0.0)
        ],
        'f1_score': [
            train_metrics.get('f1_score', 0.0),
            val_metrics.get('f1_score', 0.0),
            test_metrics.get('f1_score', 0.0)
        ],
        'g_mean': [
            train_metrics.get('g_mean', 0.0),
            val_metrics.get('g_mean', 0.0),
            test_metrics.get('g_mean', 0.0)
        ]
    })
    
    # 确保所有值都是4位小数
    for col in results_df.columns:
        if col != 'dataset':
            results_df[col] = results_df[col].round(4)
    
    results_path = "2MGA/results.csv"
    results_df.to_csv(results_path, index=False)
    print(f"评估结果已保存到: {results_path}")
    '''
    
    # 保存时间结果到CSV
    time_df = pd.DataFrame({
        'metric': ['Training_Time_Seconds', 'Inference_Time_Seconds', 'Inference_Speed_SamplesPerSecond'],
        'value': [
            round(training_time, 4),
            round(total_inference_time, 4),
            round(inference_speed, 4)
        ]
    })
    
    time_path = "2MGA/time.csv"
    time_df.to_csv(time_path, index=False)
    print(f"时间结果已保存到: {time_path}")
    
    # ====================== 打印结果 ======================
    print("\n" + "="*60)
    print("最终结果汇总")
    print("="*60)
    
    print("\n训练集结果:")
    print(f"  异常比例: {train_anomaly_ratio:.4f}")
    print(f"  阈值: {train_threshold:.6f}")
    print(f"  AUC: {train_metrics.get('auc', 0.0):.4f}")
    print(f"  PR-AUC: {train_metrics.get('pr_auc', 0.0):.4f}")
    print(f"  准确率: {train_metrics.get('accuracy', 0.0):.4f}")
    print(f"  精确率: {train_metrics.get('precision', 0.0):.4f}")
    print(f"  召回率: {train_metrics.get('recall', 0.0):.4f}")
    print(f"  F1分数: {train_metrics.get('f1_score', 0.0):.4f}")
    print(f"  G-Mean: {train_metrics.get('g_mean', 0.0):.4f}")
    
    print("\n验证集结果:")
    print(f"  异常比例: {val_anomaly_ratio:.4f}")
    print(f"  阈值: {val_threshold:.6f}")
    print(f"  AUC: {val_metrics.get('auc', 0.0):.4f}")
    print(f"  PR-AUC: {val_metrics.get('pr_auc', 0.0):.4f}")
    print(f"  准确率: {val_metrics.get('accuracy', 0.0):.4f}")
    print(f"  精确率: {val_metrics.get('precision', 0.0):.4f}")
    print(f"  召回率: {val_metrics.get('recall', 0.0):.4f}")
    print(f"  F1分数: {val_metrics.get('f1_score', 0.0):.4f}")
    print(f"  G-Mean: {val_metrics.get('g_mean', 0.0):.4f}")
    
    print("\n测试集结果:")
    print(f"  阈值: {test_threshold:.6f}")
    print(f"  AUC: {test_metrics.get('auc', 0.0):.4f}")
    print(f"  PR-AUC: {test_metrics.get('pr_auc', 0.0):.4f}")
    print(f"  准确率: {test_metrics.get('accuracy', 0.0):.4f}")
    print(f"  精确率: {test_metrics.get('precision', 0.0):.4f}")
    print(f"  召回率: {test_metrics.get('recall', 0.0):.4f}")
    print(f"  F1分数: {test_metrics.get('f1_score', 0.0):.4f}")
    print(f"  G-Mean: {test_metrics.get('g_mean', 0.0):.4f}")
    
    print("\n时间统计:")
    print(f"  训练时间: {training_time:.4f} 秒")
    print(f"  总推理时间: {total_inference_time:.4f} 秒")
    print(f"  推理速度: {inference_speed:.4f} 样本/秒")
    
    print("\n" + "="*60)
    print("所有结果已保存到2MGA文件夹")
    print("="*60)

# 运行主程序
if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"程序运行出错: {e}")
        import traceback
        traceback.print_exc()